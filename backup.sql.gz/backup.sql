-- MySQL dump 10.13  Distrib 8.0.40, for Linux (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `addressLine3` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_iejqwvczjmjuyubddmtlqnisrrlisbzmfpyl` (`primaryOwnerId`),
  CONSTRAINT `fk_iejqwvczjmjuyubddmtlqnisrrlisbzmfpyl` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nkpailjuzymysstuypfezwbvyjnkodlgtgnv` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
INSERT INTO `addresses` VALUES (2,1,NULL,'US',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-07-12 22:55:10','2025-07-12 22:55:10');
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_cxdbxmfubnvxptadacxsfvwyiesqngotylfz` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_aovjetwiqeofbjupxeoumilbbssixzorpbus` (`dateRead`),
  KEY `fk_cepmhlblwmynyisikjsnkxlhyxtplhxodsmn` (`pluginId`),
  CONSTRAINT `fk_cepmhlblwmynyisikjsnkxlhyxtplhxodsmn` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xryzsghphdaaiyptbigjtbdrwwuddolnwdaj` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_lhoruyoyivavcfqhhwqigfgvxfhwqousbvcl` (`sessionId`,`volumeId`),
  KEY `idx_jgxpcreqjioondgxwsqhqdwgrpuulhomkesy` (`volumeId`),
  CONSTRAINT `fk_mndojmavmsdvpeexamxwmxxvivlfapbmzxsh` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_udfsplqcgllpdaugblkojlhmgcmwwvofkzud` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexdata`
--

LOCK TABLES `assetindexdata` WRITE;
/*!40000 ALTER TABLE `assetindexdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `mimeType` varchar(255) DEFAULT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_qkesjvbqufrhwmysacijvsqrzzxmzbdfkocz` (`filename`,`folderId`),
  KEY `idx_qtyqbejjmjiutjagtcicecphmnojidayzayu` (`folderId`),
  KEY `idx_pwqluavofryqetggsphznybjmbjnvwxswhgn` (`volumeId`),
  KEY `fk_kxjcknggdinjhyfkmkpbrmyxitwxytvwcgwu` (`uploaderId`),
  CONSTRAINT `fk_eudmucxtfucaxglrustaytzjpcolcthniwmy` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kxjcknggdinjhyfkmkpbrmyxitwxytvwcgwu` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_riuvcthxwbxwdlyhmaorjtswzubtuvfxvtls` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_titduejbebrfkkkjcvfkmpipkaeahrxbucqu` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_sites`
--

DROP TABLE IF EXISTS `assets_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_sites` (
  `assetId` int NOT NULL,
  `siteId` int NOT NULL,
  `alt` text,
  PRIMARY KEY (`assetId`,`siteId`),
  KEY `fk_lsdworizekjjhxmhhwhpkuqzielvqtwrdicg` (`siteId`),
  CONSTRAINT `fk_lsdworizekjjhxmhhwhpkuqzielvqtwrdicg` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_qtktfprbnwdhdahmkrdigzqapaawjwxjoaby` FOREIGN KEY (`assetId`) REFERENCES `assets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_sites`
--

LOCK TABLES `assets_sites` WRITE;
/*!40000 ALTER TABLE `assets_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authenticator`
--

DROP TABLE IF EXISTS `authenticator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authenticator` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `auth2faSecret` varchar(255) DEFAULT NULL,
  `oldTimestamp` int unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_unxbezdwpeigkablnedvpxfhpeaodkuuuvmz` (`userId`),
  CONSTRAINT `fk_unxbezdwpeigkablnedvpxfhpeaodkuuuvmz` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authenticator`
--

LOCK TABLES `authenticator` WRITE;
/*!40000 ALTER TABLE `authenticator` DISABLE KEYS */;
/*!40000 ALTER TABLE `authenticator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bulkopevents`
--

DROP TABLE IF EXISTS `bulkopevents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bulkopevents` (
  `key` char(10) NOT NULL,
  `senderClass` varchar(255) NOT NULL,
  `eventName` varchar(255) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`key`,`senderClass`,`eventName`),
  KEY `idx_jwfpfzzkcgglymshprstaubitabulfkuthyb` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bulkopevents`
--

LOCK TABLES `bulkopevents` WRITE;
/*!40000 ALTER TABLE `bulkopevents` DISABLE KEYS */;
/*!40000 ALTER TABLE `bulkopevents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_jjfsppyennermnzrncduhcmsgpcdcprximpm` (`groupId`),
  KEY `fk_bcoqccigilcckpzegxtoexpecexrcqynoysg` (`parentId`),
  CONSTRAINT `fk_bcmedhoejrxrthpbviqpevlawoqponwmkduk` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_bcoqccigilcckpzegxtoexpecexrcqynoysg` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_tvwadulctlugdzhajpypqdzrljzntiwiamvd` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_usnbsuxxttqlwdukczawjbzqpnvbbsdsxrxa` (`name`),
  KEY `idx_jnhybqsvvftsvrxpqzmshpruftedyperamfb` (`handle`),
  KEY `idx_ynrgbdvcmqeuxfxexpmnoyakzvoqmzhyrohr` (`structureId`),
  KEY `idx_vaekapuxobtajbnnlvvokjbwgbxbzlyjgejo` (`fieldLayoutId`),
  KEY `idx_csknktyxexqbjklduufujgrzxdxdawkqbvlj` (`dateDeleted`),
  CONSTRAINT `fk_fgonecjulhivpjjnfxihdynnjuqyuuatvdiq` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zypovcclvzxgkjagafidcyivslywelssmxzl` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bvzubxubkwvrzldumyjghlbrbbcrlnuwwzly` (`groupId`,`siteId`),
  KEY `idx_kyxpmlhpakrovcssbdwdquirfxhlcrvxprhs` (`siteId`),
  CONSTRAINT `fk_qeugnrjzhzumbrzijfajhnrourqqwrhcdkfo` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wxgetkoqnuoznuvhjxugoendmgieatnghjcv` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_eyjhaehhksngjdbkqyrqzfkmefigebhzbvfv` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_xfpajzhuulmzaiqwqloqnrxgigtuadcyhlae` (`siteId`),
  KEY `fk_cugkbvpphyxbojisddlyaqavarlyiktyucok` (`userId`),
  CONSTRAINT `fk_cugkbvpphyxbojisddlyaqavarlyiktyucok` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_xfpajzhuulmzaiqwqloqnrxgigtuadcyhlae` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_zipwrtesjozjtuwmxcdtrahfqfpzauigbpgc` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
INSERT INTO `changedattributes` VALUES (3,1,'authorIds','2025-07-14 13:17:28',0,1),(3,1,'postDate','2025-07-14 13:12:14',0,1),(3,1,'slug','2025-07-14 13:12:13',0,1),(3,1,'title','2025-07-14 13:12:13',0,1),(3,1,'uri','2025-07-14 13:17:59',0,1),(9,1,'title','2025-07-14 13:46:52',0,1),(9,1,'uri','2025-07-14 13:46:52',0,1),(15,1,'title','2025-07-14 14:01:39',0,1),(19,1,'authorIds','2025-07-14 14:19:21',0,1),(19,1,'slug','2025-07-14 14:30:53',0,1),(19,1,'title','2025-07-14 19:56:15',0,1),(19,1,'uri','2025-07-14 14:25:58',0,1),(49,1,'slug','2025-07-14 21:50:33',0,1),(49,1,'title','2025-07-14 21:50:33',0,1);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `layoutElementUid` char(36) NOT NULL DEFAULT '0',
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`,`layoutElementUid`),
  KEY `idx_bmuuijwoubeztpewvhnsyslriplwmbpocqwz` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_slgmwabjrgfoulrlhscyzcdzjhlmtshsvsbe` (`siteId`),
  KEY `fk_ahanoyiuumwrflwzemczzlwqesyfkxtbtmni` (`fieldId`),
  KEY `fk_tptytktfnvnytwbyolwjjjbffvhfrpcpqtuo` (`userId`),
  CONSTRAINT `fk_ahanoyiuumwrflwzemczzlwqesyfkxtbtmni` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_slgmwabjrgfoulrlhscyzcdzjhlmtshsvsbe` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tptytktfnvnytwbyolwjjjbffvhfrpcpqtuo` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_vimpfkqjlgtoloopnfsnimukhbizsctzbzdn` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
INSERT INTO `changedfields` VALUES (9,1,3,'a8779ca3-468d-4dc2-8c29-53da9010a129','2025-07-14 13:44:08',0,1),(15,1,6,'dd38f0c1-44d0-40a9-a228-b5ebe2ce0033','2025-07-14 14:01:39',0,1),(19,1,8,'d3bc591f-f9b7-4396-9b96-a457a0186712','2025-07-25 21:16:42',0,1),(29,1,7,'167cc395-5ff6-40f1-bdd4-db6422558910','2025-07-14 14:34:41',0,1),(49,1,9,'5209465d-7211-4f5d-a046-4cb112f49455','2025-07-14 22:22:04',0,1);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contentblocks`
--

DROP TABLE IF EXISTS `contentblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contentblocks` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_adgghxghozjuhmppuicbyxqpzibqejckpnzk` (`primaryOwnerId`),
  KEY `idx_lwuuwdojufetyfxpgkngammwgcihlxcwvajl` (`fieldId`),
  CONSTRAINT `fk_rblrzcmojoucqoksefrzykcbwnzvclkamwvh` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tyivufbomedecderaovxyefgyoltreobfyld` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vhtxxdocozjjdmhymypmcrpwvdhepetdvozb` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contentblocks`
--

LOCK TABLES `contentblocks` WRITE;
/*!40000 ALTER TABLE `contentblocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `contentblocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpnav_layout`
--

DROP TABLE IF EXISTS `cpnav_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cpnav_layout` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `isDefault` tinyint(1) DEFAULT '0',
  `permissions` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cpnav_layout`
--

LOCK TABLES `cpnav_layout` WRITE;
/*!40000 ALTER TABLE `cpnav_layout` DISABLE KEYS */;
INSERT INTO `cpnav_layout` VALUES (1,'Default',1,'[]',1,'2025-07-13 17:06:34','2025-07-13 17:06:34','161e35c5-199b-4d9c-b090-9dc1c61bc616');
/*!40000 ALTER TABLE `cpnav_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpnav_navigation`
--

DROP TABLE IF EXISTS `cpnav_navigation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cpnav_navigation` (
  `id` int NOT NULL AUTO_INCREMENT,
  `layoutId` int NOT NULL,
  `handle` varchar(255) DEFAULT NULL,
  `prevLabel` varchar(255) DEFAULT NULL,
  `currLabel` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  `sortOrder` smallint unsigned DEFAULT NULL,
  `prevLevel` smallint DEFAULT NULL,
  `level` smallint DEFAULT '1',
  `prevParentId` int DEFAULT NULL,
  `parentId` int DEFAULT NULL,
  `prevUrl` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `customIcon` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `newWindow` tinyint(1) DEFAULT '0',
  `subnavBehaviour` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_hubcwobjgnocoknxrdgfbkzexqorbkipyqup` (`layoutId`),
  CONSTRAINT `fk_hubcwobjgnocoknxrdgfbkzexqorbkipyqup` FOREIGN KEY (`layoutId`) REFERENCES `cpnav_layout` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cpnav_navigation`
--

LOCK TABLES `cpnav_navigation` WRITE;
/*!40000 ALTER TABLE `cpnav_navigation` DISABLE KEYS */;
INSERT INTO `cpnav_navigation` VALUES (1,1,'dashboard','Dashboard','Dashboard',0,2,1,1,NULL,NULL,'dashboard','dashboard','gauge','','craft',0,NULL,'2025-07-13 17:06:35','2025-07-14 20:55:04','31589d7d-c0b5-4e67-972a-d52ce78fbff6'),(2,1,'graphql','GraphQL','GraphQL',0,3,1,1,NULL,NULL,'graphql','graphql','graphql','','craft',0,NULL,'2025-07-13 17:06:35','2025-07-14 20:55:04','86963631-ab2b-409f-9f3e-83e7c91f7084'),(3,1,'schemas','Schemas','Schemas',1,4,2,2,2,2,'graphql/schemas','graphql/schemas','','','craft',0,NULL,'2025-07-13 17:06:35','2025-07-14 20:55:04','f769d927-37eb-455b-a3f4-894510f05932'),(4,1,'tokens','Tokens','Tokens',1,5,2,2,2,2,'graphql/tokens','graphql/tokens','','','craft',0,NULL,'2025-07-13 17:06:35','2025-07-14 20:55:04','477b3d18-a8e3-491e-8bfd-b8623f408866'),(5,1,'graphiql','GraphiQL','GraphiQL',1,6,2,2,2,2,'graphiql','graphiql','','','craft',1,NULL,'2025-07-13 17:06:35','2025-07-14 20:55:04','42b9e3ea-c132-4218-9a2d-926f70fec4f7'),(6,1,'utilities','Utilities','Utilities',1,11,1,1,NULL,NULL,'utilities','utilities','wrench','','craft',0,NULL,'2025-07-13 17:06:35','2025-07-14 20:55:04','469f73b6-5323-4852-918c-026e5c0c0934'),(7,1,'settings','Settings','Settings',1,10,1,1,NULL,NULL,'settings','settings','gear','','craft',0,NULL,'2025-07-13 17:06:35','2025-07-14 20:55:04','eb26a13f-064b-4fe8-a5e0-8bc90e2ea7d8'),(8,1,'plugin-store','Plugin Store','Plugin Store',1,9,1,1,NULL,NULL,'plugin-store','plugin-store','plug','','craft',0,NULL,'2025-07-13 17:06:35','2025-07-14 20:55:04','cf6be2e2-2c83-4a6e-aa4a-50af959598d6'),(9,1,'visitPlaybook','Visit Playbook','Playbook',1,7,NULL,1,NULL,NULL,'','https://www.playbook.com/','scribble','','manual',0,NULL,'2025-07-13 17:07:47','2025-07-14 20:55:04','20dcc96b-cb87-475a-a544-da0a6e504ee9'),(13,1,'entries','Entries','Pages',1,1,1,1,NULL,NULL,'entries','entries','newspaper','','craft',0,NULL,'2025-07-14 14:18:27','2025-07-14 20:55:04','30319499-fb4f-4280-9cf6-a80d8820de14'),(14,1,'','','System',1,8,NULL,1,NULL,NULL,'','','','','divider',0,NULL,'2025-07-14 20:54:23','2025-07-14 20:55:04','5d80a675-d1b8-4cce-9eda-f1b84f7bcee5'),(15,1,'client','Client','Client',1,0,NULL,1,NULL,NULL,'','','','','divider',0,NULL,'2025-07-14 20:55:02','2025-07-14 20:55:04','3119091a-11eb-487e-b66f-2f9ce2ee3656');
/*!40000 ALTER TABLE `cpnav_navigation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_lisiprdprqffwgvudfncujgwiistssulqtrf` (`userId`),
  CONSTRAINT `fk_lisiprdprqffwgvudfncujgwiistssulqtrf` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hrijdzhalelzbqruupfxgftmwbtoldlwnhmb` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_rbjiueuhiuhtyfiuzgdtxhokgficzygcwqmh` (`creatorId`,`provisional`),
  KEY `idx_qfbrkxthaeljqrqtqyytsztwlcqqagktzzko` (`saved`),
  KEY `fk_opptcxxydbhnmunvxvpdmvbgrqlnwhbjuvud` (`canonicalId`),
  CONSTRAINT `fk_ihylmmhhoqlvsflornhjmzcdksfiuaazijqn` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_opptcxxydbhnmunvxvpdmvbgrqlnwhbjuvud` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
INSERT INTO `drafts` VALUES (1,NULL,1,0,'First draft',NULL,0,NULL,0),(8,NULL,1,0,'First draft',NULL,0,NULL,0);
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_dtywkkyllfwnfblwjlwkpzzowsoisolfsonb` (`elementId`,`timestamp`,`userId`),
  KEY `fk_aqhjbxgmijbunptxncvkqvyrpseloxojvcke` (`userId`),
  KEY `fk_ojuwzeiushqstmpcuxfpabfwgnxmqvfvuzfb` (`siteId`),
  KEY `fk_nkvmplbhdxmyylpekubgfbifvxstzscyhpnw` (`draftId`),
  CONSTRAINT `fk_aqhjbxgmijbunptxncvkqvyrpseloxojvcke` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_guguhlmgryusnpasyukeeyynhqfmvulxjmqh` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nkvmplbhdxmyylpekubgfbifvxstzscyhpnw` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ojuwzeiushqstmpcuxfpabfwgnxmqvfvuzfb` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
INSERT INTO `elementactivity` VALUES (3,1,1,NULL,'save','2025-07-14 13:18:31'),(9,1,1,NULL,'edit','2025-07-14 13:44:05'),(9,1,1,NULL,'save','2025-07-14 13:44:08'),(15,1,1,NULL,'edit','2025-07-14 14:01:37'),(15,1,1,NULL,'save','2025-07-14 14:01:39'),(19,1,1,NULL,'edit','2025-07-25 21:16:40'),(19,1,1,NULL,'save','2025-07-25 21:16:42');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_gnasbpmztdzyengnyilymkjtceermdyshdmt` (`dateDeleted`),
  KEY `idx_argqxvrdojiljefauqlyuwhjojrwujsiadji` (`fieldLayoutId`),
  KEY `idx_flbxmilygrldcwnoqgududgzvjaitlexqkkr` (`type`),
  KEY `idx_nipmgxydovktxotsbfztgdlbmegjlaetnvvl` (`enabled`),
  KEY `idx_eviesoigplbeolwpqmltevevutaeymwpljrx` (`canonicalId`),
  KEY `idx_wprevywifzazbhookxxilbhraacjyeazpuhu` (`archived`,`dateCreated`),
  KEY `idx_yzymndbpqbcplckvuxaflyfldwridoqnypxt` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_iprungpnvbkblwfgijmxvxiqhjekunyyuiys` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_vttinmeicdyonviivaowcqqbaassccrrzffd` (`draftId`),
  KEY `fk_qtjqxlzkafvlbjxcetfohyhzpkjwzesuodsv` (`revisionId`),
  CONSTRAINT `fk_mcuylbqpjlnoeqhfsfpbqnshwsinrlnfathk` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_qtjqxlzkafvlbjxcetfohyhzpkjwzesuodsv` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sbfbxubpwmrwsoxyrnhvhnjmbklfnswiqmie` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_vttinmeicdyonviivaowcqqbaassccrrzffd` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=147 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2025-07-11 00:31:06','2025-07-11 00:31:06',NULL,NULL,NULL,'dcc0930d-5003-443a-8236-b714bb924ecd'),(2,NULL,1,NULL,NULL,'craft\\elements\\Address',1,0,'2025-07-12 22:55:10','2025-07-12 22:55:10',NULL,NULL,NULL,'7dbb6fa8-6e90-4b89-8a14-56d84979eb86'),(3,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2025-07-14 13:12:08','2025-07-14 13:18:31',NULL,'2025-07-14 13:38:06',NULL,'2fa98218-3f53-470c-883e-6562f6d8dda4'),(4,3,NULL,1,1,'craft\\elements\\Entry',1,0,'2025-07-14 13:12:14','2025-07-14 13:12:14',NULL,NULL,NULL,'28fdd828-0703-4fbb-b93c-299011f42d22'),(5,3,NULL,2,1,'craft\\elements\\Entry',1,0,'2025-07-14 13:17:28','2025-07-14 13:17:28',NULL,NULL,NULL,'fe770f40-2d91-47d2-962f-f9adf4af9432'),(6,3,NULL,3,1,'craft\\elements\\Entry',1,0,'2025-07-14 13:17:55','2025-07-14 13:17:55',NULL,NULL,NULL,'063105e1-ebc3-429c-87d5-b92347605a4e'),(7,3,NULL,4,1,'craft\\elements\\Entry',1,0,'2025-07-14 13:17:59','2025-07-14 13:17:59',NULL,NULL,NULL,'11e534aa-1d91-413a-a38a-82b6d3060567'),(8,3,NULL,5,1,'craft\\elements\\Entry',1,0,'2025-07-14 13:18:31','2025-07-14 13:18:31',NULL,NULL,NULL,'34571df8-b9e0-4aaf-aa2b-a1b34a44863f'),(9,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2025-07-14 13:43:45','2025-07-14 13:46:52',NULL,'2025-07-14 13:54:09',NULL,'c2ebab07-6ab1-4395-9a8a-f8826c658025'),(10,9,NULL,6,2,'craft\\elements\\Entry',1,0,'2025-07-14 13:43:45','2025-07-14 13:43:45',NULL,NULL,NULL,'8389dcd8-3826-460f-b7ac-06bb56944516'),(12,9,NULL,7,2,'craft\\elements\\Entry',1,0,'2025-07-14 13:44:08','2025-07-14 13:44:08',NULL,NULL,NULL,'eebe62df-1388-4f85-8196-77a6ffb07a87'),(13,9,NULL,8,2,'craft\\elements\\Entry',1,0,'2025-07-14 13:46:29','2025-07-14 13:46:29',NULL,NULL,NULL,'af215be5-60bc-4f03-a8e4-4d8c31d295cd'),(14,9,NULL,9,2,'craft\\elements\\Entry',1,0,'2025-07-14 13:46:52','2025-07-14 13:46:52',NULL,NULL,NULL,'727f61b3-5483-4c67-abc2-8d26afc09d08'),(15,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2025-07-14 13:58:00','2025-07-14 14:01:39',NULL,'2025-07-14 14:04:47',NULL,'e2009a7a-9f1f-420a-a9f2-c5b1ba9c6026'),(16,15,NULL,10,3,'craft\\elements\\Entry',1,0,'2025-07-14 13:58:00','2025-07-14 13:58:00',NULL,NULL,NULL,'89dc9794-0087-46fe-9d58-c4614b4a036a'),(18,15,NULL,11,3,'craft\\elements\\Entry',1,0,'2025-07-14 14:01:39','2025-07-14 14:01:39',NULL,NULL,NULL,'de99faa7-04c4-4e3d-980f-e7d86f71912d'),(19,NULL,NULL,NULL,5,'craft\\elements\\Entry',1,0,'2025-07-14 14:18:27','2025-07-25 21:16:41',NULL,NULL,NULL,'525214cf-db35-4a7c-a051-720138abd208'),(20,19,NULL,12,5,'craft\\elements\\Entry',1,0,'2025-07-14 14:18:27','2025-07-14 14:18:27',NULL,NULL,NULL,'6e8c7ff4-0be8-4499-9bbb-4a346802f860'),(23,19,NULL,13,5,'craft\\elements\\Entry',1,0,'2025-07-14 14:19:21','2025-07-14 14:19:21',NULL,NULL,NULL,'067c1510-2469-4de2-9ea7-6b956879406e'),(25,19,NULL,14,5,'craft\\elements\\Entry',1,0,'2025-07-14 14:23:13','2025-07-14 14:23:13',NULL,NULL,NULL,'8bcfc730-f632-41ba-8462-9b65f455ce4d'),(26,19,NULL,15,5,'craft\\elements\\Entry',1,0,'2025-07-14 14:25:58','2025-07-14 14:25:58',NULL,NULL,NULL,'29b7a415-1192-49eb-9df1-90cb8bbf8d19'),(27,19,NULL,16,5,'craft\\elements\\Entry',1,0,'2025-07-14 14:26:25','2025-07-14 14:26:25',NULL,NULL,NULL,'5819192e-c527-4019-b33c-3186847d8758'),(28,NULL,8,NULL,4,'craft\\elements\\Entry',1,0,'2025-07-14 14:26:52','2025-07-14 14:26:52',NULL,NULL,NULL,'e82f6b47-4388-47f3-8cac-f6d43cead5d7'),(29,NULL,NULL,NULL,4,'craft\\elements\\Entry',1,0,'2025-07-14 14:29:41','2025-07-14 14:34:41',NULL,'2025-07-14 19:50:29',NULL,'af1bdda7-a41c-4e92-b4cf-5971509f8a35'),(30,19,NULL,17,5,'craft\\elements\\Entry',1,0,'2025-07-14 14:29:41','2025-07-14 14:29:41',NULL,NULL,NULL,'9c1fd705-155b-4954-9cba-5af3ca7ec168'),(31,29,NULL,18,4,'craft\\elements\\Entry',1,0,'2025-07-14 14:29:41','2025-07-14 14:29:41',NULL,NULL,NULL,'ac5e65dc-db07-4646-8347-9d1af2a62720'),(33,19,NULL,19,5,'craft\\elements\\Entry',1,0,'2025-07-14 14:30:53','2025-07-14 14:30:53',NULL,NULL,NULL,'a192be89-9fe8-486a-a91e-51d31e0673ac'),(38,19,NULL,20,5,'craft\\elements\\Entry',1,0,'2025-07-14 14:32:32','2025-07-14 14:32:32',NULL,NULL,NULL,'65b3c649-687c-4e4e-9249-706d1410c48b'),(42,NULL,NULL,NULL,6,'craft\\elements\\Entry',1,0,'2025-07-14 14:34:41','2025-07-14 14:34:41',NULL,'2025-07-14 19:50:32',NULL,'d07577a2-1926-4a1b-b3bb-2ccbe5761be7'),(43,19,NULL,21,5,'craft\\elements\\Entry',1,0,'2025-07-14 14:34:41','2025-07-14 14:34:41',NULL,NULL,NULL,'9a8032dd-2afe-4b33-9a2f-77b3f9fdfcf0'),(44,42,NULL,22,6,'craft\\elements\\Entry',1,0,'2025-07-14 14:34:41','2025-07-14 14:34:41',NULL,NULL,NULL,'320ba9d9-714c-430d-afb1-8f1e19b676f5'),(45,29,NULL,23,4,'craft\\elements\\Entry',1,0,'2025-07-14 14:34:41','2025-07-14 14:34:41',NULL,NULL,NULL,'2c3dbcef-1e38-4ff7-88ef-256c6cfcf001'),(46,19,NULL,24,5,'craft\\elements\\Entry',1,0,'2025-07-14 19:49:42','2025-07-14 19:49:42',NULL,NULL,NULL,'d6abe6cd-d7d6-482a-8764-a58ae1bb39d5'),(49,NULL,NULL,NULL,7,'craft\\elements\\Entry',1,0,'2025-07-14 19:51:27','2025-07-18 21:49:19',NULL,'2025-07-18 21:49:19',NULL,'2ee47f4a-c548-4449-a20e-48be256ea3f4'),(50,19,NULL,25,5,'craft\\elements\\Entry',1,0,'2025-07-14 19:51:27','2025-07-14 19:51:27',NULL,NULL,NULL,'e47ca720-ca44-4477-9b8a-d6ec1be5353d'),(51,49,NULL,26,7,'craft\\elements\\Entry',1,0,'2025-07-14 19:51:27','2025-07-14 19:51:27',NULL,'2025-07-18 21:49:19',NULL,'cfd8f7a6-cd0f-4cd6-ae9d-a9852447efba'),(53,19,NULL,27,5,'craft\\elements\\Entry',1,0,'2025-07-14 19:53:57','2025-07-14 19:53:57',NULL,NULL,NULL,'1cad4eab-7c50-4dda-bcbc-a1c3a87b6964'),(56,19,NULL,28,5,'craft\\elements\\Entry',1,0,'2025-07-14 19:56:15','2025-07-14 19:56:15',NULL,NULL,NULL,'f1ff35f8-1e08-435e-856c-7bd3de634cca'),(59,19,NULL,29,5,'craft\\elements\\Entry',1,0,'2025-07-14 21:50:33','2025-07-14 21:50:33',NULL,NULL,NULL,'2eb8b796-33cb-43f1-9a10-875b30c4fa45'),(60,49,NULL,30,7,'craft\\elements\\Entry',1,0,'2025-07-14 21:50:33','2025-07-14 21:50:33',NULL,'2025-07-18 21:49:19',NULL,'62df8e53-c469-4326-98d1-6bfebd589afc'),(64,19,NULL,31,5,'craft\\elements\\Entry',1,0,'2025-07-14 22:22:04','2025-07-14 22:22:04',NULL,NULL,NULL,'b0eabfef-7933-441e-a374-12c5342020dd'),(65,49,NULL,32,7,'craft\\elements\\Entry',1,0,'2025-07-14 22:22:04','2025-07-14 22:22:04',NULL,'2025-07-18 21:49:19',NULL,'e05beb91-2f95-4dc3-857d-bd24fe5fe9ab'),(69,NULL,NULL,NULL,8,'craft\\elements\\Entry',1,0,'2025-07-18 20:09:19','2025-07-18 20:09:19',NULL,NULL,NULL,'57e5c2bf-78b8-4f62-8396-ad70b68a1b4d'),(70,19,NULL,33,5,'craft\\elements\\Entry',1,0,'2025-07-18 20:09:19','2025-07-18 20:09:19',NULL,NULL,NULL,'b1f1df73-cfa4-4537-9968-67ddc7c7cdd1'),(71,69,NULL,34,8,'craft\\elements\\Entry',1,0,'2025-07-18 20:09:19','2025-07-18 20:09:19',NULL,NULL,NULL,'fc80d85b-3aa1-4518-8b31-822ce84bce0d'),(75,NULL,NULL,NULL,9,'craft\\elements\\Entry',1,0,'2025-07-18 21:49:19','2025-07-18 21:49:19',NULL,NULL,NULL,'66a658b8-c781-4996-a80f-ddf578382e03'),(76,NULL,NULL,NULL,12,'craft\\elements\\Entry',1,0,'2025-07-18 21:49:19','2025-07-18 21:49:19',NULL,NULL,NULL,'9f007981-6b52-47dc-947e-b504b817d755'),(77,19,NULL,35,5,'craft\\elements\\Entry',1,0,'2025-07-18 21:49:19','2025-07-18 21:49:19',NULL,NULL,NULL,'853156ad-2fc4-4f44-a9b2-4e683fa6f2a6'),(78,75,NULL,36,9,'craft\\elements\\Entry',1,0,'2025-07-18 21:49:19','2025-07-18 21:49:19',NULL,NULL,NULL,'cb4265f6-b8f4-47fb-8b38-8b5c9d4d31c8'),(79,76,NULL,37,12,'craft\\elements\\Entry',1,0,'2025-07-18 21:49:19','2025-07-18 21:49:19',NULL,NULL,NULL,'20506ef9-4a64-4790-b5f4-e3d2eb3c93cb'),(82,NULL,NULL,NULL,9,'craft\\elements\\Entry',1,0,'2025-07-18 21:53:07','2025-07-20 14:03:21',NULL,'2025-07-20 14:03:21',NULL,'c6277661-2ceb-4f1c-9edb-9341382ce6d0'),(83,19,NULL,38,5,'craft\\elements\\Entry',1,0,'2025-07-18 21:53:07','2025-07-18 21:53:07',NULL,NULL,NULL,'019f5a0e-0802-41c4-8f17-365b2a015c0d'),(84,82,NULL,39,9,'craft\\elements\\Entry',1,0,'2025-07-18 21:53:07','2025-07-18 21:53:07',NULL,'2025-07-20 14:03:21',NULL,'da499ccc-5619-454a-976a-3dbdd3005ab0'),(87,NULL,NULL,NULL,9,'craft\\elements\\Entry',1,0,'2025-07-18 21:56:37','2025-07-18 21:56:37',NULL,NULL,NULL,'a15be755-7670-4a49-b016-61adc0463baa'),(88,19,NULL,40,5,'craft\\elements\\Entry',1,0,'2025-07-18 21:56:37','2025-07-18 21:56:37',NULL,NULL,NULL,'1bcca2b0-625e-4daf-bba7-b28828fd03a0'),(89,87,NULL,41,9,'craft\\elements\\Entry',1,0,'2025-07-18 21:56:37','2025-07-18 21:56:37',NULL,NULL,NULL,'b7c82b13-1c81-4dac-8656-70ecdfe01b10'),(93,NULL,NULL,NULL,13,'craft\\elements\\Entry',1,0,'2025-07-19 16:48:18','2025-07-19 16:48:18',NULL,NULL,NULL,'80b990d1-1d72-4ea9-8624-5bd046f1dc4a'),(94,NULL,NULL,NULL,9,'craft\\elements\\Entry',1,0,'2025-07-19 16:48:18','2025-07-19 16:48:18',NULL,NULL,NULL,'b9bff1e3-e184-4308-a2c7-1b0e972583ed'),(95,19,NULL,42,5,'craft\\elements\\Entry',1,0,'2025-07-19 16:48:18','2025-07-19 16:48:18',NULL,NULL,NULL,'d88fb933-e93c-451d-93e2-7a215baeb991'),(96,93,NULL,43,13,'craft\\elements\\Entry',1,0,'2025-07-19 16:48:18','2025-07-19 16:48:18',NULL,NULL,NULL,'21585f20-4d9b-4dc2-84d4-4e1c2bf1542c'),(97,94,NULL,44,9,'craft\\elements\\Entry',1,0,'2025-07-19 16:48:18','2025-07-19 16:48:18',NULL,NULL,NULL,'cdcc1fd4-e00b-4bca-b54b-242d4f7a62e7'),(100,NULL,NULL,NULL,8,'craft\\elements\\Entry',1,0,'2025-07-20 14:00:00','2025-07-20 14:00:16',NULL,'2025-07-20 14:00:16',NULL,'7cc5c96c-c4b9-4604-aee0-801b3958aae6'),(101,19,NULL,45,5,'craft\\elements\\Entry',1,0,'2025-07-20 14:00:00','2025-07-20 14:00:00',NULL,NULL,NULL,'d5682662-3c58-481b-a7a8-004862753147'),(102,100,NULL,46,8,'craft\\elements\\Entry',1,0,'2025-07-20 14:00:00','2025-07-20 14:00:00',NULL,'2025-07-20 14:00:16',NULL,'5469d14d-e108-4ddb-861c-976fd1db858b'),(105,NULL,NULL,NULL,14,'craft\\elements\\Entry',1,0,'2025-07-20 14:00:16','2025-07-20 14:00:16',NULL,NULL,NULL,'8ba6bc0c-e9cc-4627-b993-ee32ab6a1e7f'),(106,19,NULL,47,5,'craft\\elements\\Entry',1,0,'2025-07-20 14:00:16','2025-07-20 14:00:16',NULL,NULL,NULL,'311d0b66-9373-4261-b695-3c172e1af593'),(107,105,NULL,48,14,'craft\\elements\\Entry',1,0,'2025-07-20 14:00:16','2025-07-20 14:00:16',NULL,NULL,NULL,'50097084-ab73-4e0c-aefe-056daf3752d8'),(111,NULL,NULL,NULL,9,'craft\\elements\\Entry',1,0,'2025-07-20 14:03:21','2025-07-20 14:03:21',NULL,NULL,NULL,'63e6199e-aaf1-43a9-9057-fdc28410d441'),(112,NULL,NULL,NULL,11,'craft\\elements\\Entry',1,0,'2025-07-20 14:03:21','2025-07-20 14:03:21',NULL,NULL,NULL,'a1a3f1a5-b18c-4ed1-a90d-ffba99abbc72'),(113,19,NULL,49,5,'craft\\elements\\Entry',1,0,'2025-07-20 14:03:21','2025-07-20 14:03:21',NULL,NULL,NULL,'93a8e9a9-1f63-4fe6-9725-2b32865a10e4'),(114,111,NULL,50,9,'craft\\elements\\Entry',1,0,'2025-07-20 14:03:21','2025-07-20 14:03:21',NULL,NULL,NULL,'607fcb2e-361f-4bf5-a1ac-e713ccb43552'),(115,112,NULL,51,11,'craft\\elements\\Entry',1,0,'2025-07-20 14:03:21','2025-07-20 14:03:21',NULL,NULL,NULL,'93eb2232-4983-4663-8968-4554801730a6'),(120,NULL,NULL,NULL,16,'craft\\elements\\Entry',1,0,'2025-07-20 14:42:34','2025-07-20 14:42:34',NULL,NULL,NULL,'fdf4cb89-3d37-4ff6-9c7a-b259d9e58d46'),(121,NULL,NULL,NULL,15,'craft\\elements\\Entry',1,0,'2025-07-20 14:42:34','2025-07-20 14:42:34',NULL,NULL,NULL,'b3693b58-3d4c-49e6-84f2-463ee2cd2032'),(122,NULL,NULL,NULL,9,'craft\\elements\\Entry',1,0,'2025-07-20 14:42:34','2025-07-20 14:42:34',NULL,NULL,NULL,'4f285772-7b3a-4af9-ab58-563181a3b174'),(123,19,NULL,52,5,'craft\\elements\\Entry',1,0,'2025-07-20 14:42:34','2025-07-20 14:42:34',NULL,NULL,NULL,'a16167ea-7b0d-46fa-9834-b6fecfaa9cb1'),(124,120,NULL,53,16,'craft\\elements\\Entry',1,0,'2025-07-20 14:42:34','2025-07-20 14:42:34',NULL,NULL,NULL,'b25176f0-d5b8-4172-8e56-495f630b4e11'),(125,121,NULL,54,15,'craft\\elements\\Entry',1,0,'2025-07-20 14:42:34','2025-07-20 14:42:34',NULL,NULL,NULL,'b086207b-3853-4e36-8b6b-4b2e7bd82d2c'),(126,122,NULL,55,9,'craft\\elements\\Entry',1,0,'2025-07-20 14:42:34','2025-07-20 14:42:34',NULL,NULL,NULL,'4de6fe93-4561-44c0-b50e-0c1bd360aafe'),(129,NULL,NULL,NULL,16,'craft\\elements\\Entry',1,0,'2025-07-20 15:50:18','2025-07-20 15:50:18',NULL,NULL,NULL,'0307d471-ef0b-4f4e-9987-0a8f4801548c'),(130,19,NULL,56,5,'craft\\elements\\Entry',1,0,'2025-07-20 15:50:18','2025-07-20 15:50:18',NULL,NULL,NULL,'bd1edad2-6e6f-47b1-946d-f0ef08102070'),(131,129,NULL,57,16,'craft\\elements\\Entry',1,0,'2025-07-20 15:50:18','2025-07-20 15:50:18',NULL,NULL,NULL,'92ec0a46-d1db-4874-8af7-08d5e6014673'),(134,NULL,NULL,NULL,16,'craft\\elements\\Entry',1,0,'2025-07-20 15:50:53','2025-07-21 23:58:54',NULL,'2025-07-21 23:58:54',NULL,'901da3df-1103-463c-9552-4084142c3a88'),(135,19,NULL,58,5,'craft\\elements\\Entry',1,0,'2025-07-20 15:50:53','2025-07-20 15:50:53',NULL,NULL,NULL,'21f6c68f-9b00-4428-8532-88e72e7412fb'),(136,134,NULL,59,16,'craft\\elements\\Entry',1,0,'2025-07-20 15:50:53','2025-07-20 15:50:53',NULL,'2025-07-21 23:58:54',NULL,'8d34af0c-30c4-4390-92ec-15a31305f53e'),(138,19,NULL,60,5,'craft\\elements\\Entry',1,0,'2025-07-21 23:58:54','2025-07-21 23:58:54',NULL,NULL,NULL,'cc6aa2ea-6c10-4de6-ac97-3e5fe7239cf2'),(142,NULL,NULL,NULL,9,'craft\\elements\\Entry',1,0,'2025-07-25 21:16:42','2025-07-25 21:16:42',NULL,NULL,NULL,'e16abe7e-4363-476e-a73f-f3e8939fddd3'),(143,NULL,NULL,NULL,17,'craft\\elements\\Entry',1,0,'2025-07-25 21:16:42','2025-07-25 21:16:42',NULL,NULL,NULL,'c0105ad3-19a7-4e56-8e2e-1770e48ac6ae'),(144,19,NULL,61,5,'craft\\elements\\Entry',1,0,'2025-07-25 21:16:41','2025-07-25 21:16:42',NULL,NULL,NULL,'774539b3-3f01-4ab5-bc8d-1c1820c9334f'),(145,142,NULL,62,9,'craft\\elements\\Entry',1,0,'2025-07-25 21:16:42','2025-07-25 21:16:42',NULL,NULL,NULL,'3942d1e0-fabb-4b7f-8c56-a60d62cd5eb7'),(146,143,NULL,63,17,'craft\\elements\\Entry',1,0,'2025-07-25 21:16:42','2025-07-25 21:16:42',NULL,NULL,NULL,'58c8bc4e-dfcc-4183-ad1b-e02c22203a13');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_bulkops`
--

DROP TABLE IF EXISTS `elements_bulkops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_bulkops` (
  `elementId` int NOT NULL,
  `key` char(10) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`elementId`,`key`),
  KEY `idx_hldovgrykefoccjktxmimpbzcxtvbtchzgqe` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_bulkops`
--

LOCK TABLES `elements_bulkops` WRITE;
/*!40000 ALTER TABLE `elements_bulkops` DISABLE KEYS */;
/*!40000 ALTER TABLE `elements_bulkops` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_owners`
--

DROP TABLE IF EXISTS `elements_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_owners` (
  `elementId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`elementId`,`ownerId`),
  KEY `fk_ubuwxvacovdgnwtebxwlxxazktbmpqpeczgt` (`ownerId`),
  CONSTRAINT `fk_hiolwaygylbijgdyyoszkdtzqxpbhmhvlnjz` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ubuwxvacovdgnwtebxwlxxazktbmpqpeczgt` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_owners`
--

LOCK TABLES `elements_owners` WRITE;
/*!40000 ALTER TABLE `elements_owners` DISABLE KEYS */;
INSERT INTO `elements_owners` VALUES (29,19,2),(31,30,1),(31,33,1),(31,38,1),(42,19,1),(44,43,1),(44,46,1),(45,43,2),(45,46,2),(49,19,2),(51,50,1),(51,53,1),(51,56,1),(60,59,1),(65,64,1),(65,70,2),(69,19,4),(71,70,1),(71,77,1),(71,83,2),(71,88,2),(71,95,2),(71,101,3),(71,106,3),(71,113,4),(71,123,4),(71,130,4),(71,135,4),(71,138,4),(71,144,4),(75,19,5),(76,19,6),(78,77,2),(78,83,3),(78,88,3),(78,95,3),(78,101,4),(78,106,4),(78,113,5),(78,123,5),(78,130,5),(78,135,6),(78,138,5),(78,144,5),(79,77,3),(79,83,4),(79,88,4),(79,95,4),(79,101,5),(79,106,5),(79,113,6),(79,123,6),(79,130,6),(79,135,7),(79,138,6),(79,144,6),(82,19,2),(84,83,1),(84,88,1),(84,95,1),(84,101,2),(84,106,2),(87,19,9),(89,88,5),(89,95,5),(89,101,6),(89,106,6),(89,113,7),(89,123,7),(89,130,7),(89,135,8),(89,138,7),(89,144,9),(93,19,10),(94,19,11),(96,95,6),(96,101,7),(96,106,7),(96,113,8),(96,123,8),(96,130,8),(96,135,9),(96,138,8),(96,144,10),(97,95,7),(97,101,8),(97,106,8),(97,113,9),(97,123,9),(97,130,9),(97,135,10),(97,138,9),(97,144,11),(100,19,1),(102,101,1),(105,19,2),(107,106,1),(107,113,2),(107,123,2),(107,130,2),(107,135,2),(107,138,2),(107,144,2),(111,19,1),(112,19,3),(114,113,1),(114,123,1),(114,130,1),(114,135,1),(114,138,1),(114,144,1),(115,113,3),(115,123,3),(115,130,3),(115,135,3),(115,138,3),(115,144,3),(120,19,12),(121,19,13),(122,19,15),(124,123,10),(124,130,10),(124,135,11),(124,138,10),(124,144,12),(125,123,11),(125,130,11),(125,135,12),(125,138,11),(125,144,13),(126,123,12),(126,130,13),(126,135,14),(126,138,13),(126,144,15),(129,19,14),(131,130,12),(131,135,13),(131,138,12),(131,144,14),(134,19,5),(136,135,5),(142,19,7),(143,19,8),(145,144,7),(146,144,8);
/*!40000 ALTER TABLE `elements_owners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `content` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_gddsevlfssdutnzeztyqpjsbtbkpxlgmbzrk` (`elementId`,`siteId`),
  KEY `idx_mqrgkmclptbipvdyprckkwldpsqgbevtlujz` (`siteId`),
  KEY `idx_ktvllvmthpmfjcyaowhylkeibbdizilmtnfe` (`title`,`siteId`),
  KEY `idx_jmyfkzkzrslhkbuxzohxvncenajqcjxxiaub` (`slug`,`siteId`),
  KEY `idx_ihybijtkwfxxniorooeesioqasltkkyqhske` (`enabled`),
  KEY `idx_ggwtcwpmkcuiofxmpuepgcllxowhzawdhixi` (`uri`,`siteId`),
  CONSTRAINT `fk_hyppopyghcigiaoucsmyopqslasxjbobatfx` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ofnpptoqjhygcrehstdwgiwzizsjwrcyfwqk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=147 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,NULL,NULL,1,'2025-07-11 00:31:06','2025-07-11 00:31:06','e39b297b-883b-4207-988a-d25af49352fc'),(2,2,1,NULL,'__temp_qoyhdfklzdzmieppkemzthpkyryjgfxhrpfl',NULL,NULL,1,'2025-07-12 22:55:10','2025-07-12 22:55:10','3ecdd234-d6fb-4020-bc45-0ac9b030170d'),(3,3,1,'Hello!','hello',NULL,NULL,1,'2025-07-14 13:12:08','2025-07-14 13:17:59','1062d7e4-e952-4e7d-afd9-01ba8828cb5e'),(4,4,1,'Hello!','hello',NULL,NULL,1,'2025-07-14 13:12:14','2025-07-14 13:12:14','ec71752f-2dd6-478e-b727-3cf84eab63dd'),(5,5,1,'Hello!','hello','__home__',NULL,1,'2025-07-14 13:17:28','2025-07-14 13:17:28','8f05a0d6-7217-4bd7-964e-3ac72636ee54'),(6,6,1,'Hello!','hello','__home__',NULL,1,'2025-07-14 13:17:55','2025-07-14 13:17:55','5889e1aa-3822-4e90-b57a-d37b7eb1d945'),(7,7,1,'Hello!','hello',NULL,NULL,1,'2025-07-14 13:17:59','2025-07-14 13:17:59','85976ae9-459e-4d0b-924f-360d01c2355f'),(8,8,1,'Hello!','hello',NULL,NULL,1,'2025-07-14 13:18:31','2025-07-14 13:18:31','b0edcd66-57fa-4ee8-9586-e08b3ad48924'),(9,9,1,NULL,'pages',NULL,'{\"a8779ca3-468d-4dc2-8c29-53da9010a129\": \"Hello There!\"}',1,'2025-07-14 13:43:45','2025-07-14 13:46:52','49a4c8a0-f2ac-4d97-8834-d54cc8a71133'),(10,10,1,NULL,'pages','pages',NULL,1,'2025-07-14 13:43:45','2025-07-14 13:43:45','f1cac69a-6c00-4d50-9250-4daddb1acabb'),(12,12,1,NULL,'pages','pages','{\"a8779ca3-468d-4dc2-8c29-53da9010a129\": \"Hello There!\"}',1,'2025-07-14 13:44:08','2025-07-14 13:44:08','1d9c8f58-a5b4-4502-a0e2-b86449bf5fe4'),(13,13,1,NULL,'pages','__home__','{\"a8779ca3-468d-4dc2-8c29-53da9010a129\": \"Hello There!\"}',1,'2025-07-14 13:46:29','2025-07-14 13:46:29','f573811a-b37c-4dda-8bdd-6125531c9d2e'),(14,14,1,NULL,'pages',NULL,'{\"a8779ca3-468d-4dc2-8c29-53da9010a129\": \"Hello There!\"}',1,'2025-07-14 13:46:52','2025-07-14 13:46:52','f042297b-3727-45a6-8845-ae4c8e432beb'),(15,15,1,NULL,'example','example','{\"dd38f0c1-44d0-40a9-a228-b5ebe2ce0033\": \"Hello There!\"}',1,'2025-07-14 13:58:00','2025-07-14 14:01:39','b32ccef3-0411-41d9-a72d-a7f5364be187'),(16,16,1,'Example','example','example',NULL,1,'2025-07-14 13:58:00','2025-07-14 13:58:00','0e929f6c-8057-476e-9efd-bb1564ffc0cd'),(18,18,1,NULL,'example','example','{\"dd38f0c1-44d0-40a9-a228-b5ebe2ce0033\": \"Hello There!\"}',1,'2025-07-14 14:01:39','2025-07-14 14:01:39','9577f345-6d9b-4079-a783-c57b1a8d59ca'),(19,19,1,'About','about','about',NULL,1,'2025-07-14 14:18:27','2025-07-14 19:53:57','c500e7f8-6a1a-4369-a0e3-1d7cd557be7b'),(20,20,1,'Pages','pages','pages',NULL,1,'2025-07-14 14:18:27','2025-07-14 14:18:27','f3622551-56b2-420c-843b-c4ad23e5799c'),(23,23,1,'Pages','pages',NULL,NULL,1,'2025-07-14 14:19:21','2025-07-14 14:19:21','91e3aed3-9588-49f7-9ec8-09e09019f046'),(25,25,1,'Pages','pages','__home__',NULL,1,'2025-07-14 14:23:13','2025-07-14 14:23:13','f24aa900-691a-4a31-bc2a-80d6751c10b2'),(26,26,1,'Pages','pages','pages',NULL,1,'2025-07-14 14:25:58','2025-07-14 14:25:58','fc09e7f5-d020-42a6-8c3f-4e6e015a9092'),(27,27,1,'Pages','pages','pages',NULL,1,'2025-07-14 14:26:25','2025-07-14 14:26:25','058edf77-a273-4b65-81f6-e7a6ee09bbbf'),(28,28,1,NULL,'__temp_ppsdcbehmumbvoalwhhgqwwhwqgvubbfmyoc',NULL,NULL,1,'2025-07-14 14:26:52','2025-07-14 14:26:52','e43b171d-02a0-4ebd-a51d-b3f970553ebf'),(29,29,1,NULL,'__temp_cyvwaccosclkregvmeeogjawmrqhxoydmhnm',NULL,'{\"167cc395-5ff6-40f1-bdd4-db6422558910\": \"Lorem Ipsum Dolor And So Forth\"}',1,'2025-07-14 14:29:41','2025-07-14 14:34:41','aaf1c52e-02d6-485b-b0bc-f96da82e5623'),(30,30,1,'about','pages','pages',NULL,1,'2025-07-14 14:29:41','2025-07-14 14:29:41','781e98a8-f65c-4934-9f96-889c29a8d92c'),(31,31,1,NULL,NULL,NULL,'{\"167cc395-5ff6-40f1-bdd4-db6422558910\": \"Hello!\"}',1,'2025-07-14 14:29:41','2025-07-14 14:29:41','1b63ab2e-bb12-4cc1-a1cf-f0871a78e8c4'),(33,33,1,'about','about','about',NULL,1,'2025-07-14 14:30:53','2025-07-14 14:30:53','f2b43e10-4353-47ff-8307-cbc189b385e6'),(38,38,1,'about','about','about',NULL,1,'2025-07-14 14:32:32','2025-07-14 14:32:32','f22dde9b-97a8-45e0-bb69-5f5e04b70c40'),(42,42,1,NULL,'__temp_caofzksdoynnvfihjpgmsbmkeqsqzmerxmpl',NULL,'{\"58c7e4ea-89c9-42bf-a238-9fcd7acaa3b6\": \"Title\"}',1,'2025-07-14 14:34:41','2025-07-14 14:34:41','f9369d2a-8dad-4b0d-b146-126293cda664'),(43,43,1,'about','about','about',NULL,1,'2025-07-14 14:34:41','2025-07-14 14:34:41','4c815d25-8f77-4c1a-bf56-cf7bc34c37c2'),(44,44,1,NULL,'__temp_caofzksdoynnvfihjpgmsbmkeqsqzmerxmpl',NULL,'{\"58c7e4ea-89c9-42bf-a238-9fcd7acaa3b6\": \"Title\"}',1,'2025-07-14 14:34:41','2025-07-14 14:34:41','36ce31e6-2143-4d35-8ec9-de7971d178b8'),(45,45,1,NULL,'__temp_cyvwaccosclkregvmeeogjawmrqhxoydmhnm',NULL,'{\"167cc395-5ff6-40f1-bdd4-db6422558910\": \"Lorem Ipsum Dolor And So Forth\"}',1,'2025-07-14 14:34:41','2025-07-14 14:34:41','45889ada-5cda-4332-8a5b-b00bf7d91411'),(46,46,1,'about','about','about',NULL,1,'2025-07-14 19:49:42','2025-07-14 19:49:42','159797fa-9879-42c0-8f88-40158fd3cdd5'),(49,49,1,'Title','title',NULL,'{\"5209465d-7211-4f5d-a046-4cb112f49455\": \"This is a simple example component of using blocks for page construction.\"}',1,'2025-07-14 19:51:27','2025-07-14 22:22:04','80ce72d5-b963-467c-9dd8-083ffa4514db'),(50,50,1,'about','about','about',NULL,1,'2025-07-14 19:51:27','2025-07-14 19:51:27','f7db4707-d21e-464d-8178-9f507eb2758a'),(51,51,1,NULL,'__temp_optzdnhdpmtspkqbjkeiekgqutzexsuxzxjw',NULL,NULL,1,'2025-07-14 19:51:27','2025-07-14 19:51:27','a037bb33-7139-4ca2-8b38-7ec17c9dbd05'),(53,53,1,'About','about','about',NULL,1,'2025-07-14 19:53:57','2025-07-14 19:53:57','deab28a6-08d5-4a33-adbe-8aa29d80ffc5'),(56,56,1,'About','about','about',NULL,1,'2025-07-14 19:56:15','2025-07-14 19:56:15','218f718a-865c-4f6f-95fb-09cedcd2d266'),(59,59,1,'About','about','about',NULL,1,'2025-07-14 21:50:33','2025-07-14 21:50:33','7a22ac9f-bb95-411f-aa18-d5baa17fe857'),(60,60,1,'Title','title',NULL,'{\"5209465d-7211-4f5d-a046-4cb112f49455\": \"Once it’s in the layout, edit or create a Page entry—you’ll see a new field area titled Page Blocks with an Add button that lets editors insert “Text Block” (and any other blocks you enable later).\"}',1,'2025-07-14 21:50:33','2025-07-14 21:50:33','8da9a93d-2b71-45f9-a1e8-af8631487d7a'),(64,64,1,'About','about','about',NULL,1,'2025-07-14 22:22:04','2025-07-14 22:22:04','13939d73-d456-4702-9dab-479b558e0247'),(65,65,1,'Title','title',NULL,'{\"5209465d-7211-4f5d-a046-4cb112f49455\": \"This is a simple example component of using blocks for page construction.\"}',1,'2025-07-14 22:22:04','2025-07-14 22:22:04','045752e1-bd84-4f50-acc9-684ed538c00f'),(69,69,1,NULL,'__temp_ozfepvxozczzxvefqltudwdllyyfouceyabp',NULL,NULL,1,'2025-07-18 20:09:19','2025-07-18 20:09:19','cb604bbb-cd15-4b23-b4da-cfc70ccf72f8'),(70,70,1,'About','about','about',NULL,1,'2025-07-18 20:09:19','2025-07-18 20:09:19','63913a2a-b074-468c-b96c-1750cf7445a5'),(71,71,1,NULL,'__temp_ozfepvxozczzxvefqltudwdllyyfouceyabp',NULL,NULL,1,'2025-07-18 20:09:19','2025-07-18 20:09:19','0bf31b4e-b647-48c3-b9f1-ef6e4b0271a2'),(75,75,1,NULL,'__temp_gndyubgjmcfdfmjxmjpfdrxsukffzkitynlp',NULL,NULL,1,'2025-07-18 21:49:19','2025-07-18 21:49:19','fbc3c281-640c-4253-8a76-93b88295fde2'),(76,76,1,NULL,'placeholder',NULL,NULL,1,'2025-07-18 21:49:19','2025-07-20 14:09:10','d8145f25-f248-4980-90e9-f0f3355eec8e'),(77,77,1,'About','about','about',NULL,1,'2025-07-18 21:49:19','2025-07-18 21:49:19','403db936-e97f-4883-bad6-ed91e02f0679'),(78,78,1,NULL,'__temp_gndyubgjmcfdfmjxmjpfdrxsukffzkitynlp',NULL,NULL,1,'2025-07-18 21:49:19','2025-07-18 21:49:19','57a25bd7-8d1a-4e3a-9fce-84c55468106f'),(79,79,1,'Placeholder','placeholder',NULL,NULL,1,'2025-07-18 21:49:19','2025-07-18 21:49:19','0a765f9e-85bd-4f9b-bdde-a89621dc3442'),(82,82,1,NULL,'__temp_bfospfmlncesvouvhptufyfjvyudrtnbjvnz',NULL,NULL,1,'2025-07-18 21:53:07','2025-07-18 21:53:07','40b1cc15-158f-4eac-a3e2-72c84e757dfb'),(83,83,1,'About','about','about',NULL,1,'2025-07-18 21:53:07','2025-07-18 21:53:07','012eeaf0-4dac-44eb-b020-114b5f26650a'),(84,84,1,NULL,'__temp_bfospfmlncesvouvhptufyfjvyudrtnbjvnz',NULL,NULL,1,'2025-07-18 21:53:07','2025-07-18 21:53:07','572f6c24-09d5-4b5c-aacd-8c4bd3bbc18b'),(87,87,1,NULL,'__temp_ogltnwzzysmtzdwjahmhsfpgewnyawllzlzf',NULL,NULL,1,'2025-07-18 21:56:37','2025-07-18 21:56:37','3899b6ea-d578-44e5-b8d9-d22771bc6d53'),(88,88,1,'About','about','about',NULL,1,'2025-07-18 21:56:37','2025-07-18 21:56:37','97a640a8-7827-48cc-8b85-c3866b97c363'),(89,89,1,NULL,'__temp_ogltnwzzysmtzdwjahmhsfpgewnyawllzlzf',NULL,NULL,1,'2025-07-18 21:56:37','2025-07-18 21:56:37','ac4e29a7-d06b-423e-b743-ee7593a98221'),(93,93,1,NULL,'__temp_grisatfdlanszdsmqlumalulpzzwosxbhfcw',NULL,NULL,1,'2025-07-19 16:48:18','2025-07-19 16:48:18','6537ca3f-8244-4be6-a233-0d792fdfcd3d'),(94,94,1,NULL,'__temp_jjamsytndfmkbazedvsefzcbxqnwkllutjlh',NULL,NULL,1,'2025-07-19 16:48:18','2025-07-19 16:48:18','e501cf85-9c53-451e-b5e0-30b4c498f532'),(95,95,1,'About','about','about',NULL,1,'2025-07-19 16:48:18','2025-07-19 16:48:18','17c7170f-4139-4a7d-808a-3227d2a4899a'),(96,96,1,NULL,'__temp_grisatfdlanszdsmqlumalulpzzwosxbhfcw',NULL,NULL,1,'2025-07-19 16:48:18','2025-07-19 16:48:18','e0aed0c4-55e4-4803-ab03-3c8ac466a5e6'),(97,97,1,NULL,'__temp_jjamsytndfmkbazedvsefzcbxqnwkllutjlh',NULL,NULL,1,'2025-07-19 16:48:18','2025-07-19 16:48:18','692747a7-9f58-4b4b-b9f5-75c6724b0f60'),(100,100,1,NULL,'__temp_ensbixkpqeeqyugrvbonwwvlfwujukhafpsc',NULL,NULL,1,'2025-07-20 14:00:00','2025-07-20 14:00:00','f040481a-ff8d-4428-a74f-f91d4f360f38'),(101,101,1,'About','about','about',NULL,1,'2025-07-20 14:00:00','2025-07-20 14:00:00','fdf8a9df-e876-440d-afd2-b36d5878e6bb'),(102,102,1,NULL,'__temp_ensbixkpqeeqyugrvbonwwvlfwujukhafpsc',NULL,NULL,1,'2025-07-20 14:00:00','2025-07-20 14:00:00','b07526cf-80f3-433f-a3d4-347603fd6afd'),(105,105,1,NULL,'__temp_qhnjarggiyrhamkqyszgvdawekwlqddbckhm',NULL,NULL,1,'2025-07-20 14:00:16','2025-07-20 14:00:16','d02e491a-2f8f-4afa-ad26-5712e756e812'),(106,106,1,'About','about','about',NULL,1,'2025-07-20 14:00:16','2025-07-20 14:00:16','64e9f2d8-f794-4fb3-a8cd-d73098e19781'),(107,107,1,NULL,'__temp_qhnjarggiyrhamkqyszgvdawekwlqddbckhm',NULL,NULL,1,'2025-07-20 14:00:16','2025-07-20 14:00:16','0ae2af65-a820-49b8-99eb-2c6c1a15688e'),(111,111,1,NULL,'__temp_hectkcenyhwczbfmcqlegqvlvjeyajlvsrtz',NULL,NULL,1,'2025-07-20 14:03:21','2025-07-20 14:03:21','6179b713-23f0-4799-8f71-2c95f4d81d24'),(112,112,1,NULL,'placeholder',NULL,NULL,1,'2025-07-20 14:03:21','2025-07-20 14:08:36','fd00928a-0dd9-4258-80dd-6155d8f1fcd4'),(113,113,1,'About','about','about',NULL,1,'2025-07-20 14:03:21','2025-07-20 14:03:21','27f8a2ee-de2b-43e9-a718-349055d262f0'),(114,114,1,NULL,'__temp_hectkcenyhwczbfmcqlegqvlvjeyajlvsrtz',NULL,NULL,1,'2025-07-20 14:03:21','2025-07-20 14:03:21','bafa0212-adcf-4cfb-a737-059c8676dacd'),(115,115,1,'Placeholder','placeholder',NULL,NULL,1,'2025-07-20 14:03:21','2025-07-20 14:03:21','fd699621-2709-44cd-94d6-c8c7db5fb0ab'),(120,120,1,NULL,'__temp_ufstlzslglkspakvgvijgwepwuiocpqrlkhe',NULL,NULL,1,'2025-07-20 14:42:34','2025-07-20 14:42:34','e008cea8-ca4b-4081-bc81-92a7c965d480'),(121,121,1,NULL,'__temp_zqqmwjmyzacxqxuxcbemjwlqmdbvocayhiht',NULL,NULL,1,'2025-07-20 14:42:34','2025-07-20 14:42:34','4fde02e1-be04-4769-8000-b5c16d98e162'),(122,122,1,NULL,'__temp_mzawsgljhmqcnqbqdrvsiwticvixlbtzznjt',NULL,NULL,1,'2025-07-20 14:42:34','2025-07-20 14:42:34','b2f74300-3845-40b3-8518-8a9a06bb4217'),(123,123,1,'About','about','about',NULL,1,'2025-07-20 14:42:34','2025-07-20 14:42:34','6ba30349-f965-4e04-acea-9dac2887d5b0'),(124,124,1,NULL,'__temp_ufstlzslglkspakvgvijgwepwuiocpqrlkhe',NULL,NULL,1,'2025-07-20 14:42:34','2025-07-20 14:42:34','553bc81d-b8ed-483b-8680-eafeb06ef50c'),(125,125,1,NULL,'__temp_zqqmwjmyzacxqxuxcbemjwlqmdbvocayhiht',NULL,NULL,1,'2025-07-20 14:42:34','2025-07-20 14:42:34','3452736d-a2dc-4e3b-9b38-fb6eca41b841'),(126,126,1,NULL,'__temp_mzawsgljhmqcnqbqdrvsiwticvixlbtzznjt',NULL,NULL,1,'2025-07-20 14:42:34','2025-07-20 14:42:34','83de93f5-b7a5-4714-b4d0-1bd25e285cfb'),(129,129,1,NULL,'__temp_ldssqfulkherslmcpheypubodrnmdmrxvcim',NULL,NULL,1,'2025-07-20 15:50:18','2025-07-20 15:50:18','886ff8ca-8720-48df-aaf4-0c52ec98f9de'),(130,130,1,'About','about','about',NULL,1,'2025-07-20 15:50:18','2025-07-20 15:50:18','a56730b0-fb62-4481-a3a5-0b2a08a94675'),(131,131,1,NULL,'__temp_ldssqfulkherslmcpheypubodrnmdmrxvcim',NULL,NULL,1,'2025-07-20 15:50:18','2025-07-20 15:50:18','301214f7-0756-4a36-8455-c863f3ba265b'),(134,134,1,NULL,'__temp_xdfoijosclzsykhhriuqtcpddkwwzjgpserd',NULL,NULL,1,'2025-07-20 15:50:53','2025-07-20 15:50:53','a40ec05a-a591-4f93-85e2-9c2f7152dcf0'),(135,135,1,'About','about','about',NULL,1,'2025-07-20 15:50:53','2025-07-20 15:50:53','3f76d137-fa7b-440b-82b4-72c1741c8237'),(136,136,1,NULL,'__temp_xdfoijosclzsykhhriuqtcpddkwwzjgpserd',NULL,NULL,1,'2025-07-20 15:50:53','2025-07-20 15:50:53','b5fe90ee-8678-40be-8f2c-284a67d7b362'),(138,138,1,'About','about','about',NULL,1,'2025-07-21 23:58:54','2025-07-21 23:58:54','df54fa2c-881e-4e3f-ab25-ee7cbd0092c7'),(142,142,1,NULL,'__temp_ejgjejedcudwefsqmdfkwtqrklvmbnqgyaxv',NULL,NULL,1,'2025-07-25 21:16:42','2025-07-25 21:16:42','668bcf46-8621-4eb3-855e-9d51e80191a9'),(143,143,1,NULL,'__temp_rumyopjkezergdoxuwmogvsjqrjalubmopet',NULL,NULL,1,'2025-07-25 21:16:42','2025-07-25 21:16:42','e1ded07a-2c1c-4f9e-aed6-a4673b5428c7'),(144,144,1,'About','about','about',NULL,1,'2025-07-25 21:16:42','2025-07-25 21:16:42','a4556627-85f1-444b-8ef5-3db46d783fc4'),(145,145,1,NULL,'__temp_ejgjejedcudwefsqmdfkwtqrklvmbnqgyaxv',NULL,NULL,1,'2025-07-25 21:16:42','2025-07-25 21:16:42','c92409f6-28d7-48f8-b7dd-93c21a22ccc1'),(146,146,1,NULL,'__temp_rumyopjkezergdoxuwmogvsjqrjalubmopet',NULL,NULL,1,'2025-07-25 21:16:42','2025-07-25 21:16:42','1d8b5acf-0093-47ea-8ce2-79f41b6ef31a');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int DEFAULT NULL,
  `parentId` int DEFAULT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `status` enum('live','pending','expired') NOT NULL DEFAULT 'live',
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `deletedWithSection` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_xdfmlehupazowgwbwozalincoyvfiswpskrj` (`postDate`),
  KEY `idx_febmabtoknljzifwtxwmzmetewvpeskrnmoh` (`expiryDate`),
  KEY `idx_njdzoaiejtpcgkplkfaayizppsqogqdahccp` (`status`),
  KEY `idx_yzbjcgtizchfosjtyibmwmnqcjjtwwxzzxha` (`sectionId`),
  KEY `idx_tzzeajfbpthmdaclbnengxfkireivhiuiklp` (`typeId`),
  KEY `idx_eyvhorcfapqqkyxesgnqsxxjvlxyivwnjcwn` (`primaryOwnerId`),
  KEY `idx_zeswltqxmzbocmhvxeklzwwnwcpmczdkzbce` (`fieldId`),
  KEY `fk_ohqenuieaoschjyqztzztbspabpibzsfxtxl` (`parentId`),
  CONSTRAINT `fk_irruhwmdkqokoxhnhhoagtatoudjbqdzcjpv` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kkwznywnspshwwnsgcrkojsqgnirensxvdsy` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ohqenuieaoschjyqztzztbspabpibzsfxtxl` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_otuxtfmbxkcnrhkknkgxsrzjkjpscpixkwuk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rpawqrualehsnzbmiiytwdpuulfxkqpquejg` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_txjoshjqoswctdpettfupapbfyetzgerzpll` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
INSERT INTO `entries` VALUES (3,1,NULL,NULL,NULL,1,'2025-07-14 13:12:00',NULL,'live',NULL,1,'2025-07-14 13:12:08','2025-07-14 13:12:14'),(4,1,NULL,NULL,NULL,1,'2025-07-14 13:12:00',NULL,'live',NULL,NULL,'2025-07-14 13:12:14','2025-07-14 13:12:14'),(5,1,NULL,NULL,NULL,1,'2025-07-14 13:12:00',NULL,'live',NULL,NULL,'2025-07-14 13:17:28','2025-07-14 13:17:28'),(6,1,NULL,NULL,NULL,1,'2025-07-14 13:12:00',NULL,'live',NULL,NULL,'2025-07-14 13:17:55','2025-07-14 13:17:55'),(7,1,NULL,NULL,NULL,1,'2025-07-14 13:12:00',NULL,'live',NULL,NULL,'2025-07-14 13:17:59','2025-07-14 13:17:59'),(8,1,NULL,NULL,NULL,1,'2025-07-14 13:12:00',NULL,'live',NULL,NULL,'2025-07-14 13:18:31','2025-07-14 13:18:31'),(9,2,NULL,NULL,NULL,2,'2025-07-14 13:43:00',NULL,'live',NULL,1,'2025-07-14 13:43:45','2025-07-14 13:43:45'),(10,2,NULL,NULL,NULL,2,'2025-07-14 13:43:00',NULL,'live',NULL,NULL,'2025-07-14 13:43:45','2025-07-14 13:43:45'),(12,2,NULL,NULL,NULL,2,'2025-07-14 13:43:00',NULL,'live',NULL,NULL,'2025-07-14 13:44:08','2025-07-14 13:44:08'),(13,2,NULL,NULL,NULL,2,'2025-07-14 13:43:00',NULL,'live',NULL,NULL,'2025-07-14 13:46:29','2025-07-14 13:46:29'),(14,2,NULL,NULL,NULL,2,'2025-07-14 13:43:00',NULL,'live',NULL,NULL,'2025-07-14 13:46:52','2025-07-14 13:46:52'),(15,3,NULL,NULL,NULL,3,'2025-07-14 13:58:00',NULL,'live',NULL,1,'2025-07-14 13:58:00','2025-07-14 13:58:00'),(16,3,NULL,NULL,NULL,3,'2025-07-14 13:58:00',NULL,'live',NULL,NULL,'2025-07-14 13:58:00','2025-07-14 13:58:00'),(18,3,NULL,NULL,NULL,3,'2025-07-14 13:58:00',NULL,'live',NULL,NULL,'2025-07-14 14:01:39','2025-07-14 14:01:39'),(19,4,NULL,NULL,NULL,5,'2025-07-14 14:18:00',NULL,'live',NULL,NULL,'2025-07-14 14:18:27','2025-07-14 14:18:27'),(20,4,NULL,NULL,NULL,5,'2025-07-14 14:18:00',NULL,'live',NULL,NULL,'2025-07-14 14:18:27','2025-07-14 14:18:27'),(23,4,NULL,NULL,NULL,5,'2025-07-14 14:18:00',NULL,'live',NULL,NULL,'2025-07-14 14:19:21','2025-07-14 14:19:21'),(25,4,NULL,NULL,NULL,5,'2025-07-14 14:18:00',NULL,'live',NULL,NULL,'2025-07-14 14:23:13','2025-07-14 14:23:13'),(26,4,NULL,NULL,NULL,5,'2025-07-14 14:18:00',NULL,'live',NULL,NULL,'2025-07-14 14:25:58','2025-07-14 14:25:58'),(27,4,NULL,NULL,NULL,5,'2025-07-14 14:18:00',NULL,'live',NULL,NULL,'2025-07-14 14:26:25','2025-07-14 14:26:25'),(29,NULL,NULL,19,8,4,'2025-07-14 14:21:00',NULL,'live',1,NULL,'2025-07-14 14:29:41','2025-07-14 14:29:41'),(30,4,NULL,NULL,NULL,5,'2025-07-14 14:18:00',NULL,'live',NULL,NULL,'2025-07-14 14:29:41','2025-07-14 14:29:41'),(31,NULL,NULL,30,8,4,'2025-07-14 14:21:00',NULL,'live',NULL,NULL,'2025-07-14 14:29:41','2025-07-14 14:29:41'),(33,4,NULL,NULL,NULL,5,'2025-07-14 14:18:00',NULL,'live',NULL,NULL,'2025-07-14 14:30:53','2025-07-14 14:30:53'),(38,4,NULL,NULL,NULL,5,'2025-07-14 14:18:00',NULL,'live',NULL,NULL,'2025-07-14 14:32:32','2025-07-14 14:32:32'),(42,NULL,NULL,19,8,6,'2025-07-14 14:34:00',NULL,'live',1,NULL,'2025-07-14 14:34:41','2025-07-14 14:34:41'),(43,4,NULL,NULL,NULL,5,'2025-07-14 14:18:00',NULL,'live',NULL,NULL,'2025-07-14 14:34:41','2025-07-14 14:34:41'),(44,NULL,NULL,43,8,6,'2025-07-14 14:34:00',NULL,'live',NULL,NULL,'2025-07-14 14:34:41','2025-07-14 14:34:41'),(45,NULL,NULL,43,8,4,'2025-07-14 14:21:00',NULL,'live',NULL,NULL,'2025-07-14 14:34:41','2025-07-14 14:34:41'),(46,4,NULL,NULL,NULL,5,'2025-07-14 14:18:00',NULL,'live',NULL,NULL,'2025-07-14 19:49:42','2025-07-14 19:49:42'),(49,NULL,NULL,19,8,7,'2025-07-14 19:51:00',NULL,'live',0,0,'2025-07-14 19:51:27','2025-07-14 19:51:27'),(50,4,NULL,NULL,NULL,5,'2025-07-14 14:18:00',NULL,'live',NULL,NULL,'2025-07-14 19:51:27','2025-07-14 19:51:27'),(51,NULL,NULL,50,8,7,'2025-07-14 19:51:00',NULL,'live',NULL,NULL,'2025-07-14 19:51:27','2025-07-14 19:51:27'),(53,4,NULL,NULL,NULL,5,'2025-07-14 14:18:00',NULL,'live',NULL,NULL,'2025-07-14 19:53:57','2025-07-14 19:53:57'),(56,4,NULL,NULL,NULL,5,'2025-07-14 14:18:00',NULL,'live',NULL,NULL,'2025-07-14 19:56:15','2025-07-14 19:56:15'),(59,4,NULL,NULL,NULL,5,'2025-07-14 14:18:00',NULL,'live',NULL,NULL,'2025-07-14 21:50:33','2025-07-14 21:50:33'),(60,NULL,NULL,59,8,7,'2025-07-14 19:51:00',NULL,'live',NULL,NULL,'2025-07-14 21:50:33','2025-07-14 21:50:33'),(64,4,NULL,NULL,NULL,5,'2025-07-14 14:18:00',NULL,'live',NULL,NULL,'2025-07-14 22:22:04','2025-07-14 22:22:04'),(65,NULL,NULL,64,8,7,'2025-07-14 19:51:00',NULL,'live',NULL,NULL,'2025-07-14 22:22:04','2025-07-14 22:22:04'),(69,NULL,NULL,19,8,8,'2025-07-18 20:09:00',NULL,'live',NULL,NULL,'2025-07-18 20:09:19','2025-07-18 20:09:19'),(70,4,NULL,NULL,NULL,5,'2025-07-14 14:18:00',NULL,'live',NULL,NULL,'2025-07-18 20:09:19','2025-07-18 20:09:19'),(71,NULL,NULL,70,8,8,'2025-07-18 20:09:00',NULL,'live',NULL,NULL,'2025-07-18 20:09:19','2025-07-18 20:09:19'),(75,NULL,NULL,19,8,9,'2025-07-18 21:48:00',NULL,'live',NULL,NULL,'2025-07-18 21:49:19','2025-07-18 21:49:19'),(76,NULL,NULL,19,8,12,'2025-07-18 21:48:00',NULL,'live',NULL,NULL,'2025-07-18 21:49:19','2025-07-18 21:49:19'),(77,4,NULL,NULL,NULL,5,'2025-07-14 14:18:00',NULL,'live',NULL,NULL,'2025-07-18 21:49:19','2025-07-18 21:49:19'),(78,NULL,NULL,77,8,9,'2025-07-18 21:48:00',NULL,'live',NULL,NULL,'2025-07-18 21:49:19','2025-07-18 21:49:19'),(79,NULL,NULL,77,8,12,'2025-07-18 21:48:00',NULL,'live',NULL,NULL,'2025-07-18 21:49:19','2025-07-18 21:49:19'),(82,NULL,NULL,19,8,9,'2025-07-18 21:53:00',NULL,'live',0,0,'2025-07-18 21:53:07','2025-07-18 21:53:07'),(83,4,NULL,NULL,NULL,5,'2025-07-14 14:18:00',NULL,'live',NULL,NULL,'2025-07-18 21:53:07','2025-07-18 21:53:07'),(84,NULL,NULL,83,8,9,'2025-07-18 21:53:00',NULL,'live',NULL,NULL,'2025-07-18 21:53:07','2025-07-18 21:53:07'),(87,NULL,NULL,19,8,9,'2025-07-18 21:48:00',NULL,'live',NULL,NULL,'2025-07-18 21:56:37','2025-07-18 21:56:37'),(88,4,NULL,NULL,NULL,5,'2025-07-14 14:18:00',NULL,'live',NULL,NULL,'2025-07-18 21:56:37','2025-07-18 21:56:37'),(89,NULL,NULL,88,8,9,'2025-07-18 21:48:00',NULL,'live',NULL,NULL,'2025-07-18 21:56:37','2025-07-18 21:56:37'),(93,NULL,NULL,19,8,13,'2025-07-19 16:48:00',NULL,'live',NULL,NULL,'2025-07-19 16:48:18','2025-07-19 16:48:18'),(94,NULL,NULL,19,8,9,'2025-07-19 16:48:00',NULL,'live',NULL,NULL,'2025-07-19 16:48:18','2025-07-19 16:48:18'),(95,4,NULL,NULL,NULL,5,'2025-07-14 14:18:00',NULL,'live',NULL,NULL,'2025-07-19 16:48:18','2025-07-19 16:48:18'),(96,NULL,NULL,95,8,13,'2025-07-19 16:48:00',NULL,'live',NULL,NULL,'2025-07-19 16:48:18','2025-07-19 16:48:18'),(97,NULL,NULL,95,8,9,'2025-07-19 16:48:00',NULL,'live',NULL,NULL,'2025-07-19 16:48:18','2025-07-19 16:48:18'),(100,NULL,NULL,19,8,8,'2025-07-20 13:59:00',NULL,'live',0,0,'2025-07-20 14:00:00','2025-07-20 14:00:00'),(101,4,NULL,NULL,NULL,5,'2025-07-14 14:18:00',NULL,'live',NULL,NULL,'2025-07-20 14:00:00','2025-07-20 14:00:00'),(102,NULL,NULL,101,8,8,'2025-07-20 13:59:00',NULL,'live',NULL,NULL,'2025-07-20 14:00:00','2025-07-20 14:00:00'),(105,NULL,NULL,19,8,14,'2025-07-20 14:00:00',NULL,'live',NULL,NULL,'2025-07-20 14:00:16','2025-07-20 14:00:16'),(106,4,NULL,NULL,NULL,5,'2025-07-14 14:18:00',NULL,'live',NULL,NULL,'2025-07-20 14:00:16','2025-07-20 14:00:16'),(107,NULL,NULL,106,8,14,'2025-07-20 14:00:00',NULL,'live',NULL,NULL,'2025-07-20 14:00:16','2025-07-20 14:00:16'),(111,NULL,NULL,19,8,9,'2025-07-20 14:03:00',NULL,'live',NULL,NULL,'2025-07-20 14:03:21','2025-07-20 14:03:21'),(112,NULL,NULL,19,8,11,'2025-07-20 14:02:00',NULL,'live',NULL,NULL,'2025-07-20 14:03:21','2025-07-20 14:03:21'),(113,4,NULL,NULL,NULL,5,'2025-07-14 14:18:00',NULL,'live',NULL,NULL,'2025-07-20 14:03:21','2025-07-20 14:03:21'),(114,NULL,NULL,113,8,9,'2025-07-20 14:03:00',NULL,'live',NULL,NULL,'2025-07-20 14:03:21','2025-07-20 14:03:21'),(115,NULL,NULL,113,8,11,'2025-07-20 14:02:00',NULL,'live',NULL,NULL,'2025-07-20 14:03:21','2025-07-20 14:03:21'),(120,NULL,NULL,19,8,16,'2025-07-20 14:42:00',NULL,'live',NULL,NULL,'2025-07-20 14:42:34','2025-07-20 14:42:34'),(121,NULL,NULL,19,8,15,'2025-07-20 14:42:00',NULL,'live',NULL,NULL,'2025-07-20 14:42:34','2025-07-20 14:42:34'),(122,NULL,NULL,19,8,9,'2025-07-20 14:42:00',NULL,'live',NULL,NULL,'2025-07-20 14:42:34','2025-07-20 14:42:34'),(123,4,NULL,NULL,NULL,5,'2025-07-14 14:18:00',NULL,'live',NULL,NULL,'2025-07-20 14:42:34','2025-07-20 14:42:34'),(124,NULL,NULL,123,8,16,'2025-07-20 14:42:00',NULL,'live',NULL,NULL,'2025-07-20 14:42:34','2025-07-20 14:42:34'),(125,NULL,NULL,123,8,15,'2025-07-20 14:42:00',NULL,'live',NULL,NULL,'2025-07-20 14:42:34','2025-07-20 14:42:34'),(126,NULL,NULL,123,8,9,'2025-07-20 14:42:00',NULL,'live',NULL,NULL,'2025-07-20 14:42:34','2025-07-20 14:42:34'),(129,NULL,NULL,19,8,16,'2025-07-20 15:50:00',NULL,'live',NULL,NULL,'2025-07-20 15:50:18','2025-07-20 15:50:18'),(130,4,NULL,NULL,NULL,5,'2025-07-14 14:18:00',NULL,'live',NULL,NULL,'2025-07-20 15:50:18','2025-07-20 15:50:18'),(131,NULL,NULL,130,8,16,'2025-07-20 15:50:00',NULL,'live',NULL,NULL,'2025-07-20 15:50:18','2025-07-20 15:50:18'),(134,NULL,NULL,19,8,16,'2025-07-20 15:50:00',NULL,'live',0,0,'2025-07-20 15:50:53','2025-07-20 15:50:53'),(135,4,NULL,NULL,NULL,5,'2025-07-14 14:18:00',NULL,'live',NULL,NULL,'2025-07-20 15:50:53','2025-07-20 15:50:53'),(136,NULL,NULL,135,8,16,'2025-07-20 15:50:00',NULL,'live',NULL,NULL,'2025-07-20 15:50:53','2025-07-20 15:50:53'),(138,4,NULL,NULL,NULL,5,'2025-07-14 14:18:00',NULL,'live',NULL,NULL,'2025-07-21 23:58:54','2025-07-21 23:58:54'),(142,NULL,NULL,19,8,9,'2025-07-25 21:16:00',NULL,'live',NULL,NULL,'2025-07-25 21:16:42','2025-07-25 21:16:42'),(143,NULL,NULL,19,8,17,'2025-07-25 21:16:00',NULL,'live',NULL,NULL,'2025-07-25 21:16:42','2025-07-25 21:16:42'),(144,4,NULL,NULL,NULL,5,'2025-07-14 14:18:00',NULL,'live',NULL,NULL,'2025-07-25 21:16:42','2025-07-25 21:16:42'),(145,NULL,NULL,144,8,9,'2025-07-25 21:16:00',NULL,'live',NULL,NULL,'2025-07-25 21:16:42','2025-07-25 21:16:42'),(146,NULL,NULL,144,8,17,'2025-07-25 21:16:00',NULL,'live',NULL,NULL,'2025-07-25 21:16:42','2025-07-25 21:16:42');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries_authors`
--

DROP TABLE IF EXISTS `entries_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries_authors` (
  `entryId` int NOT NULL,
  `authorId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`entryId`,`authorId`),
  KEY `idx_kmhlwcajmlyrhalcxqndcpdkikkmliomgnec` (`authorId`),
  KEY `idx_nxjaghhjubdszffoytdqwolbvdudcbdfcwji` (`entryId`,`sortOrder`),
  CONSTRAINT `fk_xdmmoriakgjhjwwdjuofljwyvxjlafdsxyov` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zcdrudcbtsjxsdgbhgvgmjbtajhadjmmmavp` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries_authors`
--

LOCK TABLES `entries_authors` WRITE;
/*!40000 ALTER TABLE `entries_authors` DISABLE KEYS */;
/*!40000 ALTER TABLE `entries_authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `icon` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `showSlugField` tinyint(1) DEFAULT '1',
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text,
  `showStatusField` tinyint(1) DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_flxlkkavlkzmyivignifphymqwswbkusafsc` (`fieldLayoutId`),
  KEY `idx_otpztjciolvzqhstwhmcvslunsowrvdpadmz` (`dateDeleted`),
  CONSTRAINT `fk_jmdnegamqojqbtqzheassxzapwnyyelbqqrr` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
INSERT INTO `entrytypes` VALUES (1,1,'Module Text','moduleText',NULL,NULL,NULL,1,'site',NULL,NULL,1,'site',NULL,1,'2025-07-14 13:10:29','2025-07-14 13:10:29','2025-07-14 13:40:29','3d723127-b5b6-4f2e-b3c5-deb47aa322a3'),(2,2,'simpleTextModule','simpleTextModule',NULL,NULL,NULL,0,'site',NULL,NULL,1,'site',NULL,1,'2025-07-14 13:41:18','2025-07-14 13:41:18','2025-07-14 13:54:14','eda4010b-59ab-4309-85cb-021b125785da'),(3,3,'Text Block','textBlock',NULL,'font',NULL,0,'site',NULL,NULL,1,'site',NULL,1,'2025-07-14 13:56:56','2025-07-14 14:01:27','2025-07-14 14:04:53','364692a6-7c9c-4273-b3b2-a01425a05bee'),(4,4,'Text Block','textBlock',NULL,NULL,NULL,0,'site',NULL,NULL,1,'site',NULL,1,'2025-07-14 14:06:03','2025-07-14 14:06:03','2025-07-14 19:50:29','3ae99d80-78c3-4d7b-8751-cafe8811e019'),(5,5,'StandardPage','standardpage',NULL,'memo',NULL,1,'site',NULL,NULL,1,'site',NULL,1,'2025-07-14 14:17:22','2025-07-18 21:47:41',NULL,'aa15edf9-5fc0-40cc-8eb1-570557b0c72f'),(6,6,'Page Title','pageTitle',NULL,'heading',NULL,0,'site',NULL,NULL,1,'site',NULL,1,'2025-07-14 14:34:15','2025-07-14 14:34:15','2025-07-14 19:50:32','382944c2-a420-49ae-9417-2112aa0844cb'),(7,7,'exampleModule','examplemodule',NULL,'alien-8bit','purple',1,'site',NULL,NULL,1,'site',NULL,1,'2025-07-14 19:51:04','2025-07-14 21:45:08',NULL,'3158c64d-4653-44d7-8ef9-18f805862e13'),(8,8,'Grand Marquee','grandMarquee','Marquee component supporting a full width image on the background and modifiable copy. ','tv',NULL,0,'site',NULL,NULL,1,'site',NULL,1,'2025-07-18 20:08:44','2025-07-18 20:08:44',NULL,'cac287ab-f575-4bdf-9836-b06446a54504'),(9,9,'Large Spacer','spaceLG',NULL,'angles-up-down',NULL,0,'site',NULL,NULL,1,'site',NULL,1,'2025-07-18 21:45:14','2025-07-18 21:45:31',NULL,'0b791488-8988-45c1-b86f-3bd2a9d0f36e'),(10,10,'Medium Spacer','spaceMD',NULL,'angles-up-down',NULL,1,'site',NULL,NULL,1,'site',NULL,1,'2025-07-18 21:45:51','2025-07-18 21:45:51',NULL,'f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75'),(11,11,'Small Spacer','spaceSM',NULL,'angles-up-down',NULL,0,'site',NULL,NULL,1,'site',NULL,1,'2025-07-18 21:46:08','2025-07-20 14:08:36',NULL,'1e0e84fb-9ba3-41ec-87d0-22472b8c1ae9'),(12,12,'Aside Paragraph','asideParagraph',NULL,'align-right',NULL,0,'site',NULL,NULL,1,'site',NULL,1,'2025-07-18 21:48:26','2025-07-20 14:09:10',NULL,'b49dcac4-4dca-4e71-9925-c677816d034c'),(13,13,'Editorial Collage','editorialCollage',NULL,'objects-column',NULL,0,'site',NULL,NULL,1,'site',NULL,1,'2025-07-19 16:32:05','2025-07-19 16:32:05',NULL,'840e4b3e-cde9-4478-8400-f2e9f30c147c'),(14,14,'Billboard Split','billboardSplit',NULL,'billboard',NULL,0,'site',NULL,NULL,1,'site',NULL,1,'2025-07-20 13:59:36','2025-07-20 13:59:36',NULL,'b5253cdf-98b0-4938-9366-0b2d4914edb3'),(15,15,'Editorial Columns','editorialColumns',NULL,'newspaper',NULL,0,'site',NULL,NULL,1,'site',NULL,1,'2025-07-20 14:40:34','2025-07-20 14:40:34',NULL,'0ca218cb-9082-405d-93a1-5f3fe4324099'),(16,16,'Pattern Spacer','spacePattern',NULL,'pallet',NULL,0,'site',NULL,NULL,1,'site',NULL,1,'2025-07-20 14:41:34','2025-07-20 14:43:58',NULL,'0372f3ed-21a0-4fba-b318-c137111d8d27'),(17,17,'Cinema Slider','cinemaSlider',NULL,'rectangle-vertical-history',NULL,0,'site',NULL,NULL,1,'site',NULL,1,'2025-07-25 21:15:28','2025-07-25 21:15:28',NULL,'9655ee03-f1c7-4a52-b72b-f82b1e908aa7');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `config` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_lcmvuxpqgepvlysjdjpwtdlcdaznrjgcrnvc` (`dateDeleted`),
  KEY `idx_onevojealdwglkksthbbkzucichhmydhwhho` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"718a3666-231b-4a29-9331-3fba7a7c0ea5\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"0c5c1d30-3d0d-4b7e-b070-bd7d9577da1c\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"required\": true, \"dateAdded\": \"2025-07-14T13:08:36+00:00\", \"inputType\": null, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2025-07-14 13:10:29','2025-07-14 13:10:29','2025-07-14 13:40:29','23e84789-91cb-4a93-a7ab-de0c82eeae66'),(2,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"e784c994-d9f7-405d-a1ba-15381135b7c8\", \"name\": \"Content\", \"elements\": [{\"tip\": null, \"uid\": \"a8779ca3-468d-4dc2-8c29-53da9010a129\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"832335da-9886-493d-860a-62dec3f425c4\", \"required\": false, \"dateAdded\": \"2025-07-14T13:41:18+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2025-07-14 13:41:18','2025-07-14 13:41:18','2025-07-14 13:54:14','08ba9a02-9985-4f7b-8bfb-c74aad1ff1f4'),(3,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"a6e06d25-cdb6-47a3-8c48-c459a3b4829b\", \"name\": \"Content\", \"elements\": [{\"tip\": null, \"uid\": \"dd38f0c1-44d0-40a9-a228-b5ebe2ce0033\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"fd135243-e1d5-4555-a9af-19fc005ed000\", \"required\": false, \"dateAdded\": \"2025-07-14T14:01:27+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2025-07-14 13:56:56','2025-07-14 14:01:27','2025-07-14 14:04:53','9212a25b-f8a2-4c4d-a371-fe3cc32f47cd'),(4,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"22a18fd8-3c0a-445e-93c6-136ef6c83f37\", \"name\": \"Content\", \"elements\": [{\"tip\": null, \"uid\": \"167cc395-5ff6-40f1-bdd4-db6422558910\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"3e01de17-8376-411f-9a9d-770e001b25c9\", \"required\": false, \"dateAdded\": \"2025-07-14T14:06:03+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2025-07-14 14:06:03','2025-07-14 14:06:03','2025-07-14 19:50:29','993eea08-8d9d-4c41-a99b-b9088f2a91ca'),(5,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"9f250b8d-aff4-4ae4-a489-837de4db6f5e\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"3f70c556-5505-456d-9fab-63c1211eaa8a\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"required\": true, \"dateAdded\": \"2025-07-14T14:15:56+00:00\", \"inputType\": null, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"d3bc591f-f9b7-4396-9b96-a457a0186712\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"cf1c951a-5742-4fec-8a93-cac307d4f30b\", \"required\": false, \"dateAdded\": \"2025-07-14T14:17:22+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2025-07-14 14:17:22','2025-07-14 14:17:22',NULL,'5426a408-46cf-435b-a17e-247c0bda8b9b'),(6,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"2db18f1c-e20e-493b-be7d-eee27a90f2c8\", \"name\": \"Content\", \"elements\": [{\"tip\": null, \"uid\": \"58c7e4ea-89c9-42bf-a238-9fcd7acaa3b6\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"3e01de17-8376-411f-9a9d-770e001b25c9\", \"required\": false, \"dateAdded\": \"2025-07-14T14:34:15+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2025-07-14 14:34:15','2025-07-14 14:34:15','2025-07-14 19:50:32','f77083ba-3821-4d1a-9a4d-a2ee14cd0afc'),(7,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"27ba66a8-bdc1-4ffb-9ced-5f38d633813c\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"6add9de7-b6e3-428b-9fec-769a535c7d37\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"required\": true, \"dateAdded\": \"2025-07-14T21:45:08+00:00\", \"inputType\": null, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"5209465d-7211-4f5d-a046-4cb112f49455\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"84a55bd5-c2f1-47b7-974d-9bdb02209679\", \"required\": false, \"dateAdded\": \"2025-07-14T21:45:08+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2025-07-14 19:51:04','2025-07-14 21:45:08',NULL,'a2716d61-4dec-47e3-9cd1-f3c5b55aa979'),(8,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"cea4f451-8c71-41cb-8896-242ad1025c28\", \"name\": \"Content\", \"elements\": [], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2025-07-18 20:08:44','2025-07-18 20:08:44',NULL,'e803e5fb-035f-4e51-a26a-6410371fe5da'),(9,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"ea7c6992-e058-4287-ab25-e267b27a9b4c\", \"name\": \"Content\", \"elements\": [], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2025-07-18 21:45:14','2025-07-18 21:45:14',NULL,'ab8104b3-dce3-449e-aac7-32bdb6f900d2'),(10,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"3d391cc9-933b-49df-a27b-cb123f738fe0\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"4aab3bd6-bb76-460a-abc2-2b3a3c5c6fcf\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"required\": true, \"dateAdded\": \"2025-07-18T21:44:34+00:00\", \"inputType\": null, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2025-07-18 21:45:51','2025-07-18 21:45:51',NULL,'d0b49bea-7bc2-42ac-b727-fc48c1169125'),(11,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"1202c056-d5c4-4c3d-8bca-73d9575cd406\", \"name\": \"Content\", \"elements\": [], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2025-07-18 21:46:08','2025-07-20 14:08:36',NULL,'2fa0d3d2-d0c2-403f-8c4c-f8887a6177ef'),(12,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"7ea8807e-82d1-408a-bcd0-6b0e6cb1ad8f\", \"name\": \"Content\", \"elements\": [], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2025-07-18 21:48:26','2025-07-20 14:09:10',NULL,'65a82dfe-6080-465e-bb47-7c2cdaabdba2'),(13,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"bcd46de9-a5a2-4211-842d-9156a7c72b92\", \"name\": \"Content\", \"elements\": [], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2025-07-19 16:32:05','2025-07-19 16:32:05',NULL,'f34dca34-546a-4feb-857c-fbd7a4e5f509'),(14,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"52498aa0-4b32-4dec-afb7-81ad666eabb2\", \"name\": \"Content\", \"elements\": [], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2025-07-20 13:59:36','2025-07-20 13:59:36',NULL,'02f2aec1-b560-491d-b6ef-2bda4dc34903'),(15,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"126465ae-b60f-47b0-b5b0-87a7a56414b7\", \"name\": \"Content\", \"elements\": [], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2025-07-20 14:40:34','2025-07-20 14:40:34',NULL,'13004682-0f44-48b8-bc50-67c5ed58ce58'),(16,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"f05edd17-64c1-4310-ad03-6a090877e1ed\", \"name\": \"Content\", \"elements\": [], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2025-07-20 14:41:34','2025-07-20 14:41:34',NULL,'d14de5b2-3619-48cf-a0eb-b06a280300a0'),(17,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"a89fc1d6-e01c-4d29-ae99-e40d33b29808\", \"name\": \"Content\", \"elements\": [], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2025-07-25 21:15:28','2025-07-25 21:15:28',NULL,'f0173d49-02c4-4831-8ce2-ad98175da19a');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hfvmngpcryswxokancfnoqdqmmyomwbayadm` (`handle`,`context`),
  KEY `idx_msahoxfxuomcfxteiewwugpwsutyerfiiypa` (`context`),
  KEY `idx_ihsolnqrmamgplnxosdfcvgkzesrzpoqpoun` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
INSERT INTO `fields` VALUES (1,'Modules','modules','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Matrix','{\"createButtonLabel\":null,\"defaultIndexViewMode\":\"cards\",\"enableVersioning\":false,\"entryTypes\":[{\"uid\":\"3d723127-b5b6-4f2e-b3c5-deb47aa322a3\",\"group\":\"General\"}],\"includeTableView\":false,\"maxEntries\":null,\"minEntries\":null,\"pageSize\":50,\"propagationKeyFormat\":null,\"propagationMethod\":\"all\",\"showCardsInGrid\":false,\"viewMode\":\"cards\"}','2025-07-14 13:10:35','2025-07-14 13:10:35','2025-07-14 13:38:11','e2ac8342-3415-4487-af86-3f00c09eb210'),(2,'Example Field','exampleField','global',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2025-07-14 13:40:12','2025-07-14 13:40:12','2025-07-14 13:54:19','71daf00b-acd6-4bcc-a0cd-bbd31abb500c'),(3,'Body Text','bodyText','global',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2025-07-14 13:41:10','2025-07-14 13:41:10','2025-07-14 13:54:21','832335da-9886-493d-860a-62dec3f425c4'),(4,'Page Modules','pageModules','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Matrix','{\"createButtonLabel\":null,\"defaultIndexViewMode\":\"cards\",\"enableVersioning\":false,\"entryTypes\":[{\"uid\":\"eda4010b-59ab-4309-85cb-021b125785da\",\"group\":\"General\"}],\"includeTableView\":false,\"maxEntries\":null,\"minEntries\":null,\"pageSize\":50,\"propagationKeyFormat\":null,\"propagationMethod\":\"all\",\"showCardsInGrid\":false,\"viewMode\":\"cards\"}','2025-07-14 13:42:58','2025-07-14 13:42:58','2025-07-14 13:54:23','991026ae-1aeb-4cff-910b-b9c09589fa2c'),(5,'Page Builder','pageBuilder','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Matrix','{\"createButtonLabel\":null,\"defaultIndexViewMode\":\"cards\",\"enableVersioning\":false,\"entryTypes\":[{\"uid\":\"364692a6-7c9c-4273-b3b2-a01425a05bee\",\"group\":\"General\"}],\"includeTableView\":false,\"maxEntries\":null,\"minEntries\":null,\"pageSize\":50,\"propagationKeyFormat\":null,\"propagationMethod\":\"all\",\"showCardsInGrid\":false,\"viewMode\":\"cards\"}','2025-07-14 13:56:58','2025-07-14 13:56:58','2025-07-14 14:05:00','3d08fbd4-d732-4f72-8e39-2783c168d66d'),(6,'Body Text','bodyText','global',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2025-07-14 14:01:18','2025-07-14 14:01:18','2025-07-14 14:04:58','fd135243-e1d5-4555-a9af-19fc005ed000'),(7,'Body Text','bodyText','global',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2025-07-14 14:06:02','2025-07-14 14:06:02','2025-07-14 21:43:34','3e01de17-8376-411f-9a9d-770e001b25c9'),(8,'Page Blocks','pageBlocks','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Matrix','{\"createButtonLabel\":null,\"defaultIndexViewMode\":\"cards\",\"enableVersioning\":false,\"entryTypes\":[{\"uid\":\"3158c64d-4653-44d7-8ef9-18f805862e13\",\"name\":\"Example Module\",\"handle\":\"exampleModule\",\"description\":\"An example of how a module is built in Filament Boilerplate\",\"group\":\"General\"},{\"uid\":\"cac287ab-f575-4bdf-9836-b06446a54504\",\"group\":\"General\"},{\"uid\":\"0b791488-8988-45c1-b86f-3bd2a9d0f36e\",\"group\":\"General\"},{\"uid\":\"f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75\",\"group\":\"General\"},{\"uid\":\"1e0e84fb-9ba3-41ec-87d0-22472b8c1ae9\",\"group\":\"General\"},{\"uid\":\"b49dcac4-4dca-4e71-9925-c677816d034c\",\"group\":\"General\"},{\"uid\":\"840e4b3e-cde9-4478-8400-f2e9f30c147c\",\"group\":\"General\"},{\"uid\":\"b5253cdf-98b0-4938-9366-0b2d4914edb3\",\"group\":\"General\"},{\"uid\":\"0ca218cb-9082-405d-93a1-5f3fe4324099\",\"group\":\"General\"},{\"uid\":\"0372f3ed-21a0-4fba-b318-c137111d8d27\",\"group\":\"General\"},{\"uid\":\"9655ee03-f1c7-4a52-b72b-f82b1e908aa7\",\"group\":\"General\"}],\"includeTableView\":false,\"maxEntries\":null,\"minEntries\":null,\"pageSize\":null,\"propagationKeyFormat\":null,\"propagationMethod\":\"all\",\"showCardsInGrid\":false,\"viewMode\":\"blocks\"}','2025-07-14 14:06:56','2025-07-25 21:15:57',NULL,'cf1c951a-5742-4fec-8a93-cac307d4f30b'),(9,'Copy','copy','global',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2025-07-14 21:44:30','2025-07-14 21:44:30',NULL,'84a55bd5-c2f1-47b7-974d-9bdb02209679');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_boniyddoipzdscxojsphvfqcozauxypupacu` (`name`),
  KEY `idx_krmmutqgjabkzhwouvtxhlrkluiblziyvzia` (`handle`),
  KEY `idx_pniwmguuswvhfsfeizpkiuzkystxpxfwmnjg` (`fieldLayoutId`),
  KEY `idx_mlyynydugljogusjdwykedwaolzrsgppvdvw` (`sortOrder`),
  CONSTRAINT `fk_ohabiompsuwopqygibppcjqtuotnbhbqbmdd` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_uvegtejkoxtjeecthdylhnntvubxzdhptwrl` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` json DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
INSERT INTO `gqlschemas` VALUES (1,'Public Schema','[]',1,'2025-07-12 20:35:59','2025-07-12 20:35:59','2db1f353-5cc8-40db-b2de-583a39d92a64');
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xrjzwodzstlcelwcrcclbfqgrzzrcmexnceq` (`accessToken`),
  UNIQUE KEY `idx_fjxivswffjxtrqvbadannucdvlhizrmrvoof` (`name`),
  KEY `fk_dmmzywbkrsujjounjotzkrqjnngfvnhtbgef` (`schemaId`),
  CONSTRAINT `fk_dmmzywbkrsujjounjotzkrqjnngfvnhtbgef` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_sycmlaadnzzwmbvcpomysfemihdgfzvztgdm` (`assetId`,`transformString`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransformindex`
--

LOCK TABLES `imagetransformindex` WRITE;
/*!40000 ALTER TABLE `imagetransformindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransformindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hppopwcxwbnesxfzmxogourydanxesheaoak` (`name`),
  KEY `idx_tpqlazmahexmqfwtpgvnyuivbtferpqkrqzh` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
INSERT INTO `info` VALUES (1,'5.8.6','5.8.0.3',0,'iqpnsuoszbmz','3@mtithgxike','2025-07-11 00:31:06','2025-07-25 21:15:57','28169b9c-b9d0-49ae-bc28-c1bb3f742eef');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_uiekjeqdhjqlqqvjyvkgbalsdnypftfqqekl` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'craft','Install','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','46756af9-a7dd-4fa5-b774-4c681446c7f1'),(2,'craft','m221101_115859_create_entries_authors_table','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','7e325d1f-6a7e-41be-9663-1854f71912b6'),(3,'craft','m221107_112121_add_max_authors_to_sections','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','a6eaf395-4b74-41c7-95e9-1f3f22516d80'),(4,'craft','m221205_082005_translatable_asset_alt_text','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','a5ad253e-5ba6-47a7-916b-11d78ed366d8'),(5,'craft','m230314_110309_add_authenticator_table','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','af1fea8c-04d5-4fc6-8f58-f0e7669d12d8'),(6,'craft','m230314_111234_add_webauthn_table','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','9264d38a-62bf-4a93-9384-3bb93fcdd748'),(7,'craft','m230503_120303_add_recoverycodes_table','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','038407ec-16d0-4421-837b-15516b3ada19'),(8,'craft','m230511_000000_field_layout_configs','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','f8796eed-fe4b-4f7e-ad1d-f0238109969e'),(9,'craft','m230511_215903_content_refactor','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','b9227897-18a4-4179-a2af-49bf90d62fd3'),(10,'craft','m230524_000000_add_entry_type_show_slug_field','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','e3631f63-a6fa-441e-a13c-ddef2c583e0c'),(11,'craft','m230524_000001_entry_type_icons','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','70f47665-9228-4307-b80b-7c0837b19bdc'),(12,'craft','m230524_000002_entry_type_colors','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','295fef37-7d5d-4a66-893a-8ea532b5e1a1'),(13,'craft','m230524_220029_global_entry_types','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','0831282e-e254-45b9-9058-4256e4c2b188'),(14,'craft','m230531_123004_add_entry_type_show_status_field','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','39c573f5-7b67-44b6-8498-8646eacca61b'),(15,'craft','m230607_102049_add_entrytype_slug_translation_columns','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','4c6ad635-9b0c-433c-bd31-120c4f4cfc32'),(16,'craft','m230616_173810_kill_field_groups','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','f385e57a-b10d-4f34-b411-986041144fc3'),(17,'craft','m230616_183820_remove_field_name_limit','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','c648ca0c-2a75-4683-b0d4-5a351b6c13f2'),(18,'craft','m230617_070415_entrify_matrix_blocks','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','a84171c5-d0d3-4d36-a223-442e31f9e3ae'),(19,'craft','m230710_162700_element_activity','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','125e6ba3-838a-4ca1-9856-fd2e5f483469'),(20,'craft','m230820_162023_fix_cache_id_type','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','6c63fc82-ac47-44b5-a42f-5a39b57ed998'),(21,'craft','m230826_094050_fix_session_id_type','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','c1922140-8b1f-4021-a0fa-d2ae202aa4a5'),(22,'craft','m230904_190356_address_fields','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','6dbf61dd-e305-42ef-a8a7-2b080b00623c'),(23,'craft','m230928_144045_add_subpath_to_volumes','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','bdef0c83-65e9-47f9-b7be-1187416f54aa'),(24,'craft','m231013_185640_changedfields_amend_primary_key','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','1914c3e5-1fc2-411f-b177-f5fcc8fc085d'),(25,'craft','m231213_030600_element_bulk_ops','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','0f020147-d445-4a75-8fe5-d7bd9f2aa2ca'),(26,'craft','m240129_150719_sites_language_amend_length','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','45d58709-f0c3-45f9-87a9-66ba58ca20c3'),(27,'craft','m240206_035135_convert_json_columns','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','837045a2-7988-4dae-b92a-a3281b9ee494'),(28,'craft','m240207_182452_address_line_3','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','490c8ba3-553f-4d9a-9f4c-1eddcccab904'),(29,'craft','m240302_212719_solo_preview_targets','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','f100cdde-65c9-4b89-85d8-30da235cd4f0'),(30,'craft','m240619_091352_add_auth_2fa_timestamp','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','d09f2198-567a-45c5-840c-cda9c9b8c44e'),(31,'craft','m240723_214330_drop_bulkop_fk','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','e33d5c32-bfdd-4a6f-b7c0-2f4935c52908'),(32,'craft','m240731_053543_soft_delete_fields','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','65a8d9e7-0213-458e-a616-2a2921060e55'),(33,'craft','m240805_154041_sso_identities','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','6fa2c41c-72a2-4c0d-b6a6-adaf151cdf4d'),(34,'craft','m240926_202248_track_entries_deleted_with_section','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','79553366-5e9b-4df9-a034-023de7e47629'),(35,'craft','m241120_190905_user_affiliated_sites','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','64c6490e-8a9f-477a-a83d-4c2ec83f444c'),(36,'craft','m241125_122914_add_viewUsers_permission','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','2dca4d37-bdb1-4149-bfab-d3c9ac6445f9'),(37,'craft','m250119_135304_entry_type_overrides','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','46c70bcf-6dcb-4dda-be41-4ddc850a1c50'),(38,'craft','m250206_135036_search_index_queue','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','a16a5d7b-4aab-4561-9d78-c3bbe95db09e'),(39,'craft','m250207_172349_bulkop_events','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','1f46c934-ed47-4e97-8462-7ff426e01ce2'),(40,'craft','m250315_131608_unlimited_authors','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','44b54258-c10f-46ed-9fb1-6e0f1bfdcef4'),(41,'craft','m250403_171253_static_statuses','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','2ba8f2cf-fdfd-4104-90c9-3f5fe2e9b6a3'),(42,'craft','m250512_164202_asset_mime_types','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','24fa8b05-637c-4547-9fe3-e94b716375ca'),(43,'craft','m250522_090843_add_deleteEntriesForSite_and_deletePeerEntriesForSite_permissions','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','3955ac07-bec3-4b38-922e-74bb92558814'),(44,'craft','m250531_183058_content_blocks','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','00c5b7b6-82a4-4d78-b19a-5d192f5dbe33'),(45,'craft','m250623_105031_entry_type_descriptions','2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-11 00:31:06','43da7d2c-9552-46b4-b65a-a7ab8c668819'),(46,'plugin:servd-asset-storage','m201026_093810_update_servd_settings','2025-07-12 22:56:27','2025-07-12 22:56:27','2025-07-12 22:56:27','e20cb6cd-4894-4f96-85a1-071160a2b983'),(47,'plugin:servd-asset-storage','m201230_183610_copy_optimise_prefix','2025-07-12 22:56:27','2025-07-12 22:56:27','2025-07-12 22:56:27','d5a8c435-a1f0-4daa-b49a-31df52312b97'),(48,'plugin:servd-asset-storage','m220119_204628_update_fs_configs','2025-07-12 22:56:27','2025-07-12 22:56:27','2025-07-12 22:56:27','82b44167-88e2-4566-800b-b099c82860b0'),(49,'plugin:cp-nav','Install','2025-07-13 17:06:34','2025-07-13 17:06:34','2025-07-13 17:06:34','894f1a32-b8ec-4fc0-8662-1ca25d6bed49');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_albnnonjavdudhkvpjjnklbvyphiabvbflqw` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
INSERT INTO `plugins` VALUES (1,'vite','5.0.1','1.0.0','2025-07-11 21:36:51','2025-07-11 21:36:51','2025-07-11 21:36:51','995213e7-6bf0-41da-bf9f-a4137c09f393'),(2,'cp-css','3.0.0','2.0.0','2025-07-12 19:23:54','2025-07-12 19:23:54','2025-07-12 19:23:54','ecd093a3-d4df-492c-8fde-9bcd74889067'),(3,'servd-asset-storage','4.0.17','3.0.0','2025-07-12 22:56:27','2025-07-12 22:56:27','2025-07-12 22:56:27','90db9e36-08a7-4d83-9e26-f97accc1188e'),(4,'dashboard-begone','3.0.0','1.0.0','2025-07-12 23:03:57','2025-07-12 23:03:57','2025-07-12 23:03:57','e82621cd-c62b-4432-8a53-2228748c24c3'),(5,'cp-nav','5.0.4','2.0.11','2025-07-13 17:06:34','2025-07-13 17:06:34','2025-07-13 17:06:34','6232d04c-35c4-4189-a7ee-f82e19fa5521');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
INSERT INTO `projectconfig` VALUES ('cp-nav.layouts.161e35c5-199b-4d9c-b090-9dc1c61bc616.isDefault','true'),('cp-nav.layouts.161e35c5-199b-4d9c-b090-9dc1c61bc616.name','\"Default\"'),('cp-nav.layouts.161e35c5-199b-4d9c-b090-9dc1c61bc616.permissions','null'),('cp-nav.layouts.161e35c5-199b-4d9c-b090-9dc1c61bc616.sortOrder','1'),('cp-nav.navigations.20dcc96b-cb87-475a-a544-da0a6e504ee9.currLabel','\"Playbook\"'),('cp-nav.navigations.20dcc96b-cb87-475a-a544-da0a6e504ee9.customIcon','null'),('cp-nav.navigations.20dcc96b-cb87-475a-a544-da0a6e504ee9.enabled','true'),('cp-nav.navigations.20dcc96b-cb87-475a-a544-da0a6e504ee9.handle','\"visitPlaybook\"'),('cp-nav.navigations.20dcc96b-cb87-475a-a544-da0a6e504ee9.icon','\"scribble\"'),('cp-nav.navigations.20dcc96b-cb87-475a-a544-da0a6e504ee9.layout','\"161e35c5-199b-4d9c-b090-9dc1c61bc616\"'),('cp-nav.navigations.20dcc96b-cb87-475a-a544-da0a6e504ee9.level','1'),('cp-nav.navigations.20dcc96b-cb87-475a-a544-da0a6e504ee9.newWindow','false'),('cp-nav.navigations.20dcc96b-cb87-475a-a544-da0a6e504ee9.parent','null'),('cp-nav.navigations.20dcc96b-cb87-475a-a544-da0a6e504ee9.prevLabel','\"Visit Playbook\"'),('cp-nav.navigations.20dcc96b-cb87-475a-a544-da0a6e504ee9.prevLevel','null'),('cp-nav.navigations.20dcc96b-cb87-475a-a544-da0a6e504ee9.prevParent','null'),('cp-nav.navigations.20dcc96b-cb87-475a-a544-da0a6e504ee9.prevUrl','null'),('cp-nav.navigations.20dcc96b-cb87-475a-a544-da0a6e504ee9.sortOrder','7'),('cp-nav.navigations.20dcc96b-cb87-475a-a544-da0a6e504ee9.type','\"manual\"'),('cp-nav.navigations.20dcc96b-cb87-475a-a544-da0a6e504ee9.url','\"https://www.playbook.com/\"'),('cp-nav.navigations.30319499-fb4f-4280-9cf6-a80d8820de14.currLabel','\"Pages\"'),('cp-nav.navigations.30319499-fb4f-4280-9cf6-a80d8820de14.customIcon','null'),('cp-nav.navigations.30319499-fb4f-4280-9cf6-a80d8820de14.enabled','true'),('cp-nav.navigations.30319499-fb4f-4280-9cf6-a80d8820de14.handle','\"entries\"'),('cp-nav.navigations.30319499-fb4f-4280-9cf6-a80d8820de14.icon','\"newspaper\"'),('cp-nav.navigations.30319499-fb4f-4280-9cf6-a80d8820de14.layout','\"161e35c5-199b-4d9c-b090-9dc1c61bc616\"'),('cp-nav.navigations.30319499-fb4f-4280-9cf6-a80d8820de14.level','1'),('cp-nav.navigations.30319499-fb4f-4280-9cf6-a80d8820de14.newWindow','false'),('cp-nav.navigations.30319499-fb4f-4280-9cf6-a80d8820de14.parent','null'),('cp-nav.navigations.30319499-fb4f-4280-9cf6-a80d8820de14.prevLabel','\"Entries\"'),('cp-nav.navigations.30319499-fb4f-4280-9cf6-a80d8820de14.prevLevel','1'),('cp-nav.navigations.30319499-fb4f-4280-9cf6-a80d8820de14.prevParent','null'),('cp-nav.navigations.30319499-fb4f-4280-9cf6-a80d8820de14.prevUrl','\"entries\"'),('cp-nav.navigations.30319499-fb4f-4280-9cf6-a80d8820de14.sortOrder','1'),('cp-nav.navigations.30319499-fb4f-4280-9cf6-a80d8820de14.type','\"craft\"'),('cp-nav.navigations.30319499-fb4f-4280-9cf6-a80d8820de14.url','\"entries\"'),('cp-nav.navigations.3119091a-11eb-487e-b66f-2f9ce2ee3656.currLabel','\"Client\"'),('cp-nav.navigations.3119091a-11eb-487e-b66f-2f9ce2ee3656.customIcon','null'),('cp-nav.navigations.3119091a-11eb-487e-b66f-2f9ce2ee3656.enabled','true'),('cp-nav.navigations.3119091a-11eb-487e-b66f-2f9ce2ee3656.handle','\"client\"'),('cp-nav.navigations.3119091a-11eb-487e-b66f-2f9ce2ee3656.icon','null'),('cp-nav.navigations.3119091a-11eb-487e-b66f-2f9ce2ee3656.layout','\"161e35c5-199b-4d9c-b090-9dc1c61bc616\"'),('cp-nav.navigations.3119091a-11eb-487e-b66f-2f9ce2ee3656.level','1'),('cp-nav.navigations.3119091a-11eb-487e-b66f-2f9ce2ee3656.newWindow','false'),('cp-nav.navigations.3119091a-11eb-487e-b66f-2f9ce2ee3656.parent','null'),('cp-nav.navigations.3119091a-11eb-487e-b66f-2f9ce2ee3656.prevLabel','\"Client\"'),('cp-nav.navigations.3119091a-11eb-487e-b66f-2f9ce2ee3656.prevLevel','null'),('cp-nav.navigations.3119091a-11eb-487e-b66f-2f9ce2ee3656.prevParent','null'),('cp-nav.navigations.3119091a-11eb-487e-b66f-2f9ce2ee3656.prevUrl','null'),('cp-nav.navigations.3119091a-11eb-487e-b66f-2f9ce2ee3656.sortOrder','0'),('cp-nav.navigations.3119091a-11eb-487e-b66f-2f9ce2ee3656.type','\"divider\"'),('cp-nav.navigations.3119091a-11eb-487e-b66f-2f9ce2ee3656.url','null'),('cp-nav.navigations.31589d7d-c0b5-4e67-972a-d52ce78fbff6.currLabel','\"Dashboard\"'),('cp-nav.navigations.31589d7d-c0b5-4e67-972a-d52ce78fbff6.customIcon','null'),('cp-nav.navigations.31589d7d-c0b5-4e67-972a-d52ce78fbff6.enabled','false'),('cp-nav.navigations.31589d7d-c0b5-4e67-972a-d52ce78fbff6.handle','\"dashboard\"'),('cp-nav.navigations.31589d7d-c0b5-4e67-972a-d52ce78fbff6.icon','\"gauge\"'),('cp-nav.navigations.31589d7d-c0b5-4e67-972a-d52ce78fbff6.layout','\"161e35c5-199b-4d9c-b090-9dc1c61bc616\"'),('cp-nav.navigations.31589d7d-c0b5-4e67-972a-d52ce78fbff6.level','1'),('cp-nav.navigations.31589d7d-c0b5-4e67-972a-d52ce78fbff6.newWindow','false'),('cp-nav.navigations.31589d7d-c0b5-4e67-972a-d52ce78fbff6.parent','null'),('cp-nav.navigations.31589d7d-c0b5-4e67-972a-d52ce78fbff6.prevLabel','\"Dashboard\"'),('cp-nav.navigations.31589d7d-c0b5-4e67-972a-d52ce78fbff6.prevLevel','1'),('cp-nav.navigations.31589d7d-c0b5-4e67-972a-d52ce78fbff6.prevParent','null'),('cp-nav.navigations.31589d7d-c0b5-4e67-972a-d52ce78fbff6.prevUrl','\"dashboard\"'),('cp-nav.navigations.31589d7d-c0b5-4e67-972a-d52ce78fbff6.sortOrder','2'),('cp-nav.navigations.31589d7d-c0b5-4e67-972a-d52ce78fbff6.type','\"craft\"'),('cp-nav.navigations.31589d7d-c0b5-4e67-972a-d52ce78fbff6.url','\"dashboard\"'),('cp-nav.navigations.42b9e3ea-c132-4218-9a2d-926f70fec4f7.currLabel','\"GraphiQL\"'),('cp-nav.navigations.42b9e3ea-c132-4218-9a2d-926f70fec4f7.customIcon','null'),('cp-nav.navigations.42b9e3ea-c132-4218-9a2d-926f70fec4f7.enabled','true'),('cp-nav.navigations.42b9e3ea-c132-4218-9a2d-926f70fec4f7.handle','\"graphiql\"'),('cp-nav.navigations.42b9e3ea-c132-4218-9a2d-926f70fec4f7.icon','null'),('cp-nav.navigations.42b9e3ea-c132-4218-9a2d-926f70fec4f7.layout','\"161e35c5-199b-4d9c-b090-9dc1c61bc616\"'),('cp-nav.navigations.42b9e3ea-c132-4218-9a2d-926f70fec4f7.level','2'),('cp-nav.navigations.42b9e3ea-c132-4218-9a2d-926f70fec4f7.newWindow','true'),('cp-nav.navigations.42b9e3ea-c132-4218-9a2d-926f70fec4f7.parent','\"86963631-ab2b-409f-9f3e-83e7c91f7084\"'),('cp-nav.navigations.42b9e3ea-c132-4218-9a2d-926f70fec4f7.prevLabel','\"GraphiQL\"'),('cp-nav.navigations.42b9e3ea-c132-4218-9a2d-926f70fec4f7.prevLevel','2'),('cp-nav.navigations.42b9e3ea-c132-4218-9a2d-926f70fec4f7.prevParent','\"86963631-ab2b-409f-9f3e-83e7c91f7084\"'),('cp-nav.navigations.42b9e3ea-c132-4218-9a2d-926f70fec4f7.prevUrl','\"graphiql\"'),('cp-nav.navigations.42b9e3ea-c132-4218-9a2d-926f70fec4f7.sortOrder','6'),('cp-nav.navigations.42b9e3ea-c132-4218-9a2d-926f70fec4f7.type','\"craft\"'),('cp-nav.navigations.42b9e3ea-c132-4218-9a2d-926f70fec4f7.url','\"graphiql\"'),('cp-nav.navigations.469f73b6-5323-4852-918c-026e5c0c0934.currLabel','\"Utilities\"'),('cp-nav.navigations.469f73b6-5323-4852-918c-026e5c0c0934.customIcon','null'),('cp-nav.navigations.469f73b6-5323-4852-918c-026e5c0c0934.enabled','true'),('cp-nav.navigations.469f73b6-5323-4852-918c-026e5c0c0934.handle','\"utilities\"'),('cp-nav.navigations.469f73b6-5323-4852-918c-026e5c0c0934.icon','\"wrench\"'),('cp-nav.navigations.469f73b6-5323-4852-918c-026e5c0c0934.layout','\"161e35c5-199b-4d9c-b090-9dc1c61bc616\"'),('cp-nav.navigations.469f73b6-5323-4852-918c-026e5c0c0934.level','1'),('cp-nav.navigations.469f73b6-5323-4852-918c-026e5c0c0934.newWindow','false'),('cp-nav.navigations.469f73b6-5323-4852-918c-026e5c0c0934.parent','null'),('cp-nav.navigations.469f73b6-5323-4852-918c-026e5c0c0934.prevLabel','\"Utilities\"'),('cp-nav.navigations.469f73b6-5323-4852-918c-026e5c0c0934.prevLevel','1'),('cp-nav.navigations.469f73b6-5323-4852-918c-026e5c0c0934.prevParent','null'),('cp-nav.navigations.469f73b6-5323-4852-918c-026e5c0c0934.prevUrl','\"utilities\"'),('cp-nav.navigations.469f73b6-5323-4852-918c-026e5c0c0934.sortOrder','11'),('cp-nav.navigations.469f73b6-5323-4852-918c-026e5c0c0934.type','\"craft\"'),('cp-nav.navigations.469f73b6-5323-4852-918c-026e5c0c0934.url','\"utilities\"'),('cp-nav.navigations.477b3d18-a8e3-491e-8bfd-b8623f408866.currLabel','\"Tokens\"'),('cp-nav.navigations.477b3d18-a8e3-491e-8bfd-b8623f408866.customIcon','null'),('cp-nav.navigations.477b3d18-a8e3-491e-8bfd-b8623f408866.enabled','true'),('cp-nav.navigations.477b3d18-a8e3-491e-8bfd-b8623f408866.handle','\"tokens\"'),('cp-nav.navigations.477b3d18-a8e3-491e-8bfd-b8623f408866.icon','null'),('cp-nav.navigations.477b3d18-a8e3-491e-8bfd-b8623f408866.layout','\"161e35c5-199b-4d9c-b090-9dc1c61bc616\"'),('cp-nav.navigations.477b3d18-a8e3-491e-8bfd-b8623f408866.level','2'),('cp-nav.navigations.477b3d18-a8e3-491e-8bfd-b8623f408866.newWindow','false'),('cp-nav.navigations.477b3d18-a8e3-491e-8bfd-b8623f408866.parent','\"86963631-ab2b-409f-9f3e-83e7c91f7084\"'),('cp-nav.navigations.477b3d18-a8e3-491e-8bfd-b8623f408866.prevLabel','\"Tokens\"'),('cp-nav.navigations.477b3d18-a8e3-491e-8bfd-b8623f408866.prevLevel','2'),('cp-nav.navigations.477b3d18-a8e3-491e-8bfd-b8623f408866.prevParent','\"86963631-ab2b-409f-9f3e-83e7c91f7084\"'),('cp-nav.navigations.477b3d18-a8e3-491e-8bfd-b8623f408866.prevUrl','\"graphql/tokens\"'),('cp-nav.navigations.477b3d18-a8e3-491e-8bfd-b8623f408866.sortOrder','5'),('cp-nav.navigations.477b3d18-a8e3-491e-8bfd-b8623f408866.type','\"craft\"'),('cp-nav.navigations.477b3d18-a8e3-491e-8bfd-b8623f408866.url','\"graphql/tokens\"'),('cp-nav.navigations.5d80a675-d1b8-4cce-9eda-f1b84f7bcee5.currLabel','\"System\"'),('cp-nav.navigations.5d80a675-d1b8-4cce-9eda-f1b84f7bcee5.customIcon','null'),('cp-nav.navigations.5d80a675-d1b8-4cce-9eda-f1b84f7bcee5.enabled','true'),('cp-nav.navigations.5d80a675-d1b8-4cce-9eda-f1b84f7bcee5.handle','null'),('cp-nav.navigations.5d80a675-d1b8-4cce-9eda-f1b84f7bcee5.icon','null'),('cp-nav.navigations.5d80a675-d1b8-4cce-9eda-f1b84f7bcee5.layout','\"161e35c5-199b-4d9c-b090-9dc1c61bc616\"'),('cp-nav.navigations.5d80a675-d1b8-4cce-9eda-f1b84f7bcee5.level','1'),('cp-nav.navigations.5d80a675-d1b8-4cce-9eda-f1b84f7bcee5.newWindow','false'),('cp-nav.navigations.5d80a675-d1b8-4cce-9eda-f1b84f7bcee5.parent','null'),('cp-nav.navigations.5d80a675-d1b8-4cce-9eda-f1b84f7bcee5.prevLabel','null'),('cp-nav.navigations.5d80a675-d1b8-4cce-9eda-f1b84f7bcee5.prevLevel','null'),('cp-nav.navigations.5d80a675-d1b8-4cce-9eda-f1b84f7bcee5.prevParent','null'),('cp-nav.navigations.5d80a675-d1b8-4cce-9eda-f1b84f7bcee5.prevUrl','null'),('cp-nav.navigations.5d80a675-d1b8-4cce-9eda-f1b84f7bcee5.sortOrder','8'),('cp-nav.navigations.5d80a675-d1b8-4cce-9eda-f1b84f7bcee5.type','\"divider\"'),('cp-nav.navigations.5d80a675-d1b8-4cce-9eda-f1b84f7bcee5.url','null'),('cp-nav.navigations.86963631-ab2b-409f-9f3e-83e7c91f7084.currLabel','\"GraphQL\"'),('cp-nav.navigations.86963631-ab2b-409f-9f3e-83e7c91f7084.customIcon','null'),('cp-nav.navigations.86963631-ab2b-409f-9f3e-83e7c91f7084.enabled','false'),('cp-nav.navigations.86963631-ab2b-409f-9f3e-83e7c91f7084.handle','\"graphql\"'),('cp-nav.navigations.86963631-ab2b-409f-9f3e-83e7c91f7084.icon','\"graphql\"'),('cp-nav.navigations.86963631-ab2b-409f-9f3e-83e7c91f7084.layout','\"161e35c5-199b-4d9c-b090-9dc1c61bc616\"'),('cp-nav.navigations.86963631-ab2b-409f-9f3e-83e7c91f7084.level','1'),('cp-nav.navigations.86963631-ab2b-409f-9f3e-83e7c91f7084.newWindow','false'),('cp-nav.navigations.86963631-ab2b-409f-9f3e-83e7c91f7084.parent','null'),('cp-nav.navigations.86963631-ab2b-409f-9f3e-83e7c91f7084.prevLabel','\"GraphQL\"'),('cp-nav.navigations.86963631-ab2b-409f-9f3e-83e7c91f7084.prevLevel','1'),('cp-nav.navigations.86963631-ab2b-409f-9f3e-83e7c91f7084.prevParent','null'),('cp-nav.navigations.86963631-ab2b-409f-9f3e-83e7c91f7084.prevUrl','\"graphql\"'),('cp-nav.navigations.86963631-ab2b-409f-9f3e-83e7c91f7084.sortOrder','3'),('cp-nav.navigations.86963631-ab2b-409f-9f3e-83e7c91f7084.type','\"craft\"'),('cp-nav.navigations.86963631-ab2b-409f-9f3e-83e7c91f7084.url','\"graphql\"'),('cp-nav.navigations.cf6be2e2-2c83-4a6e-aa4a-50af959598d6.currLabel','\"Plugin Store\"'),('cp-nav.navigations.cf6be2e2-2c83-4a6e-aa4a-50af959598d6.customIcon','null'),('cp-nav.navigations.cf6be2e2-2c83-4a6e-aa4a-50af959598d6.enabled','true'),('cp-nav.navigations.cf6be2e2-2c83-4a6e-aa4a-50af959598d6.handle','\"plugin-store\"'),('cp-nav.navigations.cf6be2e2-2c83-4a6e-aa4a-50af959598d6.icon','\"plug\"'),('cp-nav.navigations.cf6be2e2-2c83-4a6e-aa4a-50af959598d6.layout','\"161e35c5-199b-4d9c-b090-9dc1c61bc616\"'),('cp-nav.navigations.cf6be2e2-2c83-4a6e-aa4a-50af959598d6.level','1'),('cp-nav.navigations.cf6be2e2-2c83-4a6e-aa4a-50af959598d6.newWindow','false'),('cp-nav.navigations.cf6be2e2-2c83-4a6e-aa4a-50af959598d6.parent','null'),('cp-nav.navigations.cf6be2e2-2c83-4a6e-aa4a-50af959598d6.prevLabel','\"Plugin Store\"'),('cp-nav.navigations.cf6be2e2-2c83-4a6e-aa4a-50af959598d6.prevLevel','1'),('cp-nav.navigations.cf6be2e2-2c83-4a6e-aa4a-50af959598d6.prevParent','null'),('cp-nav.navigations.cf6be2e2-2c83-4a6e-aa4a-50af959598d6.prevUrl','\"plugin-store\"'),('cp-nav.navigations.cf6be2e2-2c83-4a6e-aa4a-50af959598d6.sortOrder','9'),('cp-nav.navigations.cf6be2e2-2c83-4a6e-aa4a-50af959598d6.type','\"craft\"'),('cp-nav.navigations.cf6be2e2-2c83-4a6e-aa4a-50af959598d6.url','\"plugin-store\"'),('cp-nav.navigations.eb26a13f-064b-4fe8-a5e0-8bc90e2ea7d8.currLabel','\"Settings\"'),('cp-nav.navigations.eb26a13f-064b-4fe8-a5e0-8bc90e2ea7d8.customIcon','null'),('cp-nav.navigations.eb26a13f-064b-4fe8-a5e0-8bc90e2ea7d8.enabled','true'),('cp-nav.navigations.eb26a13f-064b-4fe8-a5e0-8bc90e2ea7d8.handle','\"settings\"'),('cp-nav.navigations.eb26a13f-064b-4fe8-a5e0-8bc90e2ea7d8.icon','\"gear\"'),('cp-nav.navigations.eb26a13f-064b-4fe8-a5e0-8bc90e2ea7d8.layout','\"161e35c5-199b-4d9c-b090-9dc1c61bc616\"'),('cp-nav.navigations.eb26a13f-064b-4fe8-a5e0-8bc90e2ea7d8.level','1'),('cp-nav.navigations.eb26a13f-064b-4fe8-a5e0-8bc90e2ea7d8.newWindow','false'),('cp-nav.navigations.eb26a13f-064b-4fe8-a5e0-8bc90e2ea7d8.parent','null'),('cp-nav.navigations.eb26a13f-064b-4fe8-a5e0-8bc90e2ea7d8.prevLabel','\"Settings\"'),('cp-nav.navigations.eb26a13f-064b-4fe8-a5e0-8bc90e2ea7d8.prevLevel','1'),('cp-nav.navigations.eb26a13f-064b-4fe8-a5e0-8bc90e2ea7d8.prevParent','null'),('cp-nav.navigations.eb26a13f-064b-4fe8-a5e0-8bc90e2ea7d8.prevUrl','\"settings\"'),('cp-nav.navigations.eb26a13f-064b-4fe8-a5e0-8bc90e2ea7d8.sortOrder','10'),('cp-nav.navigations.eb26a13f-064b-4fe8-a5e0-8bc90e2ea7d8.type','\"craft\"'),('cp-nav.navigations.eb26a13f-064b-4fe8-a5e0-8bc90e2ea7d8.url','\"settings\"'),('cp-nav.navigations.f769d927-37eb-455b-a3f4-894510f05932.currLabel','\"Schemas\"'),('cp-nav.navigations.f769d927-37eb-455b-a3f4-894510f05932.customIcon','null'),('cp-nav.navigations.f769d927-37eb-455b-a3f4-894510f05932.enabled','true'),('cp-nav.navigations.f769d927-37eb-455b-a3f4-894510f05932.handle','\"schemas\"'),('cp-nav.navigations.f769d927-37eb-455b-a3f4-894510f05932.icon','null'),('cp-nav.navigations.f769d927-37eb-455b-a3f4-894510f05932.layout','\"161e35c5-199b-4d9c-b090-9dc1c61bc616\"'),('cp-nav.navigations.f769d927-37eb-455b-a3f4-894510f05932.level','2'),('cp-nav.navigations.f769d927-37eb-455b-a3f4-894510f05932.newWindow','false'),('cp-nav.navigations.f769d927-37eb-455b-a3f4-894510f05932.parent','\"86963631-ab2b-409f-9f3e-83e7c91f7084\"'),('cp-nav.navigations.f769d927-37eb-455b-a3f4-894510f05932.prevLabel','\"Schemas\"'),('cp-nav.navigations.f769d927-37eb-455b-a3f4-894510f05932.prevLevel','2'),('cp-nav.navigations.f769d927-37eb-455b-a3f4-894510f05932.prevParent','\"86963631-ab2b-409f-9f3e-83e7c91f7084\"'),('cp-nav.navigations.f769d927-37eb-455b-a3f4-894510f05932.prevUrl','\"graphql/schemas\"'),('cp-nav.navigations.f769d927-37eb-455b-a3f4-894510f05932.sortOrder','4'),('cp-nav.navigations.f769d927-37eb-455b-a3f4-894510f05932.type','\"craft\"'),('cp-nav.navigations.f769d927-37eb-455b-a3f4-894510f05932.url','\"graphql/schemas\"'),('dateModified','1753478157'),('email.fromEmail','\"creative@raraavis.design\"'),('email.fromName','\"Filament-Boilerplate\"'),('email.replyToEmail','null'),('email.template','null'),('email.transportSettings.command','\"/usr/local/bin/mailpit sendmail -t --smtp-addr 127.0.0.1:1025\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('entryTypes.0372f3ed-21a0-4fba-b318-c137111d8d27.color','null'),('entryTypes.0372f3ed-21a0-4fba-b318-c137111d8d27.description','null'),('entryTypes.0372f3ed-21a0-4fba-b318-c137111d8d27.fieldLayouts.d14de5b2-3619-48cf-a0eb-b06a280300a0.cardThumbAlignment','\"end\"'),('entryTypes.0372f3ed-21a0-4fba-b318-c137111d8d27.fieldLayouts.d14de5b2-3619-48cf-a0eb-b06a280300a0.tabs.0.elementCondition','null'),('entryTypes.0372f3ed-21a0-4fba-b318-c137111d8d27.fieldLayouts.d14de5b2-3619-48cf-a0eb-b06a280300a0.tabs.0.name','\"Content\"'),('entryTypes.0372f3ed-21a0-4fba-b318-c137111d8d27.fieldLayouts.d14de5b2-3619-48cf-a0eb-b06a280300a0.tabs.0.uid','\"f05edd17-64c1-4310-ad03-6a090877e1ed\"'),('entryTypes.0372f3ed-21a0-4fba-b318-c137111d8d27.fieldLayouts.d14de5b2-3619-48cf-a0eb-b06a280300a0.tabs.0.userCondition','null'),('entryTypes.0372f3ed-21a0-4fba-b318-c137111d8d27.handle','\"spacePattern\"'),('entryTypes.0372f3ed-21a0-4fba-b318-c137111d8d27.hasTitleField','false'),('entryTypes.0372f3ed-21a0-4fba-b318-c137111d8d27.icon','\"pallet\"'),('entryTypes.0372f3ed-21a0-4fba-b318-c137111d8d27.name','\"Pattern Spacer\"'),('entryTypes.0372f3ed-21a0-4fba-b318-c137111d8d27.showSlugField','true'),('entryTypes.0372f3ed-21a0-4fba-b318-c137111d8d27.showStatusField','true'),('entryTypes.0372f3ed-21a0-4fba-b318-c137111d8d27.slugTranslationKeyFormat','null'),('entryTypes.0372f3ed-21a0-4fba-b318-c137111d8d27.slugTranslationMethod','\"site\"'),('entryTypes.0372f3ed-21a0-4fba-b318-c137111d8d27.titleFormat','null'),('entryTypes.0372f3ed-21a0-4fba-b318-c137111d8d27.titleTranslationKeyFormat','null'),('entryTypes.0372f3ed-21a0-4fba-b318-c137111d8d27.titleTranslationMethod','\"site\"'),('entryTypes.0b791488-8988-45c1-b86f-3bd2a9d0f36e.color','null'),('entryTypes.0b791488-8988-45c1-b86f-3bd2a9d0f36e.description','null'),('entryTypes.0b791488-8988-45c1-b86f-3bd2a9d0f36e.fieldLayouts.ab8104b3-dce3-449e-aac7-32bdb6f900d2.cardThumbAlignment','\"end\"'),('entryTypes.0b791488-8988-45c1-b86f-3bd2a9d0f36e.fieldLayouts.ab8104b3-dce3-449e-aac7-32bdb6f900d2.tabs.0.elementCondition','null'),('entryTypes.0b791488-8988-45c1-b86f-3bd2a9d0f36e.fieldLayouts.ab8104b3-dce3-449e-aac7-32bdb6f900d2.tabs.0.name','\"Content\"'),('entryTypes.0b791488-8988-45c1-b86f-3bd2a9d0f36e.fieldLayouts.ab8104b3-dce3-449e-aac7-32bdb6f900d2.tabs.0.uid','\"ea7c6992-e058-4287-ab25-e267b27a9b4c\"'),('entryTypes.0b791488-8988-45c1-b86f-3bd2a9d0f36e.fieldLayouts.ab8104b3-dce3-449e-aac7-32bdb6f900d2.tabs.0.userCondition','null'),('entryTypes.0b791488-8988-45c1-b86f-3bd2a9d0f36e.handle','\"spaceLG\"'),('entryTypes.0b791488-8988-45c1-b86f-3bd2a9d0f36e.hasTitleField','false'),('entryTypes.0b791488-8988-45c1-b86f-3bd2a9d0f36e.icon','\"angles-up-down\"'),('entryTypes.0b791488-8988-45c1-b86f-3bd2a9d0f36e.name','\"Large Spacer\"'),('entryTypes.0b791488-8988-45c1-b86f-3bd2a9d0f36e.showSlugField','true'),('entryTypes.0b791488-8988-45c1-b86f-3bd2a9d0f36e.showStatusField','true'),('entryTypes.0b791488-8988-45c1-b86f-3bd2a9d0f36e.slugTranslationKeyFormat','null'),('entryTypes.0b791488-8988-45c1-b86f-3bd2a9d0f36e.slugTranslationMethod','\"site\"'),('entryTypes.0b791488-8988-45c1-b86f-3bd2a9d0f36e.titleFormat','null'),('entryTypes.0b791488-8988-45c1-b86f-3bd2a9d0f36e.titleTranslationKeyFormat','null'),('entryTypes.0b791488-8988-45c1-b86f-3bd2a9d0f36e.titleTranslationMethod','\"site\"'),('entryTypes.0ca218cb-9082-405d-93a1-5f3fe4324099.color','null'),('entryTypes.0ca218cb-9082-405d-93a1-5f3fe4324099.description','null'),('entryTypes.0ca218cb-9082-405d-93a1-5f3fe4324099.fieldLayouts.13004682-0f44-48b8-bc50-67c5ed58ce58.cardThumbAlignment','\"end\"'),('entryTypes.0ca218cb-9082-405d-93a1-5f3fe4324099.fieldLayouts.13004682-0f44-48b8-bc50-67c5ed58ce58.tabs.0.elementCondition','null'),('entryTypes.0ca218cb-9082-405d-93a1-5f3fe4324099.fieldLayouts.13004682-0f44-48b8-bc50-67c5ed58ce58.tabs.0.name','\"Content\"'),('entryTypes.0ca218cb-9082-405d-93a1-5f3fe4324099.fieldLayouts.13004682-0f44-48b8-bc50-67c5ed58ce58.tabs.0.uid','\"126465ae-b60f-47b0-b5b0-87a7a56414b7\"'),('entryTypes.0ca218cb-9082-405d-93a1-5f3fe4324099.fieldLayouts.13004682-0f44-48b8-bc50-67c5ed58ce58.tabs.0.userCondition','null'),('entryTypes.0ca218cb-9082-405d-93a1-5f3fe4324099.handle','\"editorialColumns\"'),('entryTypes.0ca218cb-9082-405d-93a1-5f3fe4324099.hasTitleField','false'),('entryTypes.0ca218cb-9082-405d-93a1-5f3fe4324099.icon','\"newspaper\"'),('entryTypes.0ca218cb-9082-405d-93a1-5f3fe4324099.name','\"Editorial Columns\"'),('entryTypes.0ca218cb-9082-405d-93a1-5f3fe4324099.showSlugField','true'),('entryTypes.0ca218cb-9082-405d-93a1-5f3fe4324099.showStatusField','true'),('entryTypes.0ca218cb-9082-405d-93a1-5f3fe4324099.slugTranslationKeyFormat','null'),('entryTypes.0ca218cb-9082-405d-93a1-5f3fe4324099.slugTranslationMethod','\"site\"'),('entryTypes.0ca218cb-9082-405d-93a1-5f3fe4324099.titleFormat','null'),('entryTypes.0ca218cb-9082-405d-93a1-5f3fe4324099.titleTranslationKeyFormat','null'),('entryTypes.0ca218cb-9082-405d-93a1-5f3fe4324099.titleTranslationMethod','\"site\"'),('entryTypes.1e0e84fb-9ba3-41ec-87d0-22472b8c1ae9.color','null'),('entryTypes.1e0e84fb-9ba3-41ec-87d0-22472b8c1ae9.description','null'),('entryTypes.1e0e84fb-9ba3-41ec-87d0-22472b8c1ae9.fieldLayouts.2fa0d3d2-d0c2-403f-8c4c-f8887a6177ef.cardThumbAlignment','\"end\"'),('entryTypes.1e0e84fb-9ba3-41ec-87d0-22472b8c1ae9.fieldLayouts.2fa0d3d2-d0c2-403f-8c4c-f8887a6177ef.tabs.0.elementCondition','null'),('entryTypes.1e0e84fb-9ba3-41ec-87d0-22472b8c1ae9.fieldLayouts.2fa0d3d2-d0c2-403f-8c4c-f8887a6177ef.tabs.0.name','\"Content\"'),('entryTypes.1e0e84fb-9ba3-41ec-87d0-22472b8c1ae9.fieldLayouts.2fa0d3d2-d0c2-403f-8c4c-f8887a6177ef.tabs.0.uid','\"1202c056-d5c4-4c3d-8bca-73d9575cd406\"'),('entryTypes.1e0e84fb-9ba3-41ec-87d0-22472b8c1ae9.fieldLayouts.2fa0d3d2-d0c2-403f-8c4c-f8887a6177ef.tabs.0.userCondition','null'),('entryTypes.1e0e84fb-9ba3-41ec-87d0-22472b8c1ae9.handle','\"spaceSM\"'),('entryTypes.1e0e84fb-9ba3-41ec-87d0-22472b8c1ae9.hasTitleField','false'),('entryTypes.1e0e84fb-9ba3-41ec-87d0-22472b8c1ae9.icon','\"angles-up-down\"'),('entryTypes.1e0e84fb-9ba3-41ec-87d0-22472b8c1ae9.name','\"Small Spacer\"'),('entryTypes.1e0e84fb-9ba3-41ec-87d0-22472b8c1ae9.showSlugField','true'),('entryTypes.1e0e84fb-9ba3-41ec-87d0-22472b8c1ae9.showStatusField','true'),('entryTypes.1e0e84fb-9ba3-41ec-87d0-22472b8c1ae9.slugTranslationKeyFormat','null'),('entryTypes.1e0e84fb-9ba3-41ec-87d0-22472b8c1ae9.slugTranslationMethod','\"site\"'),('entryTypes.1e0e84fb-9ba3-41ec-87d0-22472b8c1ae9.titleFormat','null'),('entryTypes.1e0e84fb-9ba3-41ec-87d0-22472b8c1ae9.titleTranslationKeyFormat','null'),('entryTypes.1e0e84fb-9ba3-41ec-87d0-22472b8c1ae9.titleTranslationMethod','\"site\"'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.color','\"purple\"'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.description','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.cardThumbAlignment','\"end\"'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elementCondition','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.0.autocapitalize','true'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.0.autocomplete','false'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.0.autocorrect','true'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.0.class','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.0.dateAdded','\"2025-07-14T21:45:08+00:00\"'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.0.disabled','false'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.0.elementCondition','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.0.id','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.0.includeInCards','false'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.0.inputType','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.0.instructions','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.0.label','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.0.max','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.0.min','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.0.name','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.0.orientation','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.0.placeholder','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.0.providesThumbs','false'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.0.readonly','false'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.0.required','true'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.0.size','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.0.step','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.0.tip','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.0.title','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.0.uid','\"6add9de7-b6e3-428b-9fec-769a535c7d37\"'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.0.userCondition','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.0.warning','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.0.width','100'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.1.dateAdded','\"2025-07-14T21:45:08+00:00\"'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.1.editCondition','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.1.elementCondition','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.1.fieldUid','\"84a55bd5-c2f1-47b7-974d-9bdb02209679\"'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.1.handle','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.1.includeInCards','false'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.1.instructions','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.1.label','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.1.providesThumbs','false'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.1.required','false'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.1.tip','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.1.uid','\"5209465d-7211-4f5d-a046-4cb112f49455\"'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.1.userCondition','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.1.warning','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.elements.1.width','100'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.name','\"Content\"'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.uid','\"27ba66a8-bdc1-4ffb-9ced-5f38d633813c\"'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.fieldLayouts.a2716d61-4dec-47e3-9cd1-f3c5b55aa979.tabs.0.userCondition','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.handle','\"examplemodule\"'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.hasTitleField','true'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.icon','\"alien-8bit\"'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.name','\"exampleModule\"'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.showSlugField','true'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.showStatusField','true'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.slugTranslationKeyFormat','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.slugTranslationMethod','\"site\"'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.titleFormat','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.titleTranslationKeyFormat','null'),('entryTypes.3158c64d-4653-44d7-8ef9-18f805862e13.titleTranslationMethod','\"site\"'),('entryTypes.840e4b3e-cde9-4478-8400-f2e9f30c147c.color','null'),('entryTypes.840e4b3e-cde9-4478-8400-f2e9f30c147c.description','null'),('entryTypes.840e4b3e-cde9-4478-8400-f2e9f30c147c.fieldLayouts.f34dca34-546a-4feb-857c-fbd7a4e5f509.cardThumbAlignment','\"end\"'),('entryTypes.840e4b3e-cde9-4478-8400-f2e9f30c147c.fieldLayouts.f34dca34-546a-4feb-857c-fbd7a4e5f509.tabs.0.elementCondition','null'),('entryTypes.840e4b3e-cde9-4478-8400-f2e9f30c147c.fieldLayouts.f34dca34-546a-4feb-857c-fbd7a4e5f509.tabs.0.name','\"Content\"'),('entryTypes.840e4b3e-cde9-4478-8400-f2e9f30c147c.fieldLayouts.f34dca34-546a-4feb-857c-fbd7a4e5f509.tabs.0.uid','\"bcd46de9-a5a2-4211-842d-9156a7c72b92\"'),('entryTypes.840e4b3e-cde9-4478-8400-f2e9f30c147c.fieldLayouts.f34dca34-546a-4feb-857c-fbd7a4e5f509.tabs.0.userCondition','null'),('entryTypes.840e4b3e-cde9-4478-8400-f2e9f30c147c.handle','\"editorialCollage\"'),('entryTypes.840e4b3e-cde9-4478-8400-f2e9f30c147c.hasTitleField','false'),('entryTypes.840e4b3e-cde9-4478-8400-f2e9f30c147c.icon','\"objects-column\"'),('entryTypes.840e4b3e-cde9-4478-8400-f2e9f30c147c.name','\"Editorial Collage\"'),('entryTypes.840e4b3e-cde9-4478-8400-f2e9f30c147c.showSlugField','true'),('entryTypes.840e4b3e-cde9-4478-8400-f2e9f30c147c.showStatusField','true'),('entryTypes.840e4b3e-cde9-4478-8400-f2e9f30c147c.slugTranslationKeyFormat','null'),('entryTypes.840e4b3e-cde9-4478-8400-f2e9f30c147c.slugTranslationMethod','\"site\"'),('entryTypes.840e4b3e-cde9-4478-8400-f2e9f30c147c.titleFormat','null'),('entryTypes.840e4b3e-cde9-4478-8400-f2e9f30c147c.titleTranslationKeyFormat','null'),('entryTypes.840e4b3e-cde9-4478-8400-f2e9f30c147c.titleTranslationMethod','\"site\"'),('entryTypes.9655ee03-f1c7-4a52-b72b-f82b1e908aa7.color','null'),('entryTypes.9655ee03-f1c7-4a52-b72b-f82b1e908aa7.description','null'),('entryTypes.9655ee03-f1c7-4a52-b72b-f82b1e908aa7.fieldLayouts.f0173d49-02c4-4831-8ce2-ad98175da19a.cardThumbAlignment','\"end\"'),('entryTypes.9655ee03-f1c7-4a52-b72b-f82b1e908aa7.fieldLayouts.f0173d49-02c4-4831-8ce2-ad98175da19a.tabs.0.elementCondition','null'),('entryTypes.9655ee03-f1c7-4a52-b72b-f82b1e908aa7.fieldLayouts.f0173d49-02c4-4831-8ce2-ad98175da19a.tabs.0.name','\"Content\"'),('entryTypes.9655ee03-f1c7-4a52-b72b-f82b1e908aa7.fieldLayouts.f0173d49-02c4-4831-8ce2-ad98175da19a.tabs.0.uid','\"a89fc1d6-e01c-4d29-ae99-e40d33b29808\"'),('entryTypes.9655ee03-f1c7-4a52-b72b-f82b1e908aa7.fieldLayouts.f0173d49-02c4-4831-8ce2-ad98175da19a.tabs.0.userCondition','null'),('entryTypes.9655ee03-f1c7-4a52-b72b-f82b1e908aa7.handle','\"cinemaSlider\"'),('entryTypes.9655ee03-f1c7-4a52-b72b-f82b1e908aa7.hasTitleField','false'),('entryTypes.9655ee03-f1c7-4a52-b72b-f82b1e908aa7.icon','\"rectangle-vertical-history\"'),('entryTypes.9655ee03-f1c7-4a52-b72b-f82b1e908aa7.name','\"Cinema Slider\"'),('entryTypes.9655ee03-f1c7-4a52-b72b-f82b1e908aa7.showSlugField','true'),('entryTypes.9655ee03-f1c7-4a52-b72b-f82b1e908aa7.showStatusField','true'),('entryTypes.9655ee03-f1c7-4a52-b72b-f82b1e908aa7.slugTranslationKeyFormat','null'),('entryTypes.9655ee03-f1c7-4a52-b72b-f82b1e908aa7.slugTranslationMethod','\"site\"'),('entryTypes.9655ee03-f1c7-4a52-b72b-f82b1e908aa7.titleFormat','null'),('entryTypes.9655ee03-f1c7-4a52-b72b-f82b1e908aa7.titleTranslationKeyFormat','null'),('entryTypes.9655ee03-f1c7-4a52-b72b-f82b1e908aa7.titleTranslationMethod','\"site\"'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.color','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.description','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.cardThumbAlignment','\"end\"'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elementCondition','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.0.autocapitalize','true'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.0.autocomplete','false'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.0.autocorrect','true'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.0.class','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.0.dateAdded','\"2025-07-14T14:15:56+00:00\"'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.0.disabled','false'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.0.elementCondition','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.0.id','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.0.includeInCards','false'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.0.inputType','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.0.instructions','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.0.label','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.0.max','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.0.min','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.0.name','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.0.orientation','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.0.placeholder','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.0.providesThumbs','false'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.0.readonly','false'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.0.required','true'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.0.size','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.0.step','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.0.tip','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.0.title','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.0.uid','\"3f70c556-5505-456d-9fab-63c1211eaa8a\"'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.0.userCondition','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.0.warning','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.0.width','100'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.1.dateAdded','\"2025-07-14T14:17:22+00:00\"'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.1.editCondition','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.1.elementCondition','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.1.fieldUid','\"cf1c951a-5742-4fec-8a93-cac307d4f30b\"'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.1.handle','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.1.includeInCards','false'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.1.instructions','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.1.label','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.1.providesThumbs','false'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.1.required','false'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.1.tip','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.1.uid','\"d3bc591f-f9b7-4396-9b96-a457a0186712\"'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.1.userCondition','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.1.warning','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.elements.1.width','100'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.name','\"Content\"'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.uid','\"9f250b8d-aff4-4ae4-a489-837de4db6f5e\"'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.fieldLayouts.5426a408-46cf-435b-a17e-247c0bda8b9b.tabs.0.userCondition','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.handle','\"standardpage\"'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.hasTitleField','true'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.icon','\"memo\"'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.name','\"StandardPage\"'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.showSlugField','true'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.showStatusField','true'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.slugTranslationKeyFormat','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.slugTranslationMethod','\"site\"'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.titleFormat','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.titleTranslationKeyFormat','null'),('entryTypes.aa15edf9-5fc0-40cc-8eb1-570557b0c72f.titleTranslationMethod','\"site\"'),('entryTypes.b49dcac4-4dca-4e71-9925-c677816d034c.color','null'),('entryTypes.b49dcac4-4dca-4e71-9925-c677816d034c.description','null'),('entryTypes.b49dcac4-4dca-4e71-9925-c677816d034c.fieldLayouts.65a82dfe-6080-465e-bb47-7c2cdaabdba2.cardThumbAlignment','\"end\"'),('entryTypes.b49dcac4-4dca-4e71-9925-c677816d034c.fieldLayouts.65a82dfe-6080-465e-bb47-7c2cdaabdba2.tabs.0.elementCondition','null'),('entryTypes.b49dcac4-4dca-4e71-9925-c677816d034c.fieldLayouts.65a82dfe-6080-465e-bb47-7c2cdaabdba2.tabs.0.name','\"Content\"'),('entryTypes.b49dcac4-4dca-4e71-9925-c677816d034c.fieldLayouts.65a82dfe-6080-465e-bb47-7c2cdaabdba2.tabs.0.uid','\"7ea8807e-82d1-408a-bcd0-6b0e6cb1ad8f\"'),('entryTypes.b49dcac4-4dca-4e71-9925-c677816d034c.fieldLayouts.65a82dfe-6080-465e-bb47-7c2cdaabdba2.tabs.0.userCondition','null'),('entryTypes.b49dcac4-4dca-4e71-9925-c677816d034c.handle','\"asideParagraph\"'),('entryTypes.b49dcac4-4dca-4e71-9925-c677816d034c.hasTitleField','false'),('entryTypes.b49dcac4-4dca-4e71-9925-c677816d034c.icon','\"align-right\"'),('entryTypes.b49dcac4-4dca-4e71-9925-c677816d034c.name','\"Aside Paragraph\"'),('entryTypes.b49dcac4-4dca-4e71-9925-c677816d034c.showSlugField','true'),('entryTypes.b49dcac4-4dca-4e71-9925-c677816d034c.showStatusField','true'),('entryTypes.b49dcac4-4dca-4e71-9925-c677816d034c.slugTranslationKeyFormat','null'),('entryTypes.b49dcac4-4dca-4e71-9925-c677816d034c.slugTranslationMethod','\"site\"'),('entryTypes.b49dcac4-4dca-4e71-9925-c677816d034c.titleFormat','null'),('entryTypes.b49dcac4-4dca-4e71-9925-c677816d034c.titleTranslationKeyFormat','null'),('entryTypes.b49dcac4-4dca-4e71-9925-c677816d034c.titleTranslationMethod','\"site\"'),('entryTypes.b5253cdf-98b0-4938-9366-0b2d4914edb3.color','null'),('entryTypes.b5253cdf-98b0-4938-9366-0b2d4914edb3.description','null'),('entryTypes.b5253cdf-98b0-4938-9366-0b2d4914edb3.fieldLayouts.02f2aec1-b560-491d-b6ef-2bda4dc34903.cardThumbAlignment','\"end\"'),('entryTypes.b5253cdf-98b0-4938-9366-0b2d4914edb3.fieldLayouts.02f2aec1-b560-491d-b6ef-2bda4dc34903.tabs.0.elementCondition','null'),('entryTypes.b5253cdf-98b0-4938-9366-0b2d4914edb3.fieldLayouts.02f2aec1-b560-491d-b6ef-2bda4dc34903.tabs.0.name','\"Content\"'),('entryTypes.b5253cdf-98b0-4938-9366-0b2d4914edb3.fieldLayouts.02f2aec1-b560-491d-b6ef-2bda4dc34903.tabs.0.uid','\"52498aa0-4b32-4dec-afb7-81ad666eabb2\"'),('entryTypes.b5253cdf-98b0-4938-9366-0b2d4914edb3.fieldLayouts.02f2aec1-b560-491d-b6ef-2bda4dc34903.tabs.0.userCondition','null'),('entryTypes.b5253cdf-98b0-4938-9366-0b2d4914edb3.handle','\"billboardSplit\"'),('entryTypes.b5253cdf-98b0-4938-9366-0b2d4914edb3.hasTitleField','false'),('entryTypes.b5253cdf-98b0-4938-9366-0b2d4914edb3.icon','\"billboard\"'),('entryTypes.b5253cdf-98b0-4938-9366-0b2d4914edb3.name','\"Billboard Split\"'),('entryTypes.b5253cdf-98b0-4938-9366-0b2d4914edb3.showSlugField','true'),('entryTypes.b5253cdf-98b0-4938-9366-0b2d4914edb3.showStatusField','true'),('entryTypes.b5253cdf-98b0-4938-9366-0b2d4914edb3.slugTranslationKeyFormat','null'),('entryTypes.b5253cdf-98b0-4938-9366-0b2d4914edb3.slugTranslationMethod','\"site\"'),('entryTypes.b5253cdf-98b0-4938-9366-0b2d4914edb3.titleFormat','null'),('entryTypes.b5253cdf-98b0-4938-9366-0b2d4914edb3.titleTranslationKeyFormat','null'),('entryTypes.b5253cdf-98b0-4938-9366-0b2d4914edb3.titleTranslationMethod','\"site\"'),('entryTypes.cac287ab-f575-4bdf-9836-b06446a54504.color','null'),('entryTypes.cac287ab-f575-4bdf-9836-b06446a54504.description','\"Marquee component supporting a full width image on the background and modifiable copy. \"'),('entryTypes.cac287ab-f575-4bdf-9836-b06446a54504.fieldLayouts.e803e5fb-035f-4e51-a26a-6410371fe5da.cardThumbAlignment','\"end\"'),('entryTypes.cac287ab-f575-4bdf-9836-b06446a54504.fieldLayouts.e803e5fb-035f-4e51-a26a-6410371fe5da.tabs.0.elementCondition','null'),('entryTypes.cac287ab-f575-4bdf-9836-b06446a54504.fieldLayouts.e803e5fb-035f-4e51-a26a-6410371fe5da.tabs.0.name','\"Content\"'),('entryTypes.cac287ab-f575-4bdf-9836-b06446a54504.fieldLayouts.e803e5fb-035f-4e51-a26a-6410371fe5da.tabs.0.uid','\"cea4f451-8c71-41cb-8896-242ad1025c28\"'),('entryTypes.cac287ab-f575-4bdf-9836-b06446a54504.fieldLayouts.e803e5fb-035f-4e51-a26a-6410371fe5da.tabs.0.userCondition','null'),('entryTypes.cac287ab-f575-4bdf-9836-b06446a54504.handle','\"grandMarquee\"'),('entryTypes.cac287ab-f575-4bdf-9836-b06446a54504.hasTitleField','false'),('entryTypes.cac287ab-f575-4bdf-9836-b06446a54504.icon','\"tv\"'),('entryTypes.cac287ab-f575-4bdf-9836-b06446a54504.name','\"Grand Marquee\"'),('entryTypes.cac287ab-f575-4bdf-9836-b06446a54504.showSlugField','true'),('entryTypes.cac287ab-f575-4bdf-9836-b06446a54504.showStatusField','true'),('entryTypes.cac287ab-f575-4bdf-9836-b06446a54504.slugTranslationKeyFormat','null'),('entryTypes.cac287ab-f575-4bdf-9836-b06446a54504.slugTranslationMethod','\"site\"'),('entryTypes.cac287ab-f575-4bdf-9836-b06446a54504.titleFormat','null'),('entryTypes.cac287ab-f575-4bdf-9836-b06446a54504.titleTranslationKeyFormat','null'),('entryTypes.cac287ab-f575-4bdf-9836-b06446a54504.titleTranslationMethod','\"site\"'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.color','null'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.description','null'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.cardThumbAlignment','\"end\"'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.elementCondition','null'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.elements.0.autocapitalize','true'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.elements.0.autocomplete','false'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.elements.0.autocorrect','true'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.elements.0.class','null'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.elements.0.dateAdded','\"2025-07-18T21:44:34+00:00\"'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.elements.0.disabled','false'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.elements.0.elementCondition','null'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.elements.0.id','null'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.elements.0.includeInCards','false'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.elements.0.inputType','null'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.elements.0.instructions','null'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.elements.0.label','null'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.elements.0.max','null'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.elements.0.min','null'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.elements.0.name','null'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.elements.0.orientation','null'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.elements.0.placeholder','null'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.elements.0.providesThumbs','false'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.elements.0.readonly','false'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.elements.0.required','true'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.elements.0.size','null'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.elements.0.step','null'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.elements.0.tip','null'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.elements.0.title','null'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.elements.0.uid','\"4aab3bd6-bb76-460a-abc2-2b3a3c5c6fcf\"'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.elements.0.userCondition','null'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.elements.0.warning','null'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.elements.0.width','100'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.name','\"Content\"'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.uid','\"3d391cc9-933b-49df-a27b-cb123f738fe0\"'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.fieldLayouts.d0b49bea-7bc2-42ac-b727-fc48c1169125.tabs.0.userCondition','null'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.handle','\"spaceMD\"'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.hasTitleField','true'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.icon','\"angles-up-down\"'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.name','\"Medium Spacer\"'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.showSlugField','true'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.showStatusField','true'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.slugTranslationKeyFormat','null'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.slugTranslationMethod','\"site\"'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.titleFormat','null'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.titleTranslationKeyFormat','null'),('entryTypes.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75.titleTranslationMethod','\"site\"'),('fields.84a55bd5-c2f1-47b7-974d-9bdb02209679.columnSuffix','null'),('fields.84a55bd5-c2f1-47b7-974d-9bdb02209679.handle','\"copy\"'),('fields.84a55bd5-c2f1-47b7-974d-9bdb02209679.instructions','null'),('fields.84a55bd5-c2f1-47b7-974d-9bdb02209679.name','\"Copy\"'),('fields.84a55bd5-c2f1-47b7-974d-9bdb02209679.searchable','false'),('fields.84a55bd5-c2f1-47b7-974d-9bdb02209679.settings.byteLimit','null'),('fields.84a55bd5-c2f1-47b7-974d-9bdb02209679.settings.charLimit','null'),('fields.84a55bd5-c2f1-47b7-974d-9bdb02209679.settings.code','false'),('fields.84a55bd5-c2f1-47b7-974d-9bdb02209679.settings.initialRows','4'),('fields.84a55bd5-c2f1-47b7-974d-9bdb02209679.settings.multiline','false'),('fields.84a55bd5-c2f1-47b7-974d-9bdb02209679.settings.placeholder','null'),('fields.84a55bd5-c2f1-47b7-974d-9bdb02209679.settings.uiMode','\"normal\"'),('fields.84a55bd5-c2f1-47b7-974d-9bdb02209679.translationKeyFormat','null'),('fields.84a55bd5-c2f1-47b7-974d-9bdb02209679.translationMethod','\"none\"'),('fields.84a55bd5-c2f1-47b7-974d-9bdb02209679.type','\"craft\\\\fields\\\\PlainText\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.columnSuffix','null'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.handle','\"pageBlocks\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.instructions','null'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.name','\"Page Blocks\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.searchable','false'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.createButtonLabel','null'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.defaultIndexViewMode','\"cards\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.enableVersioning','false'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.0.__assoc__.0.0','\"uid\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.0.__assoc__.0.1','\"3158c64d-4653-44d7-8ef9-18f805862e13\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.0.__assoc__.1.0','\"name\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.0.__assoc__.1.1','\"Example Module\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.0.__assoc__.2.0','\"handle\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.0.__assoc__.2.1','\"exampleModule\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.0.__assoc__.3.0','\"description\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.0.__assoc__.3.1','\"An example of how a module is built in Filament Boilerplate\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.0.__assoc__.4.0','\"group\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.0.__assoc__.4.1','\"General\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.1.__assoc__.0.0','\"uid\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.1.__assoc__.0.1','\"cac287ab-f575-4bdf-9836-b06446a54504\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.1.__assoc__.1.0','\"group\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.1.__assoc__.1.1','\"General\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.10.__assoc__.0.0','\"uid\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.10.__assoc__.0.1','\"9655ee03-f1c7-4a52-b72b-f82b1e908aa7\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.10.__assoc__.1.0','\"group\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.10.__assoc__.1.1','\"General\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.2.__assoc__.0.0','\"uid\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.2.__assoc__.0.1','\"0b791488-8988-45c1-b86f-3bd2a9d0f36e\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.2.__assoc__.1.0','\"group\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.2.__assoc__.1.1','\"General\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.3.__assoc__.0.0','\"uid\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.3.__assoc__.0.1','\"f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.3.__assoc__.1.0','\"group\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.3.__assoc__.1.1','\"General\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.4.__assoc__.0.0','\"uid\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.4.__assoc__.0.1','\"1e0e84fb-9ba3-41ec-87d0-22472b8c1ae9\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.4.__assoc__.1.0','\"group\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.4.__assoc__.1.1','\"General\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.5.__assoc__.0.0','\"uid\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.5.__assoc__.0.1','\"b49dcac4-4dca-4e71-9925-c677816d034c\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.5.__assoc__.1.0','\"group\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.5.__assoc__.1.1','\"General\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.6.__assoc__.0.0','\"uid\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.6.__assoc__.0.1','\"840e4b3e-cde9-4478-8400-f2e9f30c147c\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.6.__assoc__.1.0','\"group\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.6.__assoc__.1.1','\"General\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.7.__assoc__.0.0','\"uid\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.7.__assoc__.0.1','\"b5253cdf-98b0-4938-9366-0b2d4914edb3\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.7.__assoc__.1.0','\"group\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.7.__assoc__.1.1','\"General\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.8.__assoc__.0.0','\"uid\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.8.__assoc__.0.1','\"0ca218cb-9082-405d-93a1-5f3fe4324099\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.8.__assoc__.1.0','\"group\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.8.__assoc__.1.1','\"General\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.9.__assoc__.0.0','\"uid\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.9.__assoc__.0.1','\"0372f3ed-21a0-4fba-b318-c137111d8d27\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.9.__assoc__.1.0','\"group\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.entryTypes.9.__assoc__.1.1','\"General\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.includeTableView','false'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.maxEntries','null'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.minEntries','null'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.pageSize','null'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.propagationKeyFormat','null'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.propagationMethod','\"all\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.showCardsInGrid','false'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.settings.viewMode','\"blocks\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.translationKeyFormat','null'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.translationMethod','\"site\"'),('fields.cf1c951a-5742-4fec-8a93-cac307d4f30b.type','\"craft\\\\fields\\\\Matrix\"'),('graphql.schemas.2db1f353-5cc8-40db-b2de-583a39d92a64.isPublic','true'),('graphql.schemas.2db1f353-5cc8-40db-b2de-583a39d92a64.name','\"Public Schema\"'),('meta.__names__.0372f3ed-21a0-4fba-b318-c137111d8d27','\"Pattern Spacer\"'),('meta.__names__.0b791488-8988-45c1-b86f-3bd2a9d0f36e','\"Large Spacer\"'),('meta.__names__.0ca218cb-9082-405d-93a1-5f3fe4324099','\"Editorial Columns\"'),('meta.__names__.161e35c5-199b-4d9c-b090-9dc1c61bc616','\"Default\"'),('meta.__names__.1e0e84fb-9ba3-41ec-87d0-22472b8c1ae9','\"Small Spacer\"'),('meta.__names__.2db1f353-5cc8-40db-b2de-583a39d92a64','\"Public Schema\"'),('meta.__names__.3158c64d-4653-44d7-8ef9-18f805862e13','\"exampleModule\"'),('meta.__names__.48eabee0-5886-430a-ac24-e708a30e425a','\"Filament-Boilerplate\"'),('meta.__names__.72cc4092-dce2-4057-a061-5bf104dd7d96','\"Filament-Boilerplate\"'),('meta.__names__.840e4b3e-cde9-4478-8400-f2e9f30c147c','\"Editorial Collage\"'),('meta.__names__.84a55bd5-c2f1-47b7-974d-9bdb02209679','\"Copy\"'),('meta.__names__.9655ee03-f1c7-4a52-b72b-f82b1e908aa7','\"Cinema Slider\"'),('meta.__names__.aa15edf9-5fc0-40cc-8eb1-570557b0c72f','\"StandardPage\"'),('meta.__names__.ab2a1412-8d01-4b29-a57d-80a0f008efab','\"Pages\"'),('meta.__names__.b49dcac4-4dca-4e71-9925-c677816d034c','\"Aside Paragraph\"'),('meta.__names__.b5253cdf-98b0-4938-9366-0b2d4914edb3','\"Billboard Split\"'),('meta.__names__.cac287ab-f575-4bdf-9836-b06446a54504','\"Grand Marquee\"'),('meta.__names__.cf1c951a-5742-4fec-8a93-cac307d4f30b','\"Page Blocks\"'),('meta.__names__.f5d67f5c-dd8e-4565-a1bc-e0aed82e9f75','\"Medium Spacer\"'),('plugins.cp-css.edition','\"standard\"'),('plugins.cp-css.enabled','true'),('plugins.cp-css.schemaVersion','\"2.0.0\"'),('plugins.cp-css.settings.additionalCss','\"/* Sidebar background color */\\r\\n\\r\\n@import url(\'https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap\');\\r\\n\\r\\nbody {\\r\\n  font-family: \'Montserrat\', sans-serif;\\r\\n}\\r\\n\\r\\nbody.login main {\\r\\n  position: relative;\\r\\n  z-index: 0;\\r\\n  overflow: \\r\\n  hidden;\\r\\n}\\r\\n\\r\\n.cp-icon {\\r\\n    color:#755cef;\\r\\n}\\r\\n\\r\\n/* Blurred background image */\\r\\nbody.login main::before {\\r\\n  content: \\\"\\\";\\r\\n  position: absolute;\\r\\n  inset: 0;\\r\\n  background-image: url(\\\"https://images.pexels.com/photos/114820/pexels-photo-114820.jpeg?_gl=1*c292t5*_ga*ODQyNTExMDguMTc1MjQyODQyMg..*_ga_8JE65Q40S6*czE3NTI0Mjg0MjIkbzEkZzEkdDE3NTI0MjkxNjMkajQ2JGwwJGgw\\\");\\r\\n  background-size: cover;\\r\\n  background-position: center;\\r\\n  filter: blur(8px);\\r\\n  z-index: -2;\\r\\n}\\r\\n\\r\\n/* Color overlay */\\r\\nbody.login main::after {\\r\\n  content: \\\"\\\";\\r\\n  position: absolute;\\r\\n  inset: 0;\\r\\n  background-color: rgba(33, 41, 49, 0.8); /* dark overlay, adjustable alpha */\\r\\n  mix-blend-mode: multiply; /* optional — helps blend with image */\\r\\n  z-index: -1;\\r\\n}\\r\\n\\r\\n.btn.dashed {\\r\\n    background-color:#755cef\\r\\n}\\r\\n\\r\\nicon-picker--choose-btn btn {\\r\\n    background-color:#755cef;\\r\\n}\\r\\n\\r\\nicon-picker--remove-btn btn {\\r\\n    background-color:#755cef;\\r\\n}\\r\\n\\r\\n.fld-new-tab-btn {\\r\\n    background-color:#755cef\\r\\n}\\r\\n\\r\\n.details>.field>.heading>label, .details>fieldset>legend {\\r\\n    color:white !important;\\r\\n}\\r\\n\\r\\n\\r\\n\\r\\n.lp-editor-container>header .btn[data-icon=xmark]:not(:hover,:active,[aria-expanded=true]), .lp-preview-container>header .btn[data-icon=xmark]:not(:hover,:active,[aria-expanded=true]) {\\r\\n    background-color:#755cef;\\r\\n}\\r\\n\\r\\nbody, html { \\r\\nbackground: #212931;\\r\\n}\\r\\n\\r\\n#alerts {\\r\\n    background-color:#212931 !important;\\r\\n    padding-top:16px;\\r\\n    padding-bottom:16px;\\r\\n}\\r\\n\\r\\n#alerts li {\\r\\n    box-shadow:none;\\r\\n}\\r\\n\\r\\n#alerts>li .btn, #alerts>li a.go {\\r\\n    border: 1px solid #755cef;\\r\\n}\\r\\n\\r\\n\\r\\nspan[data-icon=\\\"external\\\"][data-icon-size=\\\"puny\\\"] {\\r\\n  color:white;\\r\\n}\\r\\n\\r\\nexternal\\r\\n\\r\\n#system-info {\\r\\n    height:100px !important;\\r\\n}\\r\\n\\r\\n.btn {\\r\\n    color:white;\\r\\n}\\r\\n\\r\\n.global-sidebar__header {\\r\\n    height:64px;\\r\\n}\\r\\n\\r\\n.nav-item__subnav {\\r\\n    padding-bottom:16px;\\r\\n}\\r\\n\\r\\n:root {\\r\\n  --focus-ring-color: #755cef;\\r\\n  --primary-button-bg:#755cef;\\r\\n  --primary-button-bg--hover:#8e78fe;\\r\\n  --nav-item-bg-hover:#755cef;\\r\\n  --primary-button-bg--active:#8e78fe;\\r\\n  --text-color:#303b46;\\r\\n  --link-color:#755cef;\\r\\n  --nav-item-bg-active:#3b4956;\\r\\n  --error-color: #755cef;\\r\\n  --fg-error: #755cef;\\r\\n  --red-050: #1b2229;\\r\\n  --header-bg:#755cef;\\r\\n}\\r\\n\\r\\n#sidebar nav li a:not(.sel):hover {\\r\\n    background-color:#8e78fe;\\r\\n}\\r\\n\\r\\n#newgroupbtn {\\r\\n    background-color:#755cef;\\r\\n    color:white;\\r\\n}\\r\\n\\r\\n#groupsettingsbtn {\\r\\n    background-color:#755cef;\\r\\n    color:white;\\r\\n}\\r\\n\\r\\n.sidebar-action--sub .sidebar-action__prefix:before {\\r\\n    background-color:white;\\r\\n}\\r\\n\\r\\n.sidebar nav li a {\\r\\n    color:white;\\r\\n}\\r\\n\\r\\n\\r\\n.readable .h1, .readable h1 {\\r\\n    color:white;\\r\\n}\\r\\n\\r\\n.crumb-link {\\r\\n    color:white !important;\\r\\n}\\r\\n\\r\\nlogin-modal-intro readable {\\r\\n    color:white;\\r\\n}\\r\\n\\r\\n#crumb-list li.crumb:not(.current):after, #crumb-list li.crumb:not(.current):before {\\r\\n    background: #0e1215;\\r\\n    content: \\\"\\\";\\r\\n    display: block;\\r\\n    height: calc(var(--arrow-c)*1rem/16);\\r\\n    inset-inline-end: calc(var(--arrow-width)*.5rem/16);\\r\\n    pointer-events: none;\\r\\n    position: absolute;\\r\\n    width: 1px;\\r\\n}\\r\\n\\r\\ndiv.modal.login-modal.fitted {\\r\\n    background-color:rgba(51, 63, 77, 0.8);\\r\\n    color:white;\\r\\n}\\r\\n\\r\\nul.icons li a:hover {\\r\\n    background-color:#eeebfd;\\r\\n    border-color:transparent;\\r\\n}\\r\\n\\r\\n.sidebar nav li a .icon.icon-mask svg circle, .sidebar nav li a .icon.icon-mask svg ellipse, .sidebar nav li a .icon.icon-mask svg line, .sidebar nav li a .icon.icon-mask svg path, .sidebar nav li a .icon.icon-mask svg polygon, .sidebar nav li a .icon.icon-mask svg polyline, .sidebar nav li a .icon.icon-mask svg rect, .sidebar nav li a .icon.icon-mask svg text {\\r\\n    color:white;\\r\\n    background-color:white;\\r\\n}\\r\\n\\r\\n\\r\\nh1, h2, h3, h4, h5, h6,\\r\\np, span, strong, em, b, i,\\r\\nli, a, blockquote, label,\\r\\nth, td, caption, figcaption, small {\\r\\n  \\r\\n}\\r\\n\\r\\nbutton.fullwidth.last.submit.btn {\\r\\n    background-color:#755cef !important;\\r\\n}\\r\\n\\r\\ndiv.pane.secondary.login-form-container {\\r\\n    padding-left:0px;\\r\\n    padding-right:0px;\\r\\n}\\r\\n\\r\\na {\\r\\n    color:#755cef\\r\\n}\\r\\n\\r\\n.border-box.focus,\\r\\n.passwordwrapper.focus,\\r\\n.selectize.multiselect.selectize-input.focus,\\r\\n.text.focus {\\r\\n  box-shadow: 0 0 0 1px #755cef, 0 0 0 3px #755cef;\\r\\n}\\r\\n\\r\\na#system-info:focus, a#system-info:hover {\\r\\n    background-color:#755cef;\\r\\n}\\r\\n\\r\\n.global-sidebar__nav {\\r\\n    margin-top:32px;\\r\\n}\\r\\n\\r\\n.pane {\\r\\n    background-color:transparent;\\r\\n    color:white;\\r\\n    box-shadow:none;\\r\\n} \\r\\n\\r\\n.pane.secondary {\\r\\n    background-color:transparent;\\r\\n    box-shadow:none;\\r\\n}\\r\\n\\r\\n[data-sidebar=collapsed] .nav-item__trigger .menubtn {\\r\\n    color:white;\\r\\n    min-width:50px;\\r\\n}\\r\\n\\r\\n.btn.submit {\\r\\n    background-color:#755cef\\r\\n}\\r\\n\\r\\n.dashboard-grid.item {\\r\\n    background-color:none;\\r\\n}\\r\\n\\r\\n#global-sidebar {\\r\\n   \\r\\n   background-color: rgba(32, 39, 46, 0.90); /* 0.0 to 1.0 = transparent to solid */\\r\\n  background-image: url(\\\"https://www.transparenttextures.com/patterns/foggy-birds.png\\\");\\r\\n  background-blend-mode: multiply; /* or overlay, soft-light, etc. */\\r\\n}\\r\\n\\r\\n/* Header background color */\\r\\n#main-container #main #header {\\r\\n\\r\\n}\\r\\n\\r\\n#system-info {\\r\\n    display:flex;\\r\\n    color:white;\\r\\n}\\r\\n\\r\\n#system-name span {\\r\\n    \\r\\n}\\r\\n\\r\\n#nav-dashboard-link {\\r\\npadding-left:8px;\\r\\npadding-top:8px;\\r\\npadding-bottom:8px;\\r\\nmin-width:50px;\\r\\n}\\r\\n\\r\\n#nav-graphql-link {\\r\\npadding-left:8px;\\r\\npadding-top:8px;\\r\\npadding-bottom:8px;\\r\\nmin-width:50px;\\r\\n}\\r\\n\\r\\n#nav-utilities-link {\\r\\npadding-left:8px;\\r\\npadding-top:8px;\\r\\npadding-bottom:8px;\\r\\nmin-width:50px;\\r\\n}\\r\\n\\r\\n#nav-settings-link {\\r\\npadding-left:8px;\\r\\npadding-top:8px;\\r\\npadding-bottom:8px;\\r\\nmin-width:50px;\\r\\n}\\r\\n\\r\\n#nav-plugin-store-link {\\r\\npadding-left:8px;\\r\\npadding-top:8px;\\r\\npadding-bottom:8px;\\r\\nmin-width:50px;\\r\\n}\\r\\n\\r\\na#nav-settings-link.sidebar-action.sel::before {\\r\\nbackground-color:#755cef\\r\\n}\\r\\n\\r\\na#nav-dashboard-link.sidebar-action.sel::before {\\r\\nbackground-color:#755cef\\r\\n}\\r\\n\\r\\na#nav-graphql-link.sidebar-action.sel::before {\\r\\nbackground-color:#755cef\\r\\n}\\r\\n\\r\\na#nav-plugin-store-link.sidebar-action.sel::before {\\r\\nbackground-color:#755cef\\r\\n}\\r\\n\\r\\na#nav-utilities-link.sidebar-action.sel::before {\\r\\nbackground-color:#755cef\\r\\n}\\r\\n\\r\\n\\r\\n.nav-icon {\\r\\n    color:white;\\r\\n}\\r\\n\\r\\n#site-icon {\\r\\n  background-image: url(\\\"data:image/svg+xml,%3C%3Fxml version=\'1.0\' encoding=\'UTF-8\'%3F%3E%3Csvg id=\'uuid-7aadeaef-bbf6-4b99-9af4-5654b1662955\' xmlns=\'http://www.w3.org/2000/svg\' version=\'1.1\' viewBox=\'0 0 226 137\'%3E%3C!-- Generator: Adobe Illustrator 29.1.0, SVG Export Plug-In . SVG Version: 2.1.0 Build 142) --%3E%3Cdefs%3E%3Cstyle%3E .st0 %7B fill: %23e7e3da; %7D %3C/style%3E%3C/defs%3E%3Cg id=\'uuid-8ea56dec-51d4-411c-8ae9-71fd3c87655a\'%3E%3Cpath class=\'st0\' d=\'M221.9,10.3c1.7-2.7,3.6-7.4,4.1-10.1,0,0,0,0,0,0,0,0-.1.1-.2.2,0,0,0,0,0,0-13.9,13.6-28.1,25-42,34.6-8.9,6.1-24.5,16.2-33.3,21.1-9.4,5.3-17.2,10.6-22.5,19.5-2.1,3.5-2.3,7.3-4.2,10.8-1.5,2.7-3.6,3.9-4.8,4.9-2.2,1.9-4.8,12.5-6.1,19.2-1.2-6.7-3.9-17.3-6.1-19.2-1.1-1-3.2-2.2-4.8-4.9-1.9-3.5-2.1-7.3-4.2-10.8-5.2-8.9-13-14.2-22.5-19.5-8.7-4.9-24.4-14.9-33.3-21.1C28.3,25.3,14.2,14,.2.3c0,0,0,0,0,0,0,0-.2-.2-.2-.2C0,.2,0,.2,0,.1c.5,2.8,2.5,7.5,4.1,10.1,5.2,9,17.6,17.1,22.6,20.5-6-3.4-12-7.2-17.9-11.2.5,2.4,1.8,4.2,3.2,6.4,5.1,7.6,13.1,12.2,19.6,16.1-4.2-1.9-8.8-4.5-13-6.6,4,10.8,14.5,15.3,22.6,19-2.2-.7-8.5-3-10.6-3.9-.7-.3.8,2.2.9,2.4,5,8.5,14.7,10.9,21.9,13.7-3-.6-8.1-2.2-11.1-2.8,4.6,6.6,12.5,10.8,20.4,13.5-3-.5-8.9-2.1-8.9-2.1,2.2,2.3,5,5.2,7.7,7.2,2.2,1.6,4.6,3.2,7.1,4.5,2.4,1.2,4.9,2.3,7.5,3.1,3.4,1,6.9,1.6,10.5,1.6,1.8,0,3.5,0,5.2-.3.9-.1,1.7-.3,2.5-.4.2,0,.8-.1,1.1-.2.6.7,1.2,3.7,2,4.8,0,0,0,0,0,0-2,1.3-4.1,2.6-5.8,4-.2.2-.4.4-.5.6-1,1.7-.1,3.4,1,5.1.7-.4,1.5-.9,2.2-1.3-1.1,1.6-1.9,1.9-2.1,4.2,0,.2,0,.3,0,.5,0,0,0,.1,0,.2,0,.9.4,1.7.9,2.4.3.5.6,1,1,1.4,0,0,0,.1.1.2.3-.4,1.5-1.7,1.8-2.2,0,0,0,.2,0,.3-.5,1.4-1.4,3.7-1,5.1.4,1.2,1.1,2.4,2,3.3.5-1,1.1-2,1.6-3.1-.5,1.4-.6,3-.4,4.5.2,1.7,1.1,3.4,2.3,4.6.6-1.5,1.2-2.9,1.7-4.4-.9,3.8-.9,8.5,2.2,11.5.6-2.3,1.3-4.6,1.9-6.9-.3,3.3-.4,5.6-.4,6.7,0,.8.2,2.4,2.3,3.6,1.3.5,2.7.9,4.1,1.1,0,0,.7-7.8.7-7.8v.4c0,0,0-.1,0-.2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,.1,0,.2v-.4s.7,7.8.7,7.8c1.4-.2,2.7-.6,4.1-1.1,2.1-1.2,2.3-2.8,2.3-3.6,0-1.1-.1-3.4-.4-6.7.6,2.3,1.3,4.6,1.9,6.9,3.1-3,3.1-7.6,2.2-11.5.6,1.5,1.2,2.9,1.7,4.4,1.3-1.2,2.1-2.8,2.3-4.6.2-1.5,0-3.1-.4-4.5.5,1,1.1,2,1.6,3.1.9-.9,1.6-2.1,2-3.3.4-1.4-.5-3.7-1-5.1,0,0,0-.2,0-.3.3.4,1.5,1.7,1.8,2.2,0,0,0-.1.1-.2.4-.4.7-.9,1-1.4.5-.7.8-1.6.9-2.4,0,0,0-.1,0-.2,0-.2,0-.3,0-.5-.3-2.3-1-2.7-2.1-4.2.7.4,1.5.9,2.2,1.3,1.1-1.7,2-3.4,1-5.1-.1-.2-.3-.4-.5-.6-1.7-1.4-3.8-2.6-5.8-4,0,0,0,0,0,0,.8-1,1.5-4.1,2-4.8.2.1.8.2,1.1.2.8.2,1.7.3,2.5.4,1.7.2,3.5.3,5.2.3,3.5,0,7.1-.6,10.5-1.6,2.6-.8,5.2-1.9,7.5-3.1,2.5-1.3,4.9-2.8,7.1-4.5,2.7-2,5.5-4.8,7.7-7.2,0,0-5.9,1.6-8.9,2.1,7.9-2.7,15.8-6.9,20.4-13.5-3,.7-8.1,2.3-11.1,2.8,7.2-2.8,16.9-5.2,21.9-13.7.1-.2,1.6-2.7.9-2.4-2.2.9-8.5,3.2-10.6,3.9,8.1-3.7,18.6-8.2,22.6-19-4.2,2.1-8.8,4.7-13,6.6,6.5-3.9,14.5-8.6,19.6-16.1,1.4-2.2,2.7-4,3.2-6.4-5.9,4.1-11.9,7.8-17.9,11.2,5-3.4,17.5-11.5,22.6-20.5h0Z\'/%3E%3C/g%3E%3C/svg%3E\\\");\\r\\nbackground-repeat: no-repeat no-repeat;\\r\\nbackground-position: center center;\\r\\nbackground-size: cover;\\r\\nheight:21px;\\r\\nwidth:32px;\\r\\n}\\r\\n\\r\\n#site-icon svg {\\r\\n    \\r\\n}\\r\\n\\r\\n#site-icon svg {\\r\\n    visibility: hidden;\\r\\n    \\r\\n}\\r\\n\\r\\n/* H1 tags */\\r\\nh1 {\\r\\n    color: #ffffff;\\r\\n}\\r\\n\\r\\n.label {\\r\\n    color:white;\\r\\n}\\r\\n\\r\\n\\r\\n\\r\\n/* Standard button color */\\r\\n.btn.submit {\\r\\n    background: #da5a47;\\r\\n}\\r\\n/* Hover button color */\\r\\n.btn.submit:not(.disabled):not(.inactive):hover,\\r\\n.btn.submit:not(.disabled):not(.inactive).hover {\\r\\n    background: #bf503f;\\r\\n}\\r\\n/* Active button color */\\r\\n.btn.submit:not(.disabled):not(.inactive):active,\\r\\n.btn.submit:not(.disabled):not(.inactive).active {\\r\\n    background: #8c3b2e;\\r\\n}\\r\\n\\r\\nbody.fixed-header #header {\\r\\n    -webkit-backdrop-filter: none;\\r\\n    backdrop-filter: none;\\r\\n    background-color:#212931;\\r\\n    padding-top:16px;\\r\\n    padding-bottom:16px;\\r\\n}\\r\\n\\r\\n.widget.craft\\\\\\\\widgets\\\\\\\\craftsupport .front .pane .cs-screen-home .cs-opt:hover {\\r\\n    background-color:#2f3944;\\r\\n}\\r\\n\\r\\n.sidebar nav li:not(.has-subnav) [data-source-item].active-drop-target, .sidebar nav li:not(.has-subnav) [data-source-item].sel, .sidebar nav li:not(.has-subnav)>a.active-drop-target, .sidebar nav li:not(.has-subnav)>a.sel {\\r\\n    background-color:#755cef;\\r\\n}\"'),('plugins.cp-css.settings.cacheBusting','true'),('plugins.cp-css.settings.cssFile','\"\"'),('plugins.cp-nav.edition','\"standard\"'),('plugins.cp-nav.enabled','true'),('plugins.cp-nav.schemaVersion','\"2.0.11\"'),('plugins.dashboard-begone.edition','\"standard\"'),('plugins.dashboard-begone.enabled','true'),('plugins.dashboard-begone.schemaVersion','\"1.0.0\"'),('plugins.servd-asset-storage.edition','\"standard\"'),('plugins.servd-asset-storage.enabled','true'),('plugins.servd-asset-storage.schemaVersion','\"3.0.0\"'),('plugins.vite.edition','\"standard\"'),('plugins.vite.enabled','true'),('plugins.vite.schemaVersion','\"1.0.0\"'),('sections.ab2a1412-8d01-4b29-a57d-80a0f008efab.defaultPlacement','\"end\"'),('sections.ab2a1412-8d01-4b29-a57d-80a0f008efab.enableVersioning','true'),('sections.ab2a1412-8d01-4b29-a57d-80a0f008efab.entryTypes.0.uid','\"aa15edf9-5fc0-40cc-8eb1-570557b0c72f\"'),('sections.ab2a1412-8d01-4b29-a57d-80a0f008efab.handle','\"pages\"'),('sections.ab2a1412-8d01-4b29-a57d-80a0f008efab.maxAuthors','1'),('sections.ab2a1412-8d01-4b29-a57d-80a0f008efab.name','\"Pages\"'),('sections.ab2a1412-8d01-4b29-a57d-80a0f008efab.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.ab2a1412-8d01-4b29-a57d-80a0f008efab.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.ab2a1412-8d01-4b29-a57d-80a0f008efab.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.ab2a1412-8d01-4b29-a57d-80a0f008efab.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.ab2a1412-8d01-4b29-a57d-80a0f008efab.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.ab2a1412-8d01-4b29-a57d-80a0f008efab.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.ab2a1412-8d01-4b29-a57d-80a0f008efab.propagationMethod','\"all\"'),('sections.ab2a1412-8d01-4b29-a57d-80a0f008efab.siteSettings.48eabee0-5886-430a-ac24-e708a30e425a.enabledByDefault','true'),('sections.ab2a1412-8d01-4b29-a57d-80a0f008efab.siteSettings.48eabee0-5886-430a-ac24-e708a30e425a.hasUrls','true'),('sections.ab2a1412-8d01-4b29-a57d-80a0f008efab.siteSettings.48eabee0-5886-430a-ac24-e708a30e425a.template','\"page.twig\"'),('sections.ab2a1412-8d01-4b29-a57d-80a0f008efab.siteSettings.48eabee0-5886-430a-ac24-e708a30e425a.uriFormat','\"{slug}\"'),('sections.ab2a1412-8d01-4b29-a57d-80a0f008efab.type','\"single\"'),('siteGroups.72cc4092-dce2-4057-a061-5bf104dd7d96.name','\"Filament-Boilerplate\"'),('sites.48eabee0-5886-430a-ac24-e708a30e425a.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.48eabee0-5886-430a-ac24-e708a30e425a.handle','\"default\"'),('sites.48eabee0-5886-430a-ac24-e708a30e425a.hasUrls','true'),('sites.48eabee0-5886-430a-ac24-e708a30e425a.language','\"en\"'),('sites.48eabee0-5886-430a-ac24-e708a30e425a.name','\"Filament-Boilerplate\"'),('sites.48eabee0-5886-430a-ac24-e708a30e425a.primary','true'),('sites.48eabee0-5886-430a-ac24-e708a30e425a.siteGroup','\"72cc4092-dce2-4057-a061-5bf104dd7d96\"'),('sites.48eabee0-5886-430a-ac24-e708a30e425a.sortOrder','1'),('system.edition','\"solo\"'),('system.live','true'),('system.name','\"Filament\"'),('system.retryDuration','null'),('system.schemaVersion','\"5.8.0.3\"'),('system.timeZone','\"America/Los_Angeles\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.require2fa','false'),('users.requireEmailVerification','true');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_ifvoyzurjewjiwlxojvwdxklzdntuacmdism` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_veaaaycokjlcutkvgfnubmodwjcetfokmcud` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=274 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recoverycodes`
--

DROP TABLE IF EXISTS `recoverycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recoverycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `recoveryCodes` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recoverycodes`
--

LOCK TABLES `recoverycodes` WRITE;
/*!40000 ALTER TABLE `recoverycodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `recoverycodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_pzdfqkjevfxruopcocwrzfnlfqxktkbuwter` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_zexznsuxxybmzdiyqugwaptpnrltrqvxlqpm` (`sourceId`),
  KEY `idx_tiakxkqhrrstnvpcfeqzwkpwzajzkypaotxz` (`targetId`),
  KEY `idx_facncppoarmyqhzrprbzztmlvuhghcalwhii` (`sourceSiteId`),
  CONSTRAINT `fk_efsfxacevcbrfadbvpsqngueubdadzuhsibs` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jnzmpcfhyfhdmgbsnfoczycetagpoqsswttq` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_loiaqzcfckwhkuxeoutvegaerfggjwzvxnce` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resourcepaths`
--

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;
INSERT INTO `resourcepaths` VALUES ('125c5ef2','@craft/web/assets/jqueryui/dist'),('1260a88','@craft/web/assets/fileupload/dist'),('15ba4c35','@bower/jquery/dist'),('18bbcee4','@bower/jquery/dist'),('1f5ddc23','@craft/web/assets/jqueryui/dist'),('234fc8ca','@craft/web/assets/routes/dist'),('278205e4','@craft/web/assets/animationblocker/dist'),('2a838735','@craft/web/assets/animationblocker/dist'),('30c54c68','@craft/web/assets/dashboard/dist'),('3dc4ceb9','@craft/web/assets/dashboard/dist'),('4314e7fd','@craft/web/assets/jquerypayment/dist'),('4347389f','@craft/web/assets/jquerytouchevents/dist'),('4487e872','@craft/web/assets/feed/dist'),('4683e54a','@craft/web/assets/velocity/dist'),('49866aa3','@craft/web/assets/feed/dist'),('499faadb','@craft/web/assets/clearcaches/dist'),('4b82679b','@craft/web/assets/velocity/dist'),('4e15652c','@craft/web/assets/jquerypayment/dist'),('4e46ba4e','@craft/web/assets/jquerytouchevents/dist'),('52a33d11','@craft/web/assets/vue/dist'),('52fbcd4e','@craft/web/assets/editsection/dist'),('5422915c','@craft/web/assets/plugins/dist'),('5fa2bfc0','@craft/web/assets/vue/dist'),('60cab01d','@verbb/base/resources/dist'),('703dcd9f','@craft/web/assets/timepicker/dist'),('724ebff2','@craft/web/assets/picturefill/dist'),('74f78023','@craft/web/assets/xregexp/dist'),('769357e7','@craft/web/assets/craftsupport/dist'),('79f602f2','@craft/web/assets/xregexp/dist'),('7ac88e4c','@craft/web/assets/authmethodsetup/dist'),('7b92d536','@craft/web/assets/craftsupport/dist'),('7f4f3d23','@craft/web/assets/picturefill/dist'),('8199d68b','@craft/web/assets/fabric/dist'),('8c98545a','@craft/web/assets/fabric/dist'),('8f6bd296','@craft/web/assets/sites/dist'),('914133e','@craft/web/assets/updates/dist'),('91b340b5','@craft/web/assets/utilities/dist'),('93dc96ff','@craft/web/assets/userpermissions/dist'),('996894cc','@craft/web/assets/matrix/dist'),('a42a634d','@craft/web/assets/garnish/dist'),('a92be19c','@craft/web/assets/garnish/dist'),('b1a87bd0','@craft/web/assets/graphiql/dist'),('b8a5a263','@craft/web/assets/admintable/dist'),('bfba1499','@verbb/cpnav/resources/dist'),('c01c6015','@craft/web/assets/tailwindreset/dist'),('c23a4802','@craft/web/assets/pluginstore/dist'),('c278859','@craft/web/assets/fileupload/dist'),('c640faae','@craft/web/assets/cp/dist'),('c709da37','@craft/web/assets/selectize/dist'),('ca0858e6','@craft/web/assets/selectize/dist'),('cb3ca178','@craft/web/assets/installer/dist'),('cb41787f','@craft/web/assets/cp/dist'),('cd1de2c4','@craft/web/assets/tailwindreset/dist'),('ceb57a16','@nystudio107/codeeditor/web/assets/dist'),('cf3bcad3','@craft/web/assets/pluginstore/dist'),('d13fa1ee','@craft/web/assets/updateswidget/dist'),('d1745e36','@craft/web/assets/d3/dist'),('d4b680e2','@craft/web/assets/theme/dist'),('d714d550','@craft/web/assets/iframeresizer/dist'),('d810f5b5','@craft/web/assets/generalsettings/dist'),('d9b70233','@craft/web/assets/theme/dist'),('da155781','@craft/web/assets/iframeresizer/dist'),('dc3e233f','@craft/web/assets/updateswidget/dist'),('dc75dce7','@craft/web/assets/d3/dist'),('dc7c82b7','@craft/web/assets/fieldsettings/dist'),('e2846151','@craft/web/assets/recententries/dist'),('e646a5df','@craft/web/assets/updater/dist'),('eb47270e','@craft/web/assets/updater/dist'),('ef85e380','@craft/web/assets/recententries/dist'),('f77076d9','@craft/web/assets/axios/dist'),('fa71f408','@craft/web/assets/axios/dist');
/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nbadfjuacswwgrppdhclmxwhfkkvrmeczzsf` (`canonicalId`,`num`),
  KEY `fk_eubwgqlioslnyoivbefyyezcjdpckxfubefn` (`creatorId`),
  CONSTRAINT `fk_eubwgqlioslnyoivbefyyezcjdpckxfubefn` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_yawceyhmchyikemveymsrnlwzxtljnleewja` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
INSERT INTO `revisions` VALUES (1,3,1,1,''),(2,3,1,2,NULL),(3,3,1,3,NULL),(4,3,1,4,NULL),(5,3,1,5,''),(6,9,1,1,NULL),(7,9,1,2,'Applied “Draft 1”'),(8,9,1,3,NULL),(9,9,1,4,NULL),(10,15,1,1,NULL),(11,15,1,2,'Applied “Draft 1”'),(12,19,1,1,NULL),(13,19,1,2,NULL),(14,19,1,3,NULL),(15,19,1,4,NULL),(16,19,1,5,NULL),(17,19,1,6,'Applied “Draft 1”'),(18,29,1,1,NULL),(19,19,1,7,'Applied “Draft 1”'),(20,19,1,8,'Applied “Draft 1”'),(21,19,1,9,'Applied “Draft 1”'),(22,42,1,1,NULL),(23,29,1,2,NULL),(24,19,1,10,''),(25,19,1,11,'Applied “Draft 1”'),(26,49,1,1,NULL),(27,19,1,12,'Applied “Draft 1”'),(28,19,1,13,'Applied “Draft 1”'),(29,19,1,14,'Applied “Draft 1”'),(30,49,1,2,NULL),(31,19,1,15,'Applied “Draft 1”'),(32,49,1,3,NULL),(33,19,1,16,'Applied “Draft 1”'),(34,69,1,1,NULL),(35,19,1,17,'Applied “Draft 1”'),(36,75,1,1,NULL),(37,76,1,1,NULL),(38,19,1,18,'Applied “Draft 1”'),(39,82,1,1,NULL),(40,19,1,19,'Applied “Draft 1”'),(41,87,1,1,NULL),(42,19,1,20,'Applied “Draft 1”'),(43,93,1,1,NULL),(44,94,1,1,NULL),(45,19,1,21,'Applied “Draft 1”'),(46,100,1,1,NULL),(47,19,1,22,'Applied “Draft 1”'),(48,105,1,1,NULL),(49,19,1,23,'Applied “Draft 1”'),(50,111,1,1,NULL),(51,112,1,1,NULL),(52,19,1,24,'Applied “Draft 1”'),(53,120,1,1,NULL),(54,121,1,1,NULL),(55,122,1,1,NULL),(56,19,1,25,'Applied “Draft 1”'),(57,129,1,1,NULL),(58,19,1,26,'Applied “Draft 1”'),(59,134,1,1,NULL),(60,19,1,27,'Applied “Draft 1”'),(61,19,1,28,'Applied “Draft 1”'),(62,142,1,1,NULL),(63,143,1,1,NULL);
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_kjjfafyftdxddsmafllgvbmwnkyzpvvhhhop` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
INSERT INTO `searchindex` VALUES (1,'email',0,1,' creative raraavis design '),(1,'firstname',0,1,''),(1,'fullname',0,1,''),(1,'lastname',0,1,''),(1,'slug',0,1,''),(1,'username',0,1,' admin '),(2,'addressline1',0,1,''),(2,'addressline2',0,1,''),(2,'addressline3',0,1,''),(2,'administrativearea',0,1,''),(2,'countrycode',0,1,' us '),(2,'dependentlocality',0,1,''),(2,'fullname',0,1,''),(2,'locality',0,1,''),(2,'organization',0,1,''),(2,'organizationtaxid',0,1,''),(2,'postalcode',0,1,''),(2,'slug',0,1,' temp qoyhdfklzdzmieppkemzthpkyryjgfxhrpfl '),(2,'sortingcode',0,1,''),(2,'title',0,1,''),(3,'slug',0,1,' hello '),(3,'title',0,1,' hello '),(9,'slug',0,1,' pages '),(9,'title',0,1,''),(15,'slug',0,1,' example '),(15,'title',0,1,''),(19,'slug',0,1,' about '),(19,'title',0,1,' about '),(28,'slug',0,1,' temp ppsdcbehmumbvoalwhhgqwwhwqgvubbfmyoc '),(28,'title',0,1,''),(29,'slug',0,1,' temp cyvwaccosclkregvmeeogjawmrqhxoydmhnm '),(29,'title',0,1,''),(42,'slug',0,1,' temp caofzksdoynnvfihjpgmsbmkeqsqzmerxmpl '),(42,'title',0,1,''),(49,'slug',0,1,' title '),(49,'title',0,1,' title '),(69,'slug',0,1,' temp ozfepvxozczzxvefqltudwdllyyfouceyabp '),(69,'title',0,1,''),(75,'slug',0,1,' temp gndyubgjmcfdfmjxmjpfdrxsukffzkitynlp '),(75,'title',0,1,''),(76,'slug',0,1,' placeholder '),(76,'title',0,1,' placeholder '),(82,'slug',0,1,' temp bfospfmlncesvouvhptufyfjvyudrtnbjvnz '),(82,'title',0,1,''),(87,'slug',0,1,' temp ogltnwzzysmtzdwjahmhsfpgewnyawllzlzf '),(87,'title',0,1,''),(93,'slug',0,1,' temp grisatfdlanszdsmqlumalulpzzwosxbhfcw '),(93,'title',0,1,''),(94,'slug',0,1,' temp jjamsytndfmkbazedvsefzcbxqnwkllutjlh '),(94,'title',0,1,''),(100,'slug',0,1,' temp ensbixkpqeeqyugrvbonwwvlfwujukhafpsc '),(100,'title',0,1,''),(105,'slug',0,1,' temp qhnjarggiyrhamkqyszgvdawekwlqddbckhm '),(105,'title',0,1,''),(111,'slug',0,1,' temp hectkcenyhwczbfmcqlegqvlvjeyajlvsrtz '),(111,'title',0,1,''),(112,'slug',0,1,' placeholder '),(112,'title',0,1,' placeholder '),(120,'slug',0,1,' temp ufstlzslglkspakvgvijgwepwuiocpqrlkhe '),(120,'title',0,1,''),(121,'slug',0,1,' temp zqqmwjmyzacxqxuxcbemjwlqmdbvocayhiht '),(121,'title',0,1,''),(122,'slug',0,1,' temp mzawsgljhmqcnqbqdrvsiwticvixlbtzznjt '),(122,'title',0,1,''),(129,'slug',0,1,' temp ldssqfulkherslmcpheypubodrnmdmrxvcim '),(129,'title',0,1,''),(134,'slug',0,1,' temp xdfoijosclzsykhhriuqtcpddkwwzjgpserd '),(134,'title',0,1,''),(142,'slug',0,1,' temp ejgjejedcudwefsqmdfkwtqrklvmbnqgyaxv '),(142,'title',0,1,''),(143,'slug',0,1,' temp rumyopjkezergdoxuwmogvsjqrjalubmopet '),(143,'title',0,1,'');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindexqueue`
--

DROP TABLE IF EXISTS `searchindexqueue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindexqueue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `reserved` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wahioyhtlzayijkpqlsrxlhwbbsjeqtcnusx` (`elementId`,`siteId`,`reserved`),
  CONSTRAINT `fk_usihefntltuiyzkuyjahcvvqnyiojrmchqyv` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindexqueue`
--

LOCK TABLES `searchindexqueue` WRITE;
/*!40000 ALTER TABLE `searchindexqueue` DISABLE KEYS */;
/*!40000 ALTER TABLE `searchindexqueue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindexqueue_fields`
--

DROP TABLE IF EXISTS `searchindexqueue_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindexqueue_fields` (
  `jobId` int NOT NULL,
  `fieldHandle` varchar(255) NOT NULL,
  PRIMARY KEY (`jobId`,`fieldHandle`),
  UNIQUE KEY `idx_biarwqkuxeuumiwmmjkbzvsfgrivbcqfvjgd` (`jobId`,`fieldHandle`),
  CONSTRAINT `fk_nilibybzzqermkwbhqsnyduvtwqbfeezoqyy` FOREIGN KEY (`jobId`) REFERENCES `searchindexqueue` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindexqueue_fields`
--

LOCK TABLES `searchindexqueue_fields` WRITE;
/*!40000 ALTER TABLE `searchindexqueue_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `searchindexqueue_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `maxAuthors` smallint unsigned DEFAULT NULL,
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_answethtbrrfummnvltbengfsqmaducuczcd` (`handle`),
  KEY `idx_irtzcuciphapnrmfhpakweohzqjqoddppyjs` (`name`),
  KEY `idx_kkeiixgjikzfbrasynsqxvrbogfwjduwzqso` (`structureId`),
  KEY `idx_yszwbpcggmbcjkseovxfsteqfpuqbvyyhbzy` (`dateDeleted`),
  CONSTRAINT `fk_unpdptbxyyqlgkmqhwkafkwnlfepjmpywdmd` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,NULL,'Page','page','single',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2025-07-14 13:12:02','2025-07-14 13:17:28','2025-07-14 13:38:06','1b3a481b-2dbd-4568-9612-9b2430bb030a'),(2,NULL,'Pages','pages','single',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2025-07-14 13:43:45','2025-07-14 13:43:45','2025-07-14 13:54:09','82616205-6a29-444a-877f-8dcf4fc2de22'),(3,NULL,'Example','example','single',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2025-07-14 13:58:00','2025-07-14 13:58:00','2025-07-14 14:04:47','a1b42672-68c3-4616-b6fc-5eb19d5be94f'),(4,NULL,'Pages','pages','single',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2025-07-14 14:18:27','2025-07-14 14:19:21',NULL,'ab2a1412-8d01-4b29-a57d-80a0f008efab');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_entrytypes`
--

DROP TABLE IF EXISTS `sections_entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_entrytypes` (
  `sectionId` int NOT NULL,
  `typeId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `handle` varchar(255) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`sectionId`,`typeId`),
  KEY `fk_alzomoxadojfoigcyfhkxxpsnufslfxhtbis` (`typeId`),
  CONSTRAINT `fk_alzomoxadojfoigcyfhkxxpsnufslfxhtbis` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jlaytpphvztqlqbqfvluvbywqjxfwwglwjom` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_entrytypes`
--

LOCK TABLES `sections_entrytypes` WRITE;
/*!40000 ALTER TABLE `sections_entrytypes` DISABLE KEYS */;
INSERT INTO `sections_entrytypes` VALUES (1,1,1,NULL,NULL,NULL),(2,2,1,NULL,NULL,NULL),(3,3,1,NULL,NULL,NULL),(4,5,1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `sections_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kspvlpeoubabmcvecflcwoutzusjnftbadkp` (`sectionId`,`siteId`),
  KEY `idx_reetbqarifdufniigensdfjmligimqrbokcy` (`siteId`),
  CONSTRAINT `fk_jkwocmzepvtkkgpalsfsomvtmdalixioyrla` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lklpcfdjivjbxwetxueqokzyoacvhhyscbtm` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
INSERT INTO `sections_sites` VALUES (1,1,1,0,NULL,NULL,1,'2025-07-14 13:12:02','2025-07-14 13:17:59','9325b1f0-0cc3-4b93-ab80-85d691718f58'),(2,2,1,0,NULL,NULL,1,'2025-07-14 13:43:45','2025-07-14 13:46:52','4fcbde9e-8023-40ca-9a58-ddcc42b2da33'),(3,3,1,1,'example','example/_entry.twig',1,'2025-07-14 13:58:00','2025-07-14 13:58:00','943ebb87-951a-4ac3-b20a-35ecfe6b6998'),(4,4,1,1,'{slug}','page.twig',1,'2025-07-14 14:18:27','2025-07-14 14:26:25','2f323287-2a43-4d04-bfe9-3f06a47b987c');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bggblnepbtwtpsdpjbldfbmopscjrenmioip` (`uid`),
  KEY `idx_oxvqwsjixjepdpljoebiimtofuogijnahcqp` (`token`),
  KEY `idx_alrocayuaokwgvcdnuvsjczerirmkoyaxchd` (`dateUpdated`),
  KEY `idx_xgqrafyiugjfvqthfuncctusofnzlsopwgmc` (`userId`),
  CONSTRAINT `fk_aznrbxenxxfhfyregesrhvkglitrmubfjuaz` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES (1,1,'jpkStCMWS7f9hIKxXhsvz-pCXEjPCMXGgT9o1ZTD_qqzv4CKmLAnvJWjzX7fwndXtAnNpYbCpHeSwRLn7ygnjGoRXFpIKQI4aUU6','2025-07-12 19:22:33','2025-07-12 19:25:05','a30e7e1f-582b-4c76-8164-32b7ae790e23'),(2,1,'IW8AM9uUrt9SvS0QrG6VuVRk2BjH17tse_iBZjjGMfsfk6FihbIpDIeBOUQkY3EGw2oe9eMT37xsgMde3ksHWQ1mwA848aLrP9iH','2025-07-12 19:26:12','2025-07-12 19:31:46','1437dead-e2d1-462a-96e2-f40d0f275d27'),(3,1,'umevLNl1Hn80oEYi1iJMlkDMygV1cG0-SvEXww1vN7zinCsqDUGmM40NAeRJO_aDcTeaTDOqlhUhCUPQ1i4iDDfDoBHQ4TkaTRhA','2025-07-12 19:32:07','2025-07-12 19:32:47','f39b4b6d-6f98-4a36-942c-673657c6ffee'),(4,1,'ssLjVjp7aLEFDE3MVs_FwHeq7y7girZdMBw1v70ijUABuv-3EyYJuf9NtPvQmWaKyvSOQMwCCiSHdIy65pzACQxghVt-kMgOpLFS','2025-07-12 19:32:48','2025-07-12 19:33:05','221140bf-1378-4116-9cc1-062047465085'),(5,1,'jCUz9U6kMckym8wT4gsH0rGFjq0Lh5UNZt4RJfx8wGv6sNDx9eIq03AyZqpSbMGogDHp0M8DGRMjybKj1LiDfEHGkkgzkvM37Lan','2025-07-12 19:33:24','2025-07-12 20:28:51','693f7b44-367b-449a-a747-7f7b47909d09'),(6,1,'r4fm3_yexf5OLjsHd6qPt5-tCOcColg5SSvD5dQ7Vhf89f-savezb6uX84AfrDZs7anMo3IrvD3miiC9V5Jeb15Z6dmInbjxP6tD','2025-07-12 20:29:16','2025-07-12 20:29:25','4932ff63-5bce-4516-865c-d6b4f51c0d88'),(7,1,'QnCpEYg4OzBPYMXgGYQLkh75uIuxlLkh9f0XfyKSfhk278phKmPEQBfeFpNdmWys_ZpJ4xR_pkKfkJ_4x8ccd3VDQG5KDr6fbjV6','2025-07-12 20:30:29','2025-07-12 20:32:00','1bfb0b69-0e7e-43a9-b8ea-d88e2941cf6b'),(8,1,'G9FZkKwaZX7wwRleVMlptYzREcu-tD9FEJpep9aY6u3GruUpdJBXsQlEeIyYXPQrXjzABhF62jZqXDjJrq68FsMI7jagDg65ePIN','2025-07-12 20:32:20','2025-07-12 20:32:40','bb47acaa-f001-43ff-bffa-9f0bb5d34911'),(9,1,'DG38TtgLz3S-crHLzJHJsVWtPbL7CFetWza6xdxDjtlnfs6lhoE6MHxxHvrRyjxRan8WiSkca5MspweXBDxvQwoRtUEYRj44cgxI','2025-07-12 20:33:49','2025-07-12 20:39:14','abfd6f4f-4156-4dd8-829d-7de6142717a1'),(10,1,'NTIKmwxD_US94ucD99VnGRVl_Xw_qI3VYmfXz6IHWXVf5K6K2zNJB_TuykcNIQ3ZSeZqyoV1PAvQXzFftYM9s0GurrqGWfDTmRPr','2025-07-12 20:39:24','2025-07-12 20:39:26','5acda1b1-7a46-40b1-a9ba-b9f9f7a625b6'),(11,1,'Plhuf7lTU63labqoMbF0cZSsnnVROo6PW4a9HHUCPPvUWVFOOi5WImMFgfuOzP2Tsm3NxS27VJ3LDl2zhnbX0RYjET0EzKFIgsgL','2025-07-12 20:40:31','2025-07-12 20:42:43','883ec638-0202-4b89-a408-17e4c965ded9'),(12,1,'TmIh5vOZvtHlkFVKVl9tqLlgZJVeOBAkbh_h8Nib_fSssIKyIyFPc11L8qi0jZe0PDpSW3jj4s2uy5EIx19XFWbUDSG-pDUCf1G7','2025-07-12 20:43:30','2025-07-12 20:43:55','3361a143-fb5c-4ac2-9be9-d62152145be0'),(13,1,'-SItz5o0_LZEwU9uhrx2j8e230k5kG3CGr-8BeyvBUNpc7qZp8dTWxkMtACc4p9dwJXKiCHs9M6Z_vvMcWLmqlKptzU7VdvgWQCt','2025-07-12 20:44:14','2025-07-12 21:03:57','8c65049d-6b39-4118-b5ed-ea9bfcca015c'),(14,1,'OG1hPPXJGt1U-HDgi_QGbw7Hwlm_0WuZjIPI7jr9hFWlA9iNEiAiiSdalcMC5lMhNUnt-SziZIibtjsIPy4RaNuddAMDuX4lsui5','2025-07-12 21:03:58','2025-07-12 21:05:13','2e7448e6-0cdd-4946-9d26-bc68779120c1'),(16,1,'LolBwBJqIMP4Hmp46EexwcEfvgP770FQ3AqcJ0N3v6G0GqaOWabKOSSkGpoDyuCKlumG_wDGB_HnkE4kmH_CiFdM8laKUJ3_dRXL','2025-07-12 21:11:10','2025-07-12 21:19:04','38b5398c-84d0-48f2-b097-469367bfcf1b'),(17,1,'1cWVKY1_0PweN4NnjLDpDKgtU9dmgURVR1PGuhWraXamdwAlZxxrqoCVOzYetTKQ5t4cVYH9EtnAdsDD70-bU_GKC0nDydDtqEOn','2025-07-12 21:20:44','2025-07-12 21:20:44','0f98385b-2731-4e22-9576-953759c61266'),(19,1,'lkoozR7iq4oweZaeZ96CZtE3XS-Vt0Vvj3f-QHu_bkxa7uCEXLlX6xxTB98B3Cg53j-X6Q-HxK5A5ZiQ4JlAX7BHf4DV8PxLYMJW','2025-07-12 21:37:27','2025-07-12 21:38:38','e532277f-c8ef-4cdf-84aa-368630df36c6'),(21,1,'DvainHc8LefeXqJ4THuVobL4shWnY6Wdskp51szn1g5EssdO7lqbkY37GhN5gFWwtqInZQVvkcuHOxgOE2U_r8YPba77kfE6V4sz','2025-07-12 21:40:24','2025-07-12 21:41:24','97c9d988-fa12-4fa9-90eb-a5be42069d19'),(25,1,'qGyf3kgPZWyCsmaJi0amWsDqrp4RqlV7oxWUjAfJ5FCLlno5-PVvDd45LB9_mXsTgapKwJavK5oablHHuQX-muYV40oWC0s7FX7X','2025-07-12 21:50:45','2025-07-12 21:51:58','7a2a30ac-f432-4aab-b6ea-c421e01e6bc5'),(26,1,'vpt3fLurfc8b_TN3O1U9GCBlSFBtCoNw71pOyW1aC3vTEk1V_G09mVwUp2jZO17ay2juEZnyQvyhV7jwa7NWJHK_2SfyJUvLYg5h','2025-07-12 21:52:04','2025-07-12 21:52:06','122ccf9d-37b5-4c62-b0e1-ab587dfb3382'),(27,1,'yhHUk3p9fur8ICrxxHU8ybtjeGBHaP-n3J3-UAxjUuGTaIT140BEBk7eM_WUwJsUQmf3d7V6XX27uyyHXlx0rU7O8PIumKycNksZ','2025-07-12 21:52:18','2025-07-12 21:54:51','4c691153-8421-4991-afe6-783199d18733'),(28,1,'uy5Ul2HNtRTOilpEGqRJqwV40-_EgmOfcYOD0zi2ndG4qKyg6cjxVR2Rn3cz9PJ_ciqEpa2ztmQTLZBZLmm-fj9BmIR-SJamHva8','2025-07-12 21:55:12','2025-07-12 21:55:52','cb119d94-8931-48b4-9793-e1c071e0586c'),(29,1,'rbsw9XUnJUrWi1HpkMFx_Pd3Y6jDzSc8q_DzR8i5LZogUPWergwNr7-9v-G-j796XQnmasuYZUmn9KOiBjETrkLJ6loAOqPaY_hk','2025-07-12 21:56:28','2025-07-12 22:00:11','d8df9f2a-cf82-4cec-bd6f-4c0cc8e524c6'),(30,1,'40qOWY2q7H3o7p2c9Gehxo87jREqtSZhBzooXpn39F_iujYxUF8oNZeKFwdP0OwMCz5J_nojkXIQFTKTPsi-o-wu662sCY3_WOQJ','2025-07-12 22:00:31','2025-07-12 22:00:33','fcc749fe-1544-4c90-a756-3d97b3f7f092'),(31,1,'fVnh7yCXBnXneKTjalKcsxNfRl4O_WjDw8qWb-dS5btoAA77ewzF-DtCLARZRBqmOdd9AEAfiArTPkujIWQ5Q93LewsuHz-ZZ96S','2025-07-12 22:05:25','2025-07-12 22:12:30','58a83210-4043-4cf3-b2fa-7acfee695685'),(32,1,'xL6ZUCjSlKNtJD7g9wnQYsaN2yGMmoGszfQTj9LC298GYE-y2T-KPkzNxnPMIJaMM2VB42qF6R6nahmTaMfQBZQjaRHqGGsc7nIu','2025-07-12 22:12:48','2025-07-12 22:15:32','85ca4711-9a07-4658-9faa-aa1c4597ed14'),(33,1,'E39QZEldk7x6-_3EZd3ntbfIS_RgTDAOTrdZDZMdpYgLXIj9BXmHcj12wIzgjzeyg157hiKAFQk58DAhKnZn3MqgihWF1MVGiXBl','2025-07-12 22:15:32','2025-07-12 22:17:35','936c12e5-6e36-4052-adbf-def05bfbecab'),(34,1,'GxEMWSPT2EH3Vo_3nC_EqAVrGaBfqXW3gP98l5WQwhytKHleKgDxO8IQEuc2ZDzFRzVZk1EQWMvxbClhozx6nIfrUjKpDEXm1e3h','2025-07-12 22:17:35','2025-07-12 22:18:39','3dbd0cce-a3c4-42bf-9f86-5a37f2526197'),(35,1,'RKNSdqwD-BD_PmHyZlDgQ9CBcjalbARdAz6ijac_0sOlrOQQynqIQxHpI61VguF4OKZPU9snQlZbbGNl-kxwnuNf_K8u7QbZwgRB','2025-07-12 22:31:33','2025-07-12 22:33:14','21b36ad7-4375-4cdf-9784-e91a564bd643'),(36,1,'HG_gqJfIR1EfwF5oJkYrEzJzI1kM6wH6oSa8AdH_0H_VW3yTxhYphZZ_RooGHjRq_ndb7gwpDdFBKND6MFfZ8xL2CkhLR9-cbsFD','2025-07-12 22:33:15','2025-07-12 22:33:40','6709773e-7bc2-4243-9287-971c9b9d5100'),(37,1,'VmEhIXaYf35FWtcP6QcBBg7Inn0QKYU3Gl7UL6q0VXvl9JdklsR01G9Z8hGIInE3nxq_2L9cpNG9tKuHi_0Fq82RgDdC0qhCd0Kw','2025-07-12 22:34:48','2025-07-12 22:36:30','e5267f61-fb0d-4116-b086-22def754a865'),(38,1,'AH9lL5UhBzLEq08ZoFAX3xBvaqubcEI15Bxmm0GpNR5oc0Lbi0c13dXHsUHUjFWrkVtfzODSiSniyroH5dSVKfztmTpssRS6ySsj','2025-07-12 22:36:56','2025-07-12 22:44:25','94423672-34f6-48ed-8d33-daa98cab708f'),(39,1,'fFO6hF86Fwv2eU5Zg5Ynpgh1VT_XaBR20P2AGQVNdd11gOjFu0NeIN_lCo3_K9oRzx-gDwX387DdD0Z68uX5wXA-nTUGqbH4zlv3','2025-07-12 22:44:50','2025-07-12 22:50:38','d6064da4-c33f-4056-b2e6-54787c0f4ae5'),(40,1,'A9Pa0q3PZDE4OleczleX1W5PVOuzreMzvzZfr0AC_Q_0x9xzc9nNMBWYDY47t7QA5H6k8_e3KdP4nj92Jb2IfSVPHOospuWop1sK','2025-07-12 22:50:56','2025-07-12 22:53:06','8e0a4796-c9ca-4550-9e43-e73240bda39b'),(41,1,'nE8bhz3g3x5wGU0qQD0XktJscgQfVGEGY4mm7_ufVTWlSvqoKIkkzuvtadeEfpOT6gGvqld0GsglflqYw2oA5doR2ZGkybdOOha5','2025-07-12 22:53:55','2025-07-12 22:57:58','057e1521-bcf5-4cb3-b199-9ac8a9f06653'),(42,1,'u0rMbvL1aQpXAG_uykYp1wjWwC3HJ1JmvlqPucv_n_oJ9LRMvQ9XL7V8H1ZEzQVKY-Pmqqm27VM7nxR_cEwxB2pJZEbEg1Xzhxux','2025-07-12 22:58:24','2025-07-12 23:01:02','9a223850-d940-4641-9427-15801390a0e5'),(43,1,'iCu0XeEsCEcQUhUmHWPJFBP3FveEIW4ZO6c060_tuZjZZOwvR7gH_V4vSNelcZKJBF2N2g_Aglx9mlua9DjebvEV95MmrsFTxWjz','2025-07-12 23:02:04','2025-07-12 23:02:38','3cf607aa-3cf6-4058-9d75-d7650e7a224c'),(44,1,'XfMTxEc2tKIEil6_sdMvDKWCpMXnRl-IIOX6qL215zjiz9kSRpwvdsYW4TiN081UJeJyEuGPXVSjsPEDLgjdLkg-ROINSDrT58YQ','2025-07-12 23:02:51','2025-07-12 23:04:17','e4cb85f2-ffb9-4d06-8a6a-7215c1eb667e'),(45,1,'3Oc4YeRqTKHnJVVgP-slL0xs89fXg38Lqr4eb3OV5lwLkauSdPuQ42yxwCPTXJIjm5uD0baVpN-arK17OBEHvQshEPQy8ylxZCk2','2025-07-12 23:05:09','2025-07-12 23:07:14','50bc9413-4594-4953-bd08-68b7c01a3889'),(46,1,'lE-J54x8R2vKM6Lwi8KjJPoBCfGPrvURDIqlZUhxkJppOKT2nLwhtafeiZn6yljhlO5VuY5Utujw-Rdwo4bqNy54GcI6ESL5WllS','2025-07-12 23:08:23','2025-07-12 23:09:36','2833541e-faa0-4213-bf8f-2b03152b2c83'),(47,1,'XjBpaXZdbDDGGmzyXK9vXpIqE-cz3xpQwYBNcOTI-nYKOTABqaTE11W0I-j2Hh3tJDVNBN4keLwKJ9Ez3ZVs37twqZQCO9ipJ1gV','2025-07-12 23:09:37','2025-07-12 23:09:37','96f21b17-737d-4894-957f-404f59b96bba'),(48,1,'WcBCqFfcrxNsrot0cfaTH7A3zQ4qz9meKGHEPKU6pmf1bFRJvJBi2TltLCQ17lEZbmjqkWoxjVAr9XamklIZPi-q7XUcepBRAdwG','2025-07-12 23:11:28','2025-07-12 23:17:35','7cc94baa-b487-4e88-b3fd-ef2a3b6de6e1'),(49,1,'ssUoxY123JG7BoMo-OVYSu20BOz247X_GDsDFP4azDgNyLzcbd1rxUTIff8Wh_EiEv05Owgun_fITxul38OoFI3bIM4USte0DOFB','2025-07-12 23:17:48','2025-07-12 23:18:27','56b7fea9-2ef9-4a3a-a453-844a7561159c'),(50,1,'PmqDnSe96JSjsOeWe3zyJYBAOc00NTtJo9WOIv3Wx9ZY-61C7x3oDegkQ4l_Hy5YSEyWouT_lLtI0Jacc2d0mdcWi8R55fOqvX2O','2025-07-12 23:19:22','2025-07-12 23:21:25','e16d1b2f-74b8-428c-9540-bf70797a8078'),(51,1,'O3-5o-VNezBhGL0rXnEE5WHBY0PEiC0IAha9-LCV8mzBS6x7BFpf35T8j2JFOP6KFRCqIVqWGilai4XZgEhE6huRgUW4Ye58CauS','2025-07-12 23:21:37','2025-07-12 23:21:43','1c4f7337-b8d3-4638-a331-c430e75ee00c'),(52,1,'Ow-9Bje-gyugCFdF1a47eSFdj-u-3f1gfrTrknzL4NNQI1YehJDipC0Qb4_wqnOFftZ3hqjd7ymz-48ruqvPm7PtEycGvuwNIK85','2025-07-12 23:22:24','2025-07-12 23:22:53','4d4be5ca-eb4b-473b-9796-b56dcbf24a18'),(54,1,'9DL6GS-nu2PY1qq7muTbeMs3OK6YklywfSyTnsK9kpcqCAcx7dWfTsjTi9KpS2Eyw1UQOMz2ywXbBBZPb5JxwXU8-v7MCWDLPB8e','2025-07-13 00:33:27','2025-07-13 00:34:35','99e620c6-d01b-45a5-9cb6-6071ace042f1'),(55,1,'anfNvEZqqNYfouGyctgc8-IGvjPhCuoXnTyDuF0K1DXimoAz6wjs6KxTnm64aGoBiHJCymluvJQoOMCnhmJeP9Bdplg0F3SFiA_e','2025-07-13 02:25:56','2025-07-13 02:26:23','ba2ac011-376d-45fa-a01f-6144ca4d540c'),(56,1,'3zNXdjN993xeeP2pC5eQEJcJJKm4zTpLqGV_2nReS_wmjjHKfW2-LXbhKwvadWHbXnFE9LpI9T3brkXVeYWv4cYe30gXst6hjRXh','2025-07-13 02:26:43','2025-07-13 02:53:08','de201c79-eb97-4ad1-83f2-609697533776'),(57,1,'7PEk9MVQrhdOZ9s0nKhYg4h2KmJpaBseAgDYVygqaF6ZVCrNOobKyD7DFy7Y8ZEZ2gT6WJ93YZpzC_FCmUpdFXaHyq_LIixQK-JW','2025-07-13 02:54:25','2025-07-13 02:54:26','650693bc-9227-4c7f-8d49-f8b53980d308'),(58,1,'YNYGG445GMpMhpu07OPACZSbQNKftfvswC9RaIqTHCp0TuoHaY_KUhrryJr2XjdkNOPxLn2WUqMqiUCLIvu03mgUKNVwYqyY_uT7','2025-07-13 02:55:01','2025-07-13 03:04:53','c81ecad0-a7b0-46b9-bd79-8afb39551d76'),(59,1,'mVKwRBN245PhT5LU-QdLSDMCLJ9LVcP4R730LgF9rBoIcqBqMvIO9b5jLipEfSORmGLIkA94tdANpVOozVZ-BTJa8xkFXQwVtkuk','2025-07-13 03:05:10','2025-07-13 03:05:11','bd1f480b-ea32-4877-b236-7fcca6304b77'),(60,1,'LTCjg3t4a0zIU0jwGQGNPncnGb4EOAKY9Na7zDMH6XYjB02UjuSa3y0wvocA1PVqmKkZ7sQu6m7VZWCo6RkKK3Fp0pn49kQIl52V','2025-07-13 03:06:16','2025-07-13 03:15:16','e17d6dc0-73a0-4d92-9cac-88fd6e185993'),(61,1,'aNOaXW2kKF1ZulyIBcHAFPH1ccwVJCQGTg0Tu3b0RYSrkrpJjR4LDZf8I8YLd3PAwCl2Eyk_ox6HmjcFjPnVQTGjKULJ9fjRQYP0','2025-07-13 03:16:02','2025-07-13 03:16:02','5b9c9da6-afff-4725-8062-a4dfa040f2f0'),(62,1,'aIxerG1Re30AgAeSi06cosOunc-6yTUSr8EHrnT9fGwgY6ZLyMHQ296oaSMvz--EYTUab9MKXUlmQtHOuCDYkANhhFKGm2cQ40D5','2025-07-13 03:16:51','2025-07-13 03:17:05','9f06768c-8594-4cb6-80e4-ed4bc482001c'),(63,1,'VojBPlKS9_xzssvsa4-Q3NAnuigP3504I5wJwglkk5na9Hp_Dc_U8iJgJQ0p3gapVrL9Oy4JxwRtzahtlQ9N_wtVu1aDuVIgaX9y','2025-07-13 03:17:35','2025-07-13 03:17:35','48d5f33d-9811-4886-9b3e-3309e3808a1e'),(64,1,'7EaL5TxTIglzrTzKIqkC99twMIgYwOpS1nmytXHS0hf0qkpuisFfSiR8q3MCu0sFTuHjx7aE9kIr6oAd9gSYUURqITpFhvG9MC3j','2025-07-13 03:18:15','2025-07-13 03:18:41','ce2b0212-281a-4c36-9528-c7506abcf0c4'),(65,1,'leupIwDRhWcLOItcRIGro4YZnv4zSdPeSa075IX38btf8hC7UtHo8pHRrGTxOF2V16oZz4zVEzjSy7ou8VXpqsQ3xQ-yv7FT9y55','2025-07-13 03:21:38','2025-07-13 03:27:29','73d3469d-de1e-4455-892a-f1bdc08718a7'),(66,1,'aylQgFF0rnCZ4eJkbSYhT9kk4URq49rmXzOuVMkbQkOzEn_lWZal6Q_etSQN6ieUAK0CxFJXG3mXIivMJz_KQYVASn7w_7U3W7KQ','2025-07-13 03:28:41','2025-07-13 03:29:45','2d2ea273-7273-425b-ab81-9ff6af8dfd59'),(67,1,'xcHyDhYemKrHSp_eqDPdH-JBb0F0PzUG1HUWGD9zurUC3_PY3MDT_NUYSXFfPq3C6kcVXko1SqT5TxmCoGs429WI-pyMzNChnQlp','2025-07-13 03:30:55','2025-07-13 03:31:56','29cd278f-1c56-4c18-b7dc-8efc2fb06e93'),(68,1,'XTWQUA9ZYpeI-Pgh4Ro4pGYWaXm3HwP2c7rgFiBsHSUk6Ruw1EP9mLTfiO645cy5DJCiJjl8pLnWoc7u4w6QgE35AJWMro2n45Iy','2025-07-13 03:33:07','2025-07-13 03:36:34','f54a4c7c-1915-4f25-8246-1e5ac91f0bc3'),(69,1,'p0QbV9938J3bk68nsk3rYOT_JBs9XEWhRcjEfkG5je7AtaEHeHrWdvJa_F3LLoYWBnDiOIEJ7Cg6e3ZFj3XWGzUULcrQUg0nhMi-','2025-07-13 03:37:19','2025-07-13 03:37:19','93390131-7a73-4a8d-b975-c9ba24a80e87'),(70,1,'IwjFspaGPdttxOKwElGVJEw2XaAYjvYS0Aeqvn9h-TdeXNJAgFMnVjuYfbVGtGaC0pkpGTE0W1xirpG36VVJvpHKsZdTJfrlGNh-','2025-07-13 03:38:19','2025-07-13 03:41:44','08c8ca28-a4da-43be-94b6-dd92976ba3c7'),(71,1,'BnfUieZkqBhJVNvdM1SflwTsMBLeRQv6PrlzBCRVBnoWveUpKfA-Pja7-JWEL7hJ7kCtgCDakH4XhBhzcOhrnIJwMglixXPAVXDR','2025-07-13 03:42:07','2025-07-13 04:00:07','2915e102-e447-45c6-b57b-68d0dab9c8f3'),(72,1,'e_tw41fRYFTljUVddqmoPqjr0_u_nvNUUItW1ay17OoEGYMcXf9aGn9V-lOJzVkHF7-EaQTLqJcBO325LpCYCiP2NqdrV6ujhVnY','2025-07-13 04:01:02','2025-07-13 04:02:04','6a627222-dd2d-48d9-8560-e2a6ac62816f'),(73,1,'_vP6CV9zBA3rvY9gDlF0J97ou8s4wdO0x1c0OLjfVupdKR1PPDOMaeBX4bOEAbKV2OQc9pkpD9-k4EF7hJIBR44WITzd2Uz8qS80','2025-07-13 16:41:42','2025-07-13 16:41:42','1712677c-e4c2-46e9-9cfa-8b7135c80111'),(74,1,'iadc1nVVHcnf5Y9JZ9X3pmT7yBjs-B6EcqXMhsW29QPx_vM_C0HcUvs408gmEoW6L2yIdvSJjQVH52i36s6zL9qJJp0pYUpCAnJC','2025-07-13 16:42:49','2025-07-13 16:43:48','2cfd30a9-1903-4fa7-b483-70d722afdc85'),(86,1,'mk0HlBwLWbGOcO2jUomFK1bAb9_2gCyvE-jUofckh_xnVBaS2feCNNG3VHhAMVzod046Xsk3sFVMT5UDy7RW7dL_LZbEzfVAIyOw','2025-07-13 18:08:02','2025-07-13 18:08:15','6dc604d0-f101-4d61-ab53-8618388eb4ce'),(87,1,'NUeCbP3MtAApKcVWMXCrawRpeXlBSp8GE3tRf7AgW9ax9RwHTFy7bNzpsrezRft3vFJD3-bVSX8Og3_9Rh6-MprtOUS2Bml5FW23','2025-07-13 20:17:40','2025-07-13 20:36:27','d3ccef6a-a62c-497d-bae1-faabd022a00c'),(88,1,'6VHuBVeMEmg-qI-L8OpiLfFGvUZVJvmo9SXYo8rIFj93nmcx09EPmQcBNgtORcJWtrHGjjtgnz6SkISUvnPhksIDzwJnfG1Lj7Dw','2025-07-14 12:43:40','2025-07-14 14:34:42','a67f17ad-32fb-4769-ad63-03482780e615'),(89,1,'NmlMwzlZJbCxMzfmyorTFtjGRyES2FfRuSfzA4Q1cgT8GG4YxIaXrOv5ge4C4LuBAEgB3ask4N_nTGhZ6oht_OMranRHo0TgYSww','2025-07-14 19:48:59','2025-07-14 21:49:43','23bc8110-2930-4254-a015-527514619a0b'),(90,1,'x9FjT8EXG2cNMRhEtx0Bf_zqhXA5QJ7NJayiMrB1V6mX2zoPsmkxq8cKYYecAK2drwsVLouxUR0PdItV-4Ckyd-ynOE0aGf75jYO','2025-07-14 21:49:43','2025-07-14 22:28:14','7b3a3f13-8df7-4175-a1f2-dd7234e286be'),(91,1,'PthDOQCGmkR_kW5T_5aSd5p1GJ6IveByJWQXXl2F1ejqm6wAv4_H0WNjf2thQzMsKV37rWIWdNjTHX8WVLWmlV0zvuQOQ7l24shM','2025-07-16 19:14:46','2025-07-16 19:36:56','c731d249-5627-49f1-b63d-33546fc8ed38'),(92,1,'MdSlW3_-AwfyEPLpMFGL_6i5R40o5UOwQo2EnCojEUFdel_AIXQ7K3DeyI5TGuVR7Z0vMoPfFEw3ROIDQU5THs2L9qWLO74yZHoQ','2025-07-18 20:05:24','2025-07-18 21:50:23','b2957739-138e-4ab4-9834-c60fbb4dad7f'),(93,1,'1TMYcggVZh8d-3dQUtEMNVAzvSjlXWx_xJm_OD2Mkw0z3JhuLC2UCTcAu_-M6nsvirEx2zXpohuHWfS8IWqs8Vqt4JtWy2DsU1AV','2025-07-18 21:50:23','2025-07-18 23:18:48','12319a11-fc89-4537-9d59-351296a5d284'),(94,1,'SbzQcGG1aHg5A4fTJmqeSYL0MigTI-mv0MTjrlo3eTHgs22poXhF-L_PaENaTelgxiiIa5G6VD4Qr7PoBnaq5OT5utmP--a2lqGM','2025-07-18 23:18:48','2025-07-18 23:18:48','2643cd4a-5305-47a1-ac85-f181afc0df46'),(96,1,'Tne4k0dT1z_HOHTpZ5J5t11oQtBDWi-tEBvG4qDiC0vD1QazY6xrSrAhb_QAu2qvkDvpU2BrA0ClM_wPW6BjqfzxVM8MgW7bAXlZ','2025-07-20 13:57:53','2025-07-20 14:01:49','16594b11-af68-44e3-9dc6-8f7100ec1d92'),(97,1,'t4zT9TcQxvc9FtMiysHaP8cq4IzXgwZIVv-dFULsfJmPdOBaXEWkuseNSUWXP705uLWdlPjvirIz9jQo4cU2QLS0RfbS_X68iDMM','2025-07-20 14:02:21','2025-07-20 14:02:25','153c52a4-6fcc-4409-b980-6edf4e0d209f'),(98,1,'9W9XnIkmw-Z-Ik-T8jkIHlzfzsmMEAcUxVMfjx9Xbu1XSP6uJ_C3hkM4m8mpZgEP2W9PYZdi-pw1iYSRLDqZiNMGfzJcYNcT5OOS','2025-07-20 14:02:53','2025-07-20 16:06:07','3fb466da-8598-4ad0-ad5c-0b616d0d0207'),(99,1,'LaPeEWG7pYbe6GI75OKdaIKBLG4OQ0CSizm7uUbeUaL0u9oaTfXp5ZKmm0NRKYDz2JyG3B7X79EN1YDu0au6lbL5KPk5W5NFZBBM','2025-07-21 12:49:42','2025-07-21 12:49:50','25dc4d0a-d28e-4057-a34b-e4d732810029'),(100,1,'XVl42UeK0jvhMFoC6Pi3qBBA-zi37FW8Wu6bxebhFFL9ccQiQgVQeC4OlpzxefR79RoQybLt5D1iGijv1wsMamiKPCc_KfPKuDo1','2025-07-21 23:58:46','2025-07-22 01:07:43','01337448-5243-48a3-b6c4-8dc06b20d62e'),(101,1,'gmL59pam8ox3Tp72OVjjxr-z87Q9UU0GBskncxaeuK1n4fKnzQo1YS-oIO7a2uEt83Jf2IiBHxLPvS2aq5DvFHTKLuInuuPIEg9o','2025-07-25 21:13:17','2025-07-25 22:49:05','f46ca9db-a325-4c2c-9743-58bd27d0ac8e'),(102,1,'64uY79tEAPlnB3KdezdoHY_5fnji0pZcuPMeuISBt2HnYUSo3F3xYEpyrvsWYg0FHnc6Q-fEQo8NzQ_aH9IicGhqnSwUPvzWE3pt','2025-07-25 22:49:05','2025-07-25 23:15:13','a68b3ef0-5024-4d52-81d7-c7883ce0ca77'),(103,1,'wdUwKu8OWRpaVDOxqazMeoofrqqEgIk0Txj_yYF51GHLyUnBFj5AKdpRuzaTjKyuh-q8HLdfk9legmoWYPLgAPGaDD2dU8kJ1L1g','2025-07-25 23:15:13','2025-07-25 23:32:06','2fa6b2a5-b749-4cb8-8624-e96acab6ab12');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_maydgjblqucnpsiwmyluddcfvhzerzymwbek` (`userId`,`message`),
  CONSTRAINT `fk_gtxksmbfyfepywvquddaqplqozxwbvoagamt` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hpnxsorlxfkexfpgsytzxnwejhbcdnxiqaet` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
INSERT INTO `sitegroups` VALUES (1,'Filament-Boilerplate','2025-07-11 00:31:06','2025-07-11 00:31:06',NULL,'72cc4092-dce2-4057-a061-5bf104dd7d96');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xkwusyjltovasaokjvilkffedcygkflqjvcd` (`dateDeleted`),
  KEY `idx_ozassjaguaopywalbmwnfqljakpqedsdvdpv` (`handle`),
  KEY `idx_bvjbicavmkoldfioxufdsvvrlfarvsnfajkn` (`sortOrder`),
  KEY `fk_rmydnvowulwohagtlbyqgedgxcabnkwxgthn` (`groupId`),
  CONSTRAINT `fk_rmydnvowulwohagtlbyqgedgxcabnkwxgthn` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES (1,1,1,'true','Filament-Boilerplate','default','en',1,'$PRIMARY_SITE_URL',1,'2025-07-11 00:31:06','2025-07-11 00:31:06',NULL,'48eabee0-5886-430a-ac24-e708a30e425a');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sso_identities`
--

DROP TABLE IF EXISTS `sso_identities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sso_identities` (
  `provider` varchar(255) NOT NULL,
  `identityId` varchar(255) NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`provider`,`identityId`,`userId`),
  KEY `fk_saagxlipiwepfjutyzpaedjzhwsfbzcfyfxk` (`userId`),
  CONSTRAINT `fk_saagxlipiwepfjutyzpaedjzhwsfbzcfyfxk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sso_identities`
--

LOCK TABLES `sso_identities` WRITE;
/*!40000 ALTER TABLE `sso_identities` DISABLE KEYS */;
/*!40000 ALTER TABLE `sso_identities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_fxomnmbnxeswjvdbxjjphodsulxstaqkapnk` (`structureId`,`elementId`),
  KEY `idx_qzwrsohmtoashkedorareyhreibilkzgdsrq` (`root`),
  KEY `idx_adkgbyfwlelpuvbtpcstbxzaooezdawlqlxk` (`lft`),
  KEY `idx_xeynrvahgyhbvvlirqdqvahmqyeplrxiorqk` (`rgt`),
  KEY `idx_fwzldmcjwgaynkvwgmydliofibrswlmwfucj` (`level`),
  KEY `idx_qkfpnttduuydgephrycfnymsezkdhuuvajex` (`elementId`),
  CONSTRAINT `fk_zisokoyblczgldglsdxwlrjmhgeymuiizowb` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_lqtuljikyssrrcuxnomsdimozqnexrqwemod` (`dateDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_pifxvvzuvjvsnmdpukijmivrknpsjxygffox` (`key`,`language`),
  KEY `idx_fnaevhqxcphztvljfpnwvgdimfiamojbliyh` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_pedittvluybhzskgynkaycqmqyivfrhltbkb` (`name`),
  KEY `idx_hivpjmvczakikswvufsgqcajzligzzxxoeee` (`handle`),
  KEY `idx_uoxjcljyemjnjaodkyeovlcqsnasdthmpipm` (`dateDeleted`),
  KEY `fk_btbzocqolyfqywedjzakgenyzvrcyjlosiqx` (`fieldLayoutId`),
  CONSTRAINT `fk_btbzocqolyfqywedjzakgenyzvrcyjlosiqx` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_udwarhcogwqbgfwaaykghizaamhwsnaifzee` (`groupId`),
  CONSTRAINT `fk_uwemmkiurfxjkwybmtbmachowfzgebugfztj` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xrlpnpvgejmrxxdhpliusqwsmvtunhlnpykb` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_basdhyihptryuleszjmkhrnvywyhdjbfyrdi` (`token`),
  KEY `idx_oljtpnlfquvzgcffmbmhafvvtsksfagfdiao` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xbcvqzpobyhcgizfzizdwfcfvatwmnzikzdf` (`handle`),
  KEY `idx_yhjphchqdnixbpqsjkupdkctbjrqxshbdwfm` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mxzohrqmrmraorrkgbmgdestsgtfzgbngiyb` (`groupId`,`userId`),
  KEY `idx_sfkyesytggscnyhbsbldahtwpyxwnnclwjcb` (`userId`),
  CONSTRAINT `fk_hhbpwlqmgtqjxiszmuisjyfwepmzzkkejrzo` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_udfwyxzpobpxolpljfdvmhutxvtqzzanzntl` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bsfrpaapcjwyifjdavxigbhprtdhucxsmotl` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_fqebtehjklwaegwrrsmzwclfwjlezdjenqwv` (`permissionId`,`groupId`),
  KEY `idx_hdpfuhujnrrehzpocaqutxmujkhvctmnryzc` (`groupId`),
  CONSTRAINT `fk_cnpaxklnhsgagehtspeyntgvmonldnazyfet` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_iawjysjrvsmqgxgjovoibjkleyddrbuiqoxc` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_encacyzxascmlzobochazerhqbvqksfkgsvj` (`permissionId`,`userId`),
  KEY `idx_urmvjzdmvzwfxqhzhyjsjlkkqtzyoetxoahs` (`userId`),
  CONSTRAINT `fk_ajerkusycumphetqbhezcamlmhiaeptgpymr` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_spjdsmizsmmmcpzxnqaasijdglckapcaybpx` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` json DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_gholnxlybyiqulzskrfjqescmsytfqkuqrtj` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
INSERT INTO `userpreferences` VALUES (1,'{\"language\": \"en\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `affiliatedSiteId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_iczmxanenhqfwgcxlhsymwrsxfxxsgxuszit` (`active`),
  KEY `idx_jezrscfmakxjhlgoitaxswmykrtyyxokodsm` (`locked`),
  KEY `idx_pqakdpasovgwrgpeucvhrprmyqiqohdclwqf` (`pending`),
  KEY `idx_dpfoczbmouoxwiqgwrrzqjedjdukbtklbumb` (`suspended`),
  KEY `idx_xcctvfjuyiivvrrohgdhlimbmpqtuxhxdkxq` (`verificationCode`),
  KEY `idx_uxjugiafizcjnreokulhqrxexioljvjlbldi` (`email`),
  KEY `idx_dmmuxjzmsatmsvrivdhpyxsitwmtjoihjiau` (`username`),
  KEY `fk_idaljnuolwvhnkvocniqumlrtydylbqibynd` (`photoId`),
  KEY `fk_tkfydzgzbutzyktikeblhuvmwexgnbetwzlt` (`affiliatedSiteId`),
  CONSTRAINT `fk_idaljnuolwvhnkvocniqumlrtydylbqibynd` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_necizhwursdkdpimutyxiyyghbavjsocvgcu` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tkfydzgzbutzyktikeblhuvmwexgnbetwzlt` FOREIGN KEY (`affiliatedSiteId`) REFERENCES `sites` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,NULL,1,0,0,0,1,'admin',NULL,NULL,NULL,'creative@raraavis.design','$2y$13$Zt5agiNq5/tGIAIWnDaaueqJlbDOCcshMgVBNU0wWn3kQThtJf2Ii','2025-07-25 23:15:13',NULL,NULL,NULL,'2025-07-25 21:13:13',NULL,1,NULL,NULL,NULL,0,'2025-07-11 00:31:06','2025-07-11 00:31:06','2025-07-25 23:15:13');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mfyavvnsybotjaspfwbfhpemndlbcbtwvtqi` (`name`,`parentId`,`volumeId`),
  KEY `idx_lczsisbelixtkrgjloukvqvheaisitdrvuzs` (`parentId`),
  KEY `idx_qenkbrttmlufslvguyeptzadgclfrqefysgd` (`volumeId`),
  CONSTRAINT `fk_slxsmadvqpudxxilqavqftaaaukqlacbouil` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xbjsehgiiboddggsbfbrsshmtltudxozxiky` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
INSERT INTO `volumefolders` VALUES (1,NULL,NULL,'Temporary Uploads',NULL,'2025-07-13 17:11:05','2025-07-13 17:11:05','9c4064c9-9e28-445c-83dd-d3f78389587a'),(2,1,NULL,'user_1','user_1/','2025-07-13 17:11:05','2025-07-13 17:11:05','d2dad761-27ec-456d-b54b-af2c67017502');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `subpath` varchar(255) DEFAULT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `altTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `altTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_tynoxoaudmwmyhdmdasebdxeswzsujzpzrld` (`name`),
  KEY `idx_iezeahnylxyyzzaprnldeuyjkptplvgvlyyk` (`handle`),
  KEY `idx_kkpizinnmyirczdakhbwbnnladxmtyozmvem` (`fieldLayoutId`),
  KEY `idx_qerbekzqlkizmeekdowwotajutkjmomovmto` (`dateDeleted`),
  CONSTRAINT `fk_enfcdpqgmgfzwxsgbmlnkzxktrkjldrvugwy` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webauthn`
--

DROP TABLE IF EXISTS `webauthn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webauthn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `credentialId` varchar(255) DEFAULT NULL,
  `credential` text,
  `credentialName` varchar(255) DEFAULT NULL,
  `dateLastUsed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_ybyngkmquokjraeyxwhhackqjzhyijbswznu` (`userId`),
  CONSTRAINT `fk_ybyngkmquokjraeyxwhhackqjzhyijbswznu` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webauthn`
--

LOCK TABLES `webauthn` WRITE;
/*!40000 ALTER TABLE `webauthn` DISABLE KEYS */;
/*!40000 ALTER TABLE `webauthn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zrotbjyosusqqlsjabtzydoktkddjiqeisyn` (`userId`),
  CONSTRAINT `fk_ofddhmccvtxkwtyovzghynexkodulhfsmoyi` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"limit\": 10, \"siteId\": 1, \"section\": \"*\"}',1,'2025-07-12 19:22:33','2025-07-12 19:22:33','25125c42-171c-4443-acb5-cdd1c259f7ef'),(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2025-07-12 19:22:33','2025-07-12 19:22:33','9807754f-9a70-47db-8c30-be0473c61f0c'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2025-07-12 19:22:33','2025-07-12 19:22:33','a762964f-d4d9-49e0-be62-d48836cda392'),(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\": \"https://craftcms.com/news.rss\", \"limit\": 5, \"title\": \"Craft News\"}',1,'2025-07-12 19:22:33','2025-07-12 19:22:33','f6b34f06-736f-4614-908a-8b0b5247b0b4');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-04 16:46:06
